{
	// the widget definition, where 'workspace' is the namespace,
	// 'workspacefooter' the widget name
	_$.widget('workspace.workspacefooter',
	{

		// default options
		options: {
			template: '/base/widgets/workspace/html/workspace.tmpl.html#workspace-footer-template',

			toolbar: false,

			plugins: [],

			items: {
				left: [
					{id: 'prev-record-bt', class: 'button-action', action: 'PREVIOUS_BLOCK', icon: 'glyphicon glyphicon-chevron-up'},
					{id: 'next-record-bt', class: 'button-action', action: 'NEXT_BLOCK', icon: 'glyphicon glyphicon-chevron-down'},
				],
				right: [],
				bottom: []
			}
		},

		// the constructor
		_create: function()
		{
			var that = this;

			this._isRTL = this.element.css('direction') === 'rtl';

			var appsroot = Frames.Config.get('APPS_ROOT', '.');
			var url = Frames.parseUrl(appsroot + this.options.template);

			this.templates = {};

			Frames.Template.get(url, function(result) {
				that.templates.main = result;
				that._refresh();
				that._initializeClick();

				if (!Frames.isUndef(Frames.Workspace._workspaceReady))
				{
					Frames.Workspace._workspaceReady.footer = true;
				}
	
				if (Frames.isFunction(that.options.onready))
				{
					that.options.onready();
				}
			});

		},

		_initializeClick: function()
		{
			var that = this;

			_$('a[data-action]', this.element).on('click', function()
			{
				var $el = _$(this);
				Frames.Application.valexec($el.data('action'));

				if ($el.parent().attr('id') == 'save-bt')
				{
					Frames.Application.trigger('savechanges');
				}

				return false;
			});
		},

		// events bound via _on are removed automatically
		// revert other modifications here
		_destroy: function()
		{
			// ...
		},

		// called when created, and later when changing options
		// and menu methods
		_refresh: function()
		{
			if (!this.templates.main)
			{
				return;
			}

			if (!this._initialized)
			{
				this._initialized = true;

				_$.workspace.verticalmenu.prototype._apply_shortcuts(this.options.items.left);
				_$.workspace.verticalmenu.prototype._apply_shortcuts(this.options.items.right);

				var tmplOptions = _$.extend({}, this.options.items, { rtl: this._isRTL, toolbar: this.options.toolbar });
				var html = this.templates.main(tmplOptions);
				this.element.html(html);

				if (this.options.toolbar)
				{
					this.element.addClass('workspace-toolbar');
				}

				// call all plugins if exist
				_$.each(this.options.plugins, function()
				{
					var plug = this;

					if (Frames.isFunction(plug))
					{
						plug(that);
					}
				});
			}
		}
	});

	var _wfDefaults = _$.workspace.workspacefooter.prototype.options;
	_$.workspace.workspacefooter.setup = function(options)
	{
		if (!options)
		{
			return;
		}

		var opts = _$.extend(true, {}, _wfDefaults);

		if (options.items)
		{
			if (options.items.left)
			{
				opts.items.left = options.items.left;
			}
			if (options.items.right)
			{
				opts.items.right = options.items.right;
			}
			if (options.items.bottom)
			{
				opts.items.bottom = options.items.bottom;
			}
		}

		if (options.template)
		{
			opts.template = options.template;
		}

		if (options.toolbar)
		{
			opts.toolbar = options.toolbar;
		}

		if (options.plugins)
		{
			opts.plugins = options.plugins;
		}

		_$.workspace.workspacefooter.prototype.options = opts;
		return opts;
	};

};

//# sourceURL=app/base/widgets/workspace/js/workspace.footer.js
