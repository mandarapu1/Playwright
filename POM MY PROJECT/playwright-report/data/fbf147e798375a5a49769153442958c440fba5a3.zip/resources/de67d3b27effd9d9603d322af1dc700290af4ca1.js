
var _init = Frames.ToolBar.init;
Frames.ToolBar.init = function()
{
	// custom tools
	Frames.ToolBar._tools = arguments[0];

	_init.apply(Frames.ToolBar, arguments);

	_$('.page-action-menu button[data-action],.statusbar button[data-action]').on('click', function()
	{
		var el = _$(this);
		var action = el.data('action');
		Frames.Application.valexec(action);
	});

	// var item = Frames.get('select-bt');
	// item.elem.removeClass('ui-state-default ui-button');

	Frames.ToolBar._elem.off('click');
};

Frames.ToolBar.customRules = function(elem)
{
	if (Frames.isUndef(Frames.ToolBar._elem) || Frames.ToolBar._elem.length === 0)
	{
		Frames.ToolBar._elem = _$('#menu-tools  li').not('.menu-node').has('a[data-uuid]');
	}
	if (Frames.isUndef(Frames.ToolBar._elem2) || Frames.ToolBar._elem2.length === 0)
	{
		Frames.ToolBar._elem2 = _$('.workspace-footer li').has('.button-action');
	}

	elem = Frames.ToolBar._elem;
	elem2 = Frames.ToolBar._elem2;

	elem.attr('disabled', 'disabled');

	elem2.filter('#next-record-bt').hide();
	elem2.filter('#prev-record-bt').hide();

	var print = false;
	var task = Frames.Application.task;

	if (task == Frames.Application.mainTask)
	{
		return;
	}

	var block = task.block;
	if (!Frames.isUndef(block))
	{
		var rules = Frames.ToolBar.customRulesObj(block);

		if (rules.canRollback)
		{
			elem.has('a[data-uuid=tb-rollback]').removeAttr('disabled');
		}

		if (rules.canPrint)
		{
			elem.has('a[data-uuid=tb-print]').removeAttr('disabled');
		}

		if (rules.canExit)
		{
			elem.has('a[data-uuid=tb-exit]').removeAttr('disabled');
		}

		if (rules.canExport)
		{
			elem.has('a[data-uuid=tb-export]').removeAttr('disabled');
		}

		// elem2.find("#select-bt").show();

		// if (rules.canSave) { elem2.filter("#save-bt").show(); }
		if (rules.canGoNext)
		{
			elem2.filter('#next-record-bt').show();
		}

		if (rules.canGoPrev)
		{
			elem2.filter('#prev-record-bt').show();
		}

		Frames.Application.trigger('toolbarrefresh', rules);
	}
};

Frames.ToolBar.customRulesObj = function(block)
{
	var blockMode = block.props('blockMode');

	var rules = {
		canAdd: Frames.isTrue(block.props('AllowInsert')) && blockMode !== 'SEARCH' && blockMode !== 'READ',
		canDelete: Frames.isTrue(block.props('AllowDelete')) && blockMode !== 'SEARCH' && blockMode !== 'READ',
		canCopy: Frames.isTrue(block.props('AllowInsert')) && blockMode !== 'SEARCH' && blockMode !== 'READ',
		canPrint: print,
		canExit: true,
		canExport: true,
		canRollback: true,
		canSave: true,
		canSearch: Frames.isTrue(block.props('AllowSearch')),
		canFilter: Frames.isTrue(block.props('AllowSearch')) && blockMode !== 'SEARCH',
		canGoNext: true,
		canGoPrev: true
	};

	return rules;
};

//# sourceURL=app/flat/js/toolbar.js