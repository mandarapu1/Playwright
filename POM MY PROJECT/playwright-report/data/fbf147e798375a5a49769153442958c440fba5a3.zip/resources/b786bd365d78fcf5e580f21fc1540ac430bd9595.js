	_$.widget('ui.filterpanel',
	{
		// default options
		options: {
			popup : false,
			bindable: undefined,
			filter: true,
			sort: true,
			groupby: false,
			hide: {
				effect: 'swing',
				duration: 400
			},
			show: {
				effect: 'swing',
				duration: 400
			},
			toggle: {
				easing: 'swing',
				duration: 400,
				complete: function()
				{
					Frames.Application.trigger('filtertoggle');
				}
			}
		},

		clear: function()
		{
			if (!this._alreadyOpened)
			{
				// if hasn't been opened at least one time there is nothing to clean
				return;
			}
			var that = this;

			this._advancedFilter_middleDiv.children('.cloned')
				.each(function() {
					that._clearItems($(this));
				})
				.remove();

			if (!Frames.isEmpty(this.__selectedFields))
			{
				_$.each(this.__selectedFields, function(index, element)
				{
					// enable filter option in other filters
					that._disableFilterOption(element);
				});
			}
			this.__selectedFields = [];

			var mainFieldSelect = $('.fieldSelect', this._advancedFilter_middleDiv);
			if (mainFieldSelect[0])
			{
				this.__fieldSelectTmpl.clone(true)
					.insertAfter(mainFieldSelect);

				mainFieldSelect.remove();
			}

			this._clearSearch();
		},

		_clearSearch: function()
		{
			if (this._version2)
			{
				this._advancedFilter_middleDiv.children('.cloned')
					.each(function() {
						var item = $(this).find('input.selectInformation, button.selectInformation').parent();
						item.find('span.ui-input-readonly').text('');
						item.parent().css('display', '');
					});

				this.element.removeClass('ui-advancedFilterAgain');
			}

			$('.filter-caption', this._templateAdvancedFilter_h3UpPanel).text(_(Frames.Locale.messages.FILTER_CAPTION));
			this._buttonFilterAgain.hide();

			if (this.element.is(':visible'))
			{
				this._advancedFilter_middleDiv.slideDown(this.options.toggle);
				this._templateAdvancedFilter_h3DownPanel.slideDown(this.options.toggle);
			}
			else
			{
				this._advancedFilter_middleDiv.show();
				this._templateAdvancedFilter_h3DownPanel.show();
			}

			if (this._version2 && !this._hideAddField())
			{
				this._advancedFilter_middleDiv.find('.middleDivRow:not(.cloned)').show().css('display', '');
			}
			else if (this._version1)
			{
				this._advancedFilter_middleDiv.find('.middleDivRow:not(.cloned)').show();
			}
		},

		exit: function(close)
		{
			var block = this.getBlock();
			block._lastmode = 'EXIT_FILTER';

			delete this._lastfilter;

			if (this.element.parent().is(':visible'))
			{
				this.element.slideUp(this.options.toggle);
			}
			else
			{
				this.element.hide();
			}

			this.clear();

			var mode = block.props('blockMode');

			if (mode === 'SEARCH')
			{
				// this will clear the current query filters
				if (close)
				{
					this._executeQuery( undefined,'CANCEL_SEARCH');
				}
				else 
				{
					this._executeQuery([]);
				}
			}
			else
			{
				Frames.FilterPanel.execute('EXECUTE_QUERY', undefined, this);
			}

			if (this._version2 && block._FILTER_)
			{
				block._FILTER_.clear();
				delete block._FILTER_;
			}

			if (this._version2)
			{
				this.element.removeClass('ui-advancedFilterAgain ui-advanced-filter-mode ui-basic-filter-mode');
				delete this._filterAgainMode;
				delete this._alreadyOpened;
			}

			delete block._lastmode;
		},

		bindable: function(bindable)
		{
			if (!Frames.isUndef(this._bindable) && this._bindable != bindable)
			{
				// If bindable was from the same block events will not be removed. The filterpanel is the same.
				if (this.getBlock() == bindable.block)
				{
					return;
				}

				delete this._bindable._filter;

				Frames.Application.off('endbind.filterpanel_' + this.instanceId, this._onEndBind);

				$(this.getBlock())
					// .off('postbind.filterpanel_' + this.instanceId, this._onEndBind)
					.off('prebind.filterpanel_' + this.instanceId, this._onStartBind);
			}

			if (this._bindable != bindable)
			{
				this._bindable = bindable;
				this._view = bindable.block.task.view;
				bindable._filter = this;

				Frames.Application.off('endbind.filterpanel_' + this.instanceId, this._onEndBind);
				Frames.Application.on('endbind.filterpanel_' + this.instanceId, this._onEndBind);

				$(bindable.block)
					// .off('postbind.filterpanel_' + this.instanceId, this._onEndBind)
					// .on('postbind.filterpanel_' + this.instanceId, this._onEndBind)
					.off('prebind.filterpanel_' + this.instanceId, this._onStartBind)
					.on('prebind.filterpanel_' + this.instanceId, this._onStartBind);

				// starting mode could be "SEARCH"
				// only execute endbind if it's already created or it will occurs before the controlfinfo execution
				if (!Frames.isTrue(this._creating))
				{
					this._onEndBind();
				}
			}
		},

		newoption: function(select, txt, v)
		{
			var opt = new Option(Frames.isUndef(txt) && _$.browser.mozilla ? '' : txt, Frames.isUndef(v) && _$.browser.mozilla ? '' : v);
			if (select.get(0))
			{
				var opts = select.get(0).options;
				opts[opts.length] = opt;
				return $(opt);
			}
		},

		_searchable: function(item)
		{
			if (!Frames.isUndef(item))
			{
				var iSearchable = item.props ?  Frames.isTrue(item.props('AllowSearch')) : (item.properties && Frames.isTrue(item.properties[0]['@AllowSearch']));
				return iSearchable && Frames.isTrue(this.options.filter) && !Frames.isTrue(this._isButton(item));
			}
		},

		_sortable: function(item)
		{
			if (!Frames.isUndef(item))
			{
				var isSortable = item.props ?  Frames.isTrue(item.props('AllowSort')) : (item.properties && Frames.isTrue(item.properties[0]['@AllowSort']));
				return isSortable && Frames.isTrue(this.options.sort) && !Frames.isTrue(this._isButton(item));
			}
		},

		_isButton: function(item)
		{
			var widget = item.data('widget');
			if (!Frames.isEmpty(widget))
			{
				var WidgetType = Frames.gettype(widget);
				return !Frames.isUndef(WidgetType) ? WidgetType.prototype.widgetcls.apply({elem: item}) === 'xbutton' : false;
			}
			return false;
		},

		onStartBind: function(ev, data)
		{
			var that = this;
			var block = this.getBlock();
			var mode = block.props('blockMode');

			if (mode !== 'SEARCH')
			{
				// content must be visible before the actual binding process
				if (this._version1)
				{
					this.$content.show();
				}
			}
			else
			{
				if (that._version2 && block._lastmode !== 'SEARCH' && !that._filterAgainMode)
				{
					if (Frames.isTrue(that._exitFilter))
					{
						delete that._exitFilter;
					}
					else
					{
						// reset
						block._FILTER_ = new Frames.HashMap();
					}
				}

				setTimeout(function()
				{
					if (!Frames.isUndef(data) && that._version2 && block.props("IsInFilterMode") !== 'true')
					{
						that.applyModel(data);
					}

					if (that._version1)
					{
						that.$content.hide();
					}

					that.focus();
					that.element.trap();
				}, 500);
			}
		},

		getBlock: function()
		{
			return this._bindable.block;
		},

		getItem: function()
		{
			var item = Frames.Application.current();
			if (!item || !item.block)
			{
				item = this._current;
			}
			return item;
		},

		isInFilterMode: function()
		{
			var block = this.getBlock();
			return Frames.isTrue(block.props('IsInFilterMode')) && mode !== 'SEARCH';
		},

		onEndBind: function()
		{
			var that = this;
			var block = this.getBlock();
			var task = Frames.Application.task;
			var view = task.view;
			var collapsible = this.element.parents('.ui-accordion, .ui-collapsiblepanel').eq(0);

			var filterVersion = !Frames.isUndef(block._exts.FilterVersion) ? block._exts.FilterVersion : Frames.Config.get('FILTER_VERSION', '1');
			this._version1 = filterVersion === '1';
			this._version2 = filterVersion === '2';

			// Only affect visible filters
			//accordion or colapisblepanel visibility
			var visible = collapsible.is(':visible');
			// when closing the filter (_lastmode = Search), hide filter panel
			if ((!visible && this._lastmode !== 'SEARCH') || this._view != view || block.task != Frames.Application.task)
			{
				return;
			}

			Frames.Application.trigger('filterpanelupdate');
			var mode = block.props('blockMode');
			var filterMode = Frames.isTrue(this._alreadyOpened) ? Frames.isTrue(block.props('IsInFilterMode')) && mode !== 'SEARCH' : false;

			var forceclear = mode != 'SEARCH' && 
				!collapsible.hasClass('is-collapsed') && ( // do not force clear if collapsible panel or accordion is collapsed
					(block._lastmode != mode && !filterMode) || // not in 'filter again' mode
					(block._lastmode === mode && !this.element.parent().is(':visible')) || // parent not visible
					(!filterMode && this._buttonFilterAgain.is(':visible')) ||
					(!filterMode && this._buttonFilterAgainMiddleDiv.is(':visible'))// not in 'filter again' mode but filter again is visible
			);

			if (block._lastmode == 'SEARCH' && mode !== 'SEARCH' || this._go) 
			{
				delete this._last_selid;
			}

			if (mode === 'SEARCH')
			{
				if (!Frames.isUndef(this._last_selid) && Frames.isTrue(block._clear))
				{
					block._selid = block._selid || this._last_selid;
					if (this._last_selid !== block._selid)
					{
						this.clear();
						if (this._version2)
						{
							this._addDefaultItems();
						}
					}
				}
				this._last_selid = block._selid;
			}

			if (forceclear)
			{
				// re-ocurring bind out of search mode, reset/hide filter panel if hidden
				this.close(true);
			}

			if (block._lastmode != mode || filterMode)
			{
				if (filterMode)
				{
					if (mode !== 'SEARCH')
					{
						// If it is in filterAgainMode and the filter panel hasn't been inicialized yet
						if (!this._initialized)
						{
							this._build();
						}
						if (!this._version2)
						{
							this._buttonFilterAgain.css('display', '');
						}
						else
						{
							this._buttonFilterAgainMiddleDiv.css('display', '');
						}
						this.show();

						if (this._version2)
						{
							this.element.addClass('ui-advancedFilterAgain');
							this._filterAgainValues();
						}
						else
						{
							this._advancedFilter_middleDiv.hide();
						}

						this._templateAdvancedFilter_h3DownPanel.hide();
						if (this._version1)
						{
							this.$content.show();
						}
					}
					else
					{
						this.filteragain(this._keepfilter);
						if (this._version1)
						{
							this.$content.hide();
						}
					}
				}
				else
				{
					// If filteragain button has been clicked in other canvas this._keepfilter can be undefined but we want to keep the criterias
					var keepCriterias = this._keepfilter || this._buttonFilterAgain.is(':visible') || this._buttonFilterAgainMiddleDiv.is(':visible');

					if (!this._version2)
					{
						this.hide();
					}

					this.filteragain(keepCriterias);

					if (mode == 'SEARCH')
					{
						this.open();
					}
				}

				block._lastmode = mode;
				this._lastfilter = filterMode;

			}
			else if (mode == 'SEARCH')
			{
				var curr = Frames.Application.current();
				curr = curr ? curr.member : '';
				// This filter instance has the focus
				var hasFocus = !Frames.isEmpty(this._ITEMS_) ? this._ITEMS_.indexOf(curr) > -1 : false;

				if (this._go || hasFocus)
				{
					// restore extensions when filter doesn't return results
					this._restoreExtensions();
				} else
				{
					this._createContent();
				}
			}

			if (mode == 'SEARCH')
			{
				Frames.focus.callback = function()
				{
					var lov = Frames.get('filterLov', null, Frames.Dialog.LOV.view);
					if (Frames.isUndef(lov))
					{
						if (that._version2)
						{
							var block = that.getBlock();
							// FRAMES-1941 - if not in search mode, ignore this callback and restart focus process
							if (block.props('blockMode') !== 'SEARCH')
							{
								Frames.focus(Frames.Application.task, true);
							}
							else
							{
								that.focus();
							}
						}

						// force toolbar refresh on collapsiblepanel after focus on filter
						var collapsiblePanel = that.element.closest('[data-widget="collapsiblepanel"],[data-widget="accordion"]');
						if (collapsiblePanel.length > 0 && !Frames.isEmpty(collapsiblePanel.attr('id')))
						{
							var collapsibleItem = Frames.get(collapsiblePanel.attr('id'));
							collapsibleItem._toolbar_fn();
						}
					}
					else
					{
						lov.input().focus();
					}
				};
			}

			this._restoreOriginalItems();
			this._go = false;
		},

		unregisterExtensions: function()
		{
			if (!Frames.isUndef(this._EXTRA_))
			{
				var block = this.getBlock();
				if (!Frames.isUndef(block))
				{
					this._EXTRA_.reset();
					while (this._EXTRA_.hasNext())
					{
						var item = this._EXTRA_.next()
						if (block._BINDS_.indexOf(item) != -1)
						{
							block._BINDS_.remove(item);
						}
						else
						{
							block._BINDS_.remove(item.objid());
						}
					}
				}
			}
		},

		_restoreExtensions: function()
		{
			if (!Frames.isUndef(this._EXTRA_))
			{
				var block = this.getBlock();
				if (!Frames.isUndef(block))
				{
					this._EXTRA_.reset();
					while (this._EXTRA_.hasNext())
					{
							block.bindable(this._EXTRA_.next());
					}
				}
			}
		},

		_restoreOriginalItems: function()
		{
			var that = this;
			// Restore original items that were extensions in previous opened filters
			if (!Frames.isUndef(that._ITEMS_))
			{
				var block = this.getBlock();
				if (block)
				{
					_$.each(that._ITEMS_, function(i, member)
					{
						// TODO use other way to get FilterItem objid
						var key = Frames.Application.task.view.id + ':ext-' + member.toLocaleLowerCase();
						var ext = block.getbnd(key);
						if (!Frames.isUndef(ext))
						{
							// Item was previous registered as extension
							// keep the extension and unbind the original if exists
							var original = block.get(member);
							if (!Frames.isUndef(original))
							{
								block._BINDS_.remove(original.objid());
							}
						}
					});
				}
			}
		},

		filteragain: function(keep)
		{
			if (keep)
			{
				// keep filter options
				this._clearSearch();
				this.focus();
			}
			else
			{
				this.clear();
			}
		},

		close: function(clear)
		{
			if (this._version2)
			{
				if (!this._alreadyOpened)
				{
					return;
				}
				this.element.removeClass('ui-advancedFilterAgain ui-advanced-filter-mode ui-basic-filter-mode');
			}

			this.hide();

			if (clear)
			{
				this.clear();
			}

			if (this._version2)
			{
				this._alreadyOpened = false;
				delete this._filterAgainMode;
				delete this._lastfilter;
			}
		},

		open: function()
		{
			if (this._version2)
			{
				if (this._alreadyOpened)
				{
					return;
				}
				this._alreadyOpened = true;
				delete this._keepfilter;
			}

			// Toggle between simple and multi view has to change the filter "content"
			this.$content = this.element.next();

			this._createContent();

			this.show();

			if (this._version2)
			{
				var templateSelect = this._templateAdvancedSearchMiddleDiv.find('select.fieldSelect');
				var fieldSelect = this._advancedFilter_middleDiv.find('.selectFilter.fieldSelect');

				if (templateSelect.width() === 0)
				{
					templateSelect.css('width', fieldSelect.outerWidth());
					fieldSelect.css('width', fieldSelect.outerWidth());
				}

				if (!this._filterAgainMode)
				{
					this._addDefaultItems();
				}

				delete this._filterAgainMode;
			}
			else
			{
				this._alreadyOpened = true;
			}
		},

		_filterAgainValues: function()
		{
			var that = this;
			this._advancedFilter_middleDiv.children('.cloned')
				.each(function() {

					var el = $(this).find('input.selectInformation, button.selectInformation');
					var opt = $(this).find('.fieldCriteria option:selected');
					var query = opt.data('query');
					var criteria = opt.text();
					var hasMultipleElements = false;

					//we can have multiple elements, like on between
					var elem = el;
					if (el.length > 1)
					{
						elem = elem.eq(0);
						hasMultipleElements = true;
					}

					var item = elem.parent();
					var widget = item.data('widget');
					var type = item.data('type');
					var val;
					var span = $(this).find('.ui-input-readonly');
					var hasCriteria = $(this).find('.ui-field-criteria');
					var dir;

					if (type == 'Date' && Frames.Locale.formats.IS_RTL && Frames.Locale.formats.DATE_IS_RTL)
					{
						dir = 'rtl';
					}
					else
					{
						dir = 'ltr'
					}

					if (widget === 'radiogroup')
					{
						var value = item.find('> input').val();
						if (!Frames.isEmpty(value))
						{
							var radio = item.find('input[value="' + value + '"]');
							val = radio.parent().find('label').text();
						}
					}
					else if (widget === 'checkbox')
					{
						var $sp = item.find('> button > .ui-button-icon');
						if ($sp.length > 0)
						{
							var isChecked = $sp.hasClass('fa-check');
							if (isChecked)
							{
								val = _(Frames.Locale.messages.CHECKED); 
							}
							else
							{
								val = _(Frames.Locale.messages.UNCHECKED);
							}
						}
					}
					else
					{
						val = elem.val();
						if (criteria === 'Between' && !that._isBasicMode())
						{
							var elem1 = el.eq(1);
							var item1 = elem1.parent();
							var widget1 = item1.data('widget');
							var val1 = elem1.val();
							if (!Frames.isEmpty(val) && !Frames.isEmpty(val1))
							{
								val = val + ' ' + _(Frames.Locale.messages.AND) + ' ' + val1;
							}
						}
					}

					if (Frames.isEmpty(val))
					{
						if (Frames.isTrue(query, true))
						{
							item.parent().css('display', 'none');
						}
						else
						{
							val = criteria;
						}
					}

					if (span.length === 0)
					{
						//XSS prevention
						span = $('<span class="ui-input-readonly" ' + (Frames.isEmpty(dir) ? '' : ' dir="' + dir + '"') + '></>').appendTo($(this).find('.ui-widget:not(.ui-radiobox):not(.ui-button)').eq(0));
						span.text(val);
						if (elem.css('text-transform') != 'none')
						{
							span.css('text-transform', elem.css('text-transform'));
						}
					}
					else
					{
						span = $(this).find('.ui-input-readonly');
						span.text(val);
					}

					if (hasMultipleElements)
					{
						var elems = $(this).find('[data-widget]');
						for (var i = 0; i < elems.length; i++)
						{
							var $el = $(elems[i]);
							$el.removeClass('hide-widget');
							if ($($el).find('span.ui-input-readonly').length == 0)
							{
								$el.addClass('hide-widget');
							}
						}
					}

					if ($(this).closest('.ui-filterpanel').hasClass('ui-advanced-filter-mode'))
					{
						if (hasCriteria.length === 0)
						{
							$('<span class="ui-field-criteria">' + '(' + criteria + ')' + '</>').insertBefore(span);
						}
						else
						{
							var criteria = '(' + criteria + ')';
							$(this).find('.ui-field-criteria').text(criteria);
						}
					}
					else
					{
						if (hasCriteria.length > 0)
						{
							$(this).find('.ui-field-criteria').text('');
						}
					}
				});
		},

		_createContent: function()
		{
			var that = this;
			var block = this.getBlock();
			var opt, i, len;
			var order = 0;
			var sel = this._templateAdvancedSearchMiddleDiv.find('select.fieldSelect');

			// reset options
			$('option:not([value=\'\'])', sel).remove();

			if (this._version2)
			{
				if (!this._filterAgainMode)
				{
					this.element.addClass('ui-basic-filter-mode').removeClass('ui-advancedFilterAgain ui-advanced-filter-mode');
				}
			}

			var items = this._getQueryItems();

			items = this._sortItems(items);

			for (i = 0, len = items.length; i < len; i++)
			{
				var item = items[i];

				if (this.getBlock() != item.block || (!this._searchable(item) && !this._sortable(item)) ||
					(Frames.isFalse(item.props('Visible')) ||
					(Frames.isUndef(item._isextension, false) && Frames.isFalse(item.visible()))))
				{
					// skip
					continue;
				}

				opt = that.newoption(sel, item.label() || '[ITEM ' + (i + 1) + ']', item.member);
				// keep a field order
				opt.attr('data-order', order++);

				var colCtx = item._col;
				// If it's an dtagrid item we need to map the column properties
				if (colCtx)
				{
					// XXX this properties should pass to column item context??
					if (colCtx.editorType !== undefined)
					{
						opt.attr('data-editor', colCtx.editorType);
					}
					if (colCtx.type !== undefined)
					{
						opt.attr('data-type', colCtx.type);
					}
					if (colCtx.format !== undefined && !colCtx.formatDefault)
					{
						opt.attr('data-format', colCtx.format);
					}
					if (colCtx.editorType === 'checkbox')
					{
						colCtx.value === null ? opt.data('valueisnull', true) : opt.data('value', colCtx.value);
						colCtx.fvalue === null ? opt.data('fvalueisnull', true) : opt.data('fvalue', colCtx.fvalue);
					}
					else if (colCtx.editorType === 'combobox' && colCtx.data)
					{
						opt.attr('data-data', encodeURIComponent(JSON.stringify(colCtx.data)));
					}

					var colProps = colCtx.props;
					for (var p in colProps)
					{
						if (colProps.hasOwnProperty(p))
						{
							opt.attr('data-' + p, colProps[p]);
						}
					}
				} else
				{
					var formatType = item.props('type') || 'String';
					var editorType = item.props('Editor');
					if (Frames.isEmpty(editorType))
					{
						switch (item.widgetcls())
						{
							case 'datefield':
								editorType = 'calendar';
								break;
							case 'checkbox':
								editorType = 'checkbox';
								break;
							case 'lovinput':
								editorType = 'lovbox';
								break;
							case 'combobox':
								editorType = 'combobox';
								break;
							case 'radiogroup':
								editorType = 'radiogroup';
								break;
							default:
								editorType = 'textinput';
						}
					}

					opt.attr('data-editor', editorType);

					var input = item.input();
					if (input && input[0] && input.is('input'))
					{
						opt.attr('data-width', item.input()[0].style.width);
					}

					if (item.props('type') !== undefined)
					{
						opt.attr('data-type', formatType);
					}

					if (item.props('format') !== undefined && !item.props('formatDefault'))
					{
						opt.attr('data-format', item.props('format'));
					}

					if (editorType === 'checkbox')
					{
						var v = item.tvalue();
						var f = item.fvalue();
						v === null ? opt.data('valueisnull', true) : opt.data('value', v);
						f === null ? opt.data('fvalueisnull', true) : opt.data('fvalue', f);
					}
					else if (editorType === 'radiogroup' && typeof item.dataModel === 'function')
					{
						opt.attr('data-data', encodeURIComponent(JSON.stringify(item.dataModel(true))));
					}
					else if (editorType === 'combobox' && typeof item.dataModel === 'function')
					{
						opt.attr('data-data', encodeURIComponent(JSON.stringify(item.dataModel())));
					}

					if (item.restrictCase() !== undefined)
					{
						opt.attr('data-case', item.restrictCase());
					}
					if (item.props('minlength') !== undefined)
					{
						opt.attr('data-minlength', item.props('minlength'));
					}
					if (item.props('maxlength') !== undefined)
					{
						opt.attr('data-maxlength', item.props('maxlength'));
					}
					if (item.props('minvalue') !== undefined)
					{
						opt.attr('data-minvalue', item.props('minvalue'));
					}
					if (item.props('maxvalue') !== undefined)
					{
						opt.attr('data-maxvalue', item.props('maxvalue'));
					}
				}
			}

			if (this._version2 && !this._initialized)
			{
				var filterSwitch = $('<span />')
					.addClass('filter-switch')
					.prependTo(this._templateAdvancedFilter_h3UpPanel);

				$('<a href="javascript:;">' + _(Frames.Locale.messages.FILTER_BASIC_MODE) + '</a>')
					.addClass('ui-basic-mode')
					.appendTo(filterSwitch);

				$('<a href="javascript:;">' + _(Frames.Locale.messages.FILTER_ADVANCED_MODE) + '</a>')
					.addClass('ui-advanced-mode')
					.appendTo(filterSwitch);
			}

			// store a full copy
			this.__fieldSelectTmpl = sel.clone(true);

			this._build();
		},

		_isBasicMode: function()
		{
			return this._version2 && this.element.hasClass('ui-basic-filter-mode');
		},

		_hideAddField: function()
		{
			var $lastrow = this._advancedFilter_middleDiv.find('.middleDivRow:not(.cloned)');
			if ($lastrow.find('select.fieldSelect').children().length == 1)
			{
				$lastrow.hide();
				return true;
			}
			return false;
		},

		focus: function()
		{
			var block = this.getBlock();
			var curr = Frames.Application.current();
			if ((Frames.isUndef(curr) || block === curr.block) && block.props('blockMode') === 'SEARCH')
			{
				if (this._version2)
				{
					var it = block._filterItem ? block._filterItem : block._FILTER_ ? block._FILTER_.get(block.item.member) : undefined;
					var elem;
					if (it)
					{
						elem = it;
					}
					else
					{
						// FIX: this could be basic
						elem = this._advancedFilter_middleDiv.find('.selectFilter').last();
					}
					Frames.later(function()
					{
						var noAlerts = Frames.isFunction(Frames.Workspace.hasAlerts) && !Frames.Workspace.hasAlerts();
						if (noAlerts)
						{
							elem.focus();
						}
					});
				}
				else
				{
					this._advancedFilter_middleDiv.find('.selectFilter').last().focus();
				}
			}
		},

		_sortItems: function(items)
		{
			var $grids = $('table[data-direction=\'column\']:not(.ui-repeater-render table)', this.$content);

			if ($grids.length === 0)
			{
				return items;
			}

			// td object cache
			var $td = {};

			var arr = _$.map(items, function(obj, idx)
			{
				// XXX: this works if there's no nested grids with direction="column", which shouldn't happen anyway
				var $grid = obj.elem.closest($grids);
				var table = $grid[0] ? $grids.index($grid) : null;

				if (table !== null && !$td[table])
				{
					$td[table] = $grid.find('> tbody > tr > td');
				}

				var $cell = table !== null ? obj.elem.closest($td[table]) : $();
				var $row = $cell[0] ? $cell.parent() : $();

				return {
					elem: obj,
					idx: idx,
					table: table,
					cellIdx: $cell[0] ? ($cell.index() * 10000) + $row.index() : -1
				};
			});

			// try to sort the items according to the vertical navigation pattern
			arr = arr.sort(function(a, b)
			{
				if (a.table === null || b.table === null)
				{
					return a.idx - b.idx;
				}

				if (a.table === b.table)
				{
					if (a.cellIdx === b.cellIdx)
					{
						return a.idx - b.idx;
					}

					if (a.cellIdx < b.cellIdx)
					{
						return -1;
					}

					return 1;
				}

				if (a.table < b.table)
				{
					return -1;
				}

				return 1;
			});

			items = _$.map(arr, function(obj, idx)
			{
				return obj.elem;
			});

			return items;
		},

		_getQueryItem: function(item,itemsMap)
		{
			var that = this;
			if (Frames.isUndef(item))
			{
				return itemsMap;
			}
			if (Frames.isUndef(itemsMap))
			{
				itemsMap = new Frames.HashMap();
			}

			if (item.widgetcls() === 'datagrid')
			{
				var cols = item.columns();

				for (i = 0, len = cols.length; i < len; i++)
				{
					var c = cols[i];

					if (c.visible === false)
					{
						// skip
						continue;
					}

					if (typeof item.getItemContext === 'function')
					{
						var itemContext = item.getItemContext(c.field);

						if (itemContext)
						{
							var searchable = this._searchable(itemContext);
							var sortable = this._sortable(itemContext);

							if (!searchable && !sortable)
							{
								// skip
								continue;
							}

							itemsMap.put(itemContext.member,itemContext);
							that._ITEMS_.push(itemContext.member);
						}
					}

				}

			} else
			if (item.widgetcls() === 'repeater')
			{
				_$.each(item.getItems(), function(i, it)
				{
					itemsMap.put(it.member, it);
					that._ITEMS_.push(it.member);
				});
			} else
			if (!Frames.isUndef(item.bindable()) && item.bindable().widgetcls() === 'repeater')
			{
				// HACK Avoid duplicated items. Repeater will return is own items.
				// This occurs when repeater items has also data-block attribute in the html. This should not occur!
				return itemsMap;
			} else
			{
				if (this._searchable(item) || this._sortable(item))
				{
					itemsMap.put(item.member,item);
					that._ITEMS_.push(item.member);
				}
			}
			return itemsMap;
		},

		_getQueryItems: function()
		{
			var that = this;
			var items = new Frames.HashMap();
			// extension items
			this._EXTRA_ = new Frames.HashMap();
			// own content items ( block visible items ). Only store the members
			this._ITEMS_ = [];
			var block = this.getBlock();
			var view = Frames.Application.task.view;

			if (this.options.popup)
			{
				var _items = block.getRegisteredItems();
				_items.reset();
				while (_items.hasNext())
				{
					items = that._getQueryItem(_items.next(),items);
				}
			}
			else
			{
				// search content descendant items with same block (excluding buttons)
				$('[data-block=\'' + block.name + '\']:not([data-widget="button"])', this.$content).each(function()
				{
					var $el = $(this);

					var member = $el.data('member');

					var item = member ? block.get(member) : $el.data('frames');

					if (item)
					{
						items = that._getQueryItem(item,items);
					} else
					if (!Frames.isUndef(member))
					{
						// XXX It's needed? Or these items come all as extension items?

						// get items from block that are from the same view
						var isExt = block.getextitem(member);
						if (!Frames.isUndef(isExt))
						{
							// Avoid duplicated items on filter. If it is a extension item will be posteriorly added to queryItems in the open method.
							return;
						}
						var itemNode = Frames.findSingle(block._ctrinf, 'item', member);

						if (that._searchable(itemNode) || that._sortable(itemNode))
						{
							item = new Frames.FilterItem(member, block);

							var $lbl = $el.children('label');
							item.label($lbl.text());

							items.put(item.member, item);
							that._EXTRA_.put(item.member, item);
						}
					}
				});
			}

			// append extension items
			var _items = block.getextitem();
			_$.each(_items, function(i, n)
			{
				if (!Frames.isUndef(items.get(n)))
				{
					// Avoid duplicated items on filter
					// Don't process 'normal' items twice if they also come like extension item.
					return;
				}
				var ext = block.getextitem(n);
				if (!Frames.isUndef(ext) && ext.ViewMode == 'Filter')
				{
					it = new Frames.FilterItem(n, block, ext);
					items.put(it.member,it);
					that._EXTRA_.put(it.member,it);
				}
			});

			return items.values();
		},

		show: function()
		{
			if (this._version1)
			{
				this.$content.hide();
			}

			if (Frames.Application.task.opening)
			{
				this.element.show();
				this.focus();
			}
			else if (this.element.parent().is(':visible'))
			{
				this.element.slideDown(this.options.toggle);
				this.focus();
			}
			else
			{
				this.element.show();
			}
		},

		hide: function()
		{
			var hideFast = Frames.Application.task._processing;
			if (this.element.parent().is(':visible') && !hideFast)
			{
				this.element.slideUp(this.options.toggle);
			}
			else
			{
				this.element.hide();
			}

			if (this._version1)
			{
				this.$content.show();
			}
		},

		_create: function()
		{
			var that = this;
			this._creating = true;

			this.element.addClass('ui-widget ui-filterpanel');

			this.$content = this.element.next();

			// create an unique id for this instance
			this.instanceId = Frames.uuid();

			this.element.hide();

			this._onEndBind = _$.proxy(this.onEndBind, this);
			this._onStartBind = _$.proxy(this.onStartBind, this);
			this._restartFilter = _$.proxy(this.restartFilter, this);

			Frames.Application.on('startover.filterpanel_' + this.instanceId, this._restartFilter);

			this._initTemplateAdvancedSearchMiddleDiv();
			this._initTemplateAdvancedFilterDiv();

			this._TemplateAdvancedFilterDiv.appendTo(this.element);

			this.element.on('keydown', function(ev)
			{
				var $target = $(ev.target);
				var key = Frames.Keys.string(ev);

				if ($target.is('.selectInformation') && ev.keyCode == _$.ui.keyCode.ENTER)
				{
					var $go = that._templateAdvancedFilter_h3DownPanel.find('.ui-buttonGo');
					$go.trigger('click.GO');
					return false;
				}

				if (ev.keyCode == _$.ui.keyCode.ESCAPE)
				{
					that.exit();
				}

				if ($target.hasClass('ui-erasecombotext') && key === 'SHIFT+TAB')
				{
					var $el = $target.parent().find('.ui-widget');
					var item = $el.data('frames');
					if (!Frames.isUndef(item))
					{
						// in accessibility mode, always navigate to the button if it exists
						if (Frames.Navigation.mode() === 'all')
						{
							var $btn = $el.children('button');
							if ($el.hasClass('ui-textinput') && $btn.length > 0)
							{
								$btn.focus();
							}
							else
							{
								item.processNavigationPrevious();
							}
							ev.preventDefault();
							ev.stopImmediatePropagation();
							return false;
						}
						// in default mode, always navigate to the input if it exists
						else
						{
							var $inp = $el.children('input');
							if ($inp.length > 0)
							{
								$inp.focus();
								ev.preventDefault();
								ev.stopImmediatePropagation();
								return false;	
							}
						}
					}
				}
			});

			if (this.options.bindable)
			{
				this.bindable(this.options.bindable);
			}

			if (this._bindable)
			{
				var block = this.getBlock();
				block.$content = this.$content;
			}

			this._creating = false;
		},

		_current: Frames.Application.current,

		restartFilter: function()
		{
			//reset block data
			if (this._initialized)
			{
				var block = this.getBlock();
				if (block.task != Frames.Application.task)
				{
					return;
				}

				var data = Frames.Model.createEmptyBlockData('block', {name: block.name, hasChanges: 'true'});

				//reset pagination
				if (!Frames.isUndef(block.paging))
				{
					var pagerCtrl = _$.xmlToJSON('<page enabled="false" pageNumber="1" pageSize="1" totalPages="1" totalRecords="1" />');
					var page = [pagerCtrl];

					block.paging.controlInfo(page[0]);
				}

				//force block bind on start over click
				block._clear = true; 
				block.model(data);
				delete block._clear;
				this.close(true);
				this.filteragain(false);
				delete block._lastmode;
				delete this._last_selid;
				this.unregisterExtensions();
			}
		},

		_build: function()
		{
			if (this._initialized)
			{
				if (this._keepfilter)
				{
					delete this._keepfilter;

					// hide row if there are no more fields to filter
					this._hideAddField();
				}
				else
				{
					// update with template
					this._advancedFilter_middleDiv.find('select.fieldSelect').last()
							.replaceWith(this._templateAdvancedSearchMiddleDiv.find('select.fieldSelect').clone());

					// replaceWith returns the removed elements
					var $lastSelect = this._advancedFilter_middleDiv.find('select.fieldSelect').last();

					if (!Frames.isEmpty(this.__selectedFields))
					{
						_$.each(this.__selectedFields, function(index, element)
						{
							// remove pre-existing fields
							$lastSelect.find('option[value="' + element + '"]').remove();
						});
					}

					_$.each(this._getSelectedFields(), function(index, element)
					{
						// Disable already chosen fields ( in other filters)
						$lastSelect.find('option[value="' + element + '"]').attr('disabled','disabled');
					});

					this._advancedFilter_middleDiv.find('.middleDivRow:not(.cloned)').show();
				}
				return;
			}

			// Construction of html filter
			var that = this;

			this._appendNewAdvFilterRow(false);

			// Hide filter pressing close button in Advanced filter
			$('.ui-buttonCloseBasicFilterPanel, .ui-buttonCloseBasicFilterPanelMiddleDiv, .ui-buttonClearAllMiddleDiv', this.element).on('click', _$.proxy(function(event)
			{
				var block = this.getBlock();
				var mode = block.props('blockMode');

				if (mode !== 'SEARCH')
				{
					this._exitFilter = true;
					Frames.FilterPanel.execute('EXECUTE_QUERY', undefined, this);
				}
				else 
				{
					if ($(event.target).parents('.ui-buttonCloseBasicFilterPanel').length > 0)
					{
						this.exit(true);
					}
					else
					{
						this.exit();	
					}
				}

				return false;
			}, this));

			$('.ui-buttonFilterAgain, .ui-buttonFilterAgainMiddleDiv', this.element).on('click', _$.proxy(function(event)
			{
				if (this._version1)
				{
					this._keepfilter = true;

					try
					{
						var curr = $(document.activeElement).data('frames');
						if (!Frames.isUndef(curr))
						{
							Frames.Application.current = function()
							{
								return curr;
							};
						}
					}
					catch (e)
					{}
				}

				try
				{
					Frames.FilterPanel.execute('SEARCH', undefined, this);
				}
				finally
				{
					Frames.Application.current = this._current;
				}

				return false;
			}, this));

			this._advancedFilter_middleDiv.on('click', '.ui-erasecombotext, .ui-erasecombotext-filteragain', function(event)
			{
				var $row = $(this).parent();

				var val = $row.find('.fieldSelect option:selected').val();

				// Enable previous option in other filters
				that._disableFilterOption(val);

				// clear any existing validation
				that._clearItems($row);
				$row.remove();

				// add removed option to existing fieldSelects
				that._advancedFilter_middleDiv.find('.middleDivRow .fieldSelect').each(function()
				{
					var $opt = $(this).find('option[value="' + val + '"]');
					// Enable option if already exist or add a new entry
					if ($opt.length > 0)
					{
						$opt.removeAttr('disabled');
					} else
					{
						that._addFilterOption($(this), val);
					}
				});

				// restore last row for adding new field options
				if ($(this).hasClass('ui-erasecombotext'))
				{
					that._advancedFilter_middleDiv.find('.middleDivRow:not(.cloned)').show();
				}

				that.__selectedFields.splice(that.__selectedFields.indexOf(val), 1);

				that.focus();

				if (that._version2 && $(this).hasClass('ui-erasecombotext-filteragain'))
				{
					if (that._advancedFilter_middleDiv.find('.middleDivRow.cloned:visible').length > 0)
					{
						that._exitFilter = true;
						that._executeQuery(undefined, 'REQUERY');
					}
					else
					{
						that.exit();
					}
				}

				return false;
			});

			this._advancedFilter_middleDiv.on('click', '.ui-criteriaup', function(event)
			{
				var $row = $(this).parent();
				$row.insertBefore($row.prev());

				that._redrawPosIcons();
			});

			this._advancedFilter_middleDiv.on('click', '.ui-criteriadown', function(event)
			{
				var $row = $(this).parent();
				$row.insertAfter($row.next());

				that._redrawPosIcons();
			});

			// removes all lines in advanced filter
			this._templateAdvancedFilter_h3DownPanel.on('click', '.ui-buttonClearAll', function(event)
			{
				that.clear();
				return false;
			});

			// apply filters
			this._templateAdvancedFilter_h3DownPanel.on('click.GO','.ui-buttonGo', function(event)
			{
				var query = that.getQuery();
				that._executeQuery(query);
				return false;
			});

			// just present on advanced mode filter
			this._templateAdvancedFilter_h3UpPanel.on('click', '.ui-advanced-mode', function(event)
			{
				that._toAdvancedMode();
			});

			this._templateAdvancedFilter_h3UpPanel.on('click', '.ui-basic-mode', function(event)
			{
				$(this).closest('.ui-filterpanel')
					.addClass('ui-basic-filter-mode')
					.removeClass('ui-advanced-filter-mode');

				that._applyCriteriaToBasicMode();
			});

			this._initialized = true;
		},

		_addDefaultItems: function()
		{
			var block = this.getBlock();
			if (!block._FILTER_)
			{
				block._FILTER_ = new Frames.HashMap();
			}
		
			// focus on the first row
			var focus = true;
			var filterMode = !Frames.isEmpty(block._exts['FilterMode']) ? 
				block._exts['FilterMode'] : this._isBasicMode() ? 'basic' : 'advanced';

			var createDefaults = false;
			var items = this._getPUPItems();
			if (Frames.isUndef(items))
			{
				items = this._getQueryItems();
				createDefaults = true;
			}

			for (var i = 0; i < items.length; i++)
			{
				var item = items[i];
				var format = item.props('format');
				var type = item.props('type') || 'String';

				var ext = item._exts;
				if (!Frames.isUndef(ext.FilterDefaultValue))
				{
					var row = this._addNewRow(item.member, focus);
					focus = false;
					var it = row.find('input.selectInformation, button.selectInformation').data('frames');
					var decodedValue = _$.decodeHtml(ext.FilterDefaultValue);
					var v;

					var ast = Frames.Query.parse(decodedValue);
					if (ast.criteria)
					{
						var vals = _$.map(ast.values, function(v)
						{
							return Frames.Format.formatFromCanonical(v,  format, type);
						});

						v = Frames.Query.reverse(ast.criteria, ast.modifier, vals);
						if (filterMode == 'advanced' && this._version2)
						{
							if (ast.criteria == 'LIKE' || ast.criteria == 'STARTSWITH' || ast.criteria == 'ENDSWITH' || ast.criteria == 'CONTAINS')
							{
								v = '#' + ast.criteria + ' ' + v;
							}
						}
					}
					else
					{
						v =  Frames.Format.formatFromCanonical(decodedValue,  format, type);
					}

					it.value(v);
				}
			}

			if (createDefaults && this._advancedFilter_middleDiv.find('.middleDivRow.cloned').length === 0)
			{
				var fields = this._advancedFilter_middleDiv.find('select.fieldSelect').children();
				var len = fields.length >= 6 ? 6 : fields.length;
				for (i = 1; i < len; i++)
				{
					var field = fields[i];
					this._addNewRow(field.value, focus);
					focus = false;
				}
			}

			// hide row if there are no more fields to filter
			this._hideAddField();

			if (block._exts['FilterMode'] == 'advanced')
			{
				this._toAdvancedMode(true);
			}

			block.setInitialFilterModel();
		},

		_getPUPItems: function()
		{
			var blk = this.getBlock();
			var itemorder = blk._exts['FilterItemsOrder']
			if (!Frames.isUndef(itemorder))
			{
				itemorder = JSON.parse(itemorder);

				var items = [];
				for (var i in itemorder)
				{
					var member = itemorder[i];

					// ES-2839 - Don't add items that are not in the filter currently
					if (this._ITEMS_.indexOf(member) == -1 && Frames.isUndef(this._EXTRA_.get(member)))
					{
						continue;
					}

					var item = blk._ITEMS_.get(member);
					if (Frames.isUndef(item))
					{
						item = this._EXTRA_.get(member);
					}
					if (!Frames.isUndef(item))
					{
						items.push(item);
					}
					else if (Frames.isDebugMode())
					{
						console.log('Warning: Filter Item ' + member + ' not found in _ITEMS_ or _EXTRA_ objects');
					}
				}
				return items;
			}
			else
			{
				return null;
			}
		},

		_toAdvancedMode: function(init)
		{
			this.element.addClass('ui-advanced-filter-mode').removeClass('ui-basic-filter-mode');
			this._applyCriteriaToAdvancedMode(init);
		},

		_addNewRow: function(item, focus)
		{
			var newrow = this._appendNewAdvFilterRow();
			var fieldSelect = newrow.find('.selectFilter.fieldSelect');
			fieldSelect.val(item);
			var row = this._rowChanged(fieldSelect, focus);
			this._removeFilterOption(this._advancedFilter_middleDiv.find('.middleDivRow:not(.cloned)'), item);
			return row;
		},

		_applyCriteriaToBasicMode: function()
		{
			var rows = this._advancedFilter_middleDiv.find('.middleDivRow.cloned');
			if (rows.length > 0)
			{
				for (var i = 0; i < rows.length; i++)
				{
					var row = $(rows[i]);
					var option = row.find('.fieldCriteria option:selected');
					var criteria = option[0].value;
					var isEmptyVal = criteria === '#IS NULL' || criteria === '#IS NOT NULL' ||
						criteria === '#IS NULL #OR <>' || criteria === '#IS NULL #OR <' ||
						criteria === '#IS NULL #OR >';

					var elem = row.find('input.selectInformation, button.selectInformation');
					var $el = elem;
					//we can have multiple elements, like on between
					if (elem.length > 1)
					{
						$el = elem.eq(0);
					}

					var item = $el.data('frames');
					if (item)
					{
						Frames.Validation.reset(item);
					}

					if (criteria === '#IS NULL' || criteria === '#IS NOT NULL')
					{
						//this._selectedInformationTmpl(row);
						row.find('[data-widget]').removeClass('hide-element');
					}

					var widget = $el.parent().data('widget');
					if (widget === 'textinput' || widget === 'lovinput' || widget === 'datefield' || widget === 'combobox')
					{
						var val = $el.val();
						if (!Frames.isEmpty(val) || isEmptyVal || criteria === '#BETWEEN')
						{
							$el[0].removeAttribute('maxlength');
							if (criteria === '#LIKE')
							{
								var prefix = Frames.isUndef(option.data('prefix')) ? '' : option.data('prefix');
								var suffix = Frames.isUndef(option.data('suffix')) ? '' : option.data('suffix');
								$el.val(prefix + val + suffix);
							}
							else if (criteria === '#BETWEEN')
							{
								//row.find('[data-widget]').remove().end().find('.selectInformation').remove();
								var $el1 = elem.eq(1);
								var item1 = $el1.parent();
								var val1 = $el1.val();
								if (!Frames.isEmpty(val) && !Frames.isEmpty(val1))
								{
									$el = $el1;
									$el.val(criteria + ' ' + val + ' and ' + val1);
								}
								row.find('[data-widget]').eq(0).remove();
								row.find('span.selectInformation').remove()
							}
							else if (criteria === '=')
							{
								val = /^\s+|\s+$/.test(val) ? "'" + val + "'" : val;
								$el.val(val);
							}
							else
							{
								if (!Frames.isEmpty(val))
								{
									val = /^\s+|\s+$/.test(val) ? "'" + val + "'" : val;
									$el.val(criteria + val);
								}
								else
								{
									$el.val(criteria);
								}
							}
						}
					}
				}
			}
		},

		_applyCriteriaToAdvancedMode: function(init)
		{
			var block = this.getBlock();
			var rows = this._advancedFilter_middleDiv.find('.middleDivRow.cloned');
			if (rows.length > 0)
			{
				for (var i = 0; i < rows.length; i++)
				{
					var row = $(rows[i]);
					var member = row.find('select.fieldSelect').children('option:selected').attr('value');
					var item = block.get(member) || block.getextitem(member);
					var inp = row.find('input.selectInformation, button.selectInformation');
					var framesIt = inp.data('frames');
					var widget = inp.parent().data('widget');
					var searchOps;

					//just run this code when switching from basic to advanced. not when opening in advanced mode
					if (item && Frames.isUndef(init))
					{
						searchOps = item.extensions ? item.extensions('VALID_SEARCH_OPERATORS') : item.VALID_SEARCH_OPERATORS;
						if (searchOps && searchOps.indexOf('#LIKE') != -1)
						{
							searchOps = searchOps.replace('#LIKE', '#ILIKE');
						}
					}

					if (widget === 'textinput' || widget === 'lovinput' || widget === 'datefield' || widget === 'combobox')
					{
						var val = inp.val();
						var ast = Frames.Query.parse(val);
						var cmd = ast.criteria;
						var mod = ast.modifier;
						var vals = ast.values;
						var isValidOperator = !Frames.isUndef(searchOps) && !Frames.isUndef(cmd) ? searchOps.indexOf(cmd) >= 0 : true;

						if (cmd && isValidOperator)
						{
							if (cmd == 'ILIKE')
							{
								var startsWith = /%$/.test(val);
								var endsWidth = /^%/.test(val);
								var options = row.find('.fieldCriteria option[value="#LIKE"]');
								var len = val.match(/%/gi).length

								if (len === 1)
								{
									if (Frames.isTrue(startsWith))
									{
										options.filter('[data-suffix="%"]:not([data-prefix])').prop('selected',true);
										inp.val(val.replace(/\s?\%$/g, ''));
									}
									else if (Frames.isTrue(endsWidth))
									{
										options.filter('[data-prefix="%"]:not([data-suffix])').prop('selected',true);
										inp.val(val.replace(/^%?/g, ''));
									}
									else
									{
										options.filter(':not([data-suffix]):not([data-prefix])').prop('selected',true);
										inp.val(vals[0]);
									}
								}
								else if (len === 2)
								{
									if (Frames.isTrue(startsWith) && Frames.isTrue(endsWidth))
									{
										options.filter('[data-prefix="%"][data-suffix="%"]').prop('selected',true);
										inp.val(val.replace(/^\%\s?|\s?%$/g, ''));
									}
									else
									{
										options.filter(':not([data-suffix]):not([data-prefix])').prop('selected',true);
										inp.val(vals[0]);
									}
								}
								else
								{
									options.filter(':not([data-suffix]):not([data-prefix])').prop('selected',true);
									inp.val(vals[0]);
								}
							}
							else if (cmd == 'LIKE')
							{
								row.find('.fieldCriteria option[value="#LIKE"]:not([data-suffix]):not([data-prefix])').prop('selected',true);
								framesIt.value(vals[0]);
							}
							else if (cmd == 'STARTSWITH')
							{
								row.find('.fieldCriteria option[value="#LIKE"][data-suffix="%"]:not([data-prefix])').prop('selected',true);
								framesIt.value(vals[0].replace(/\s?\%$/g, ''));
							}
							else if (cmd == 'ENDSWITH')
							{
								row.find('.fieldCriteria option[value="#LIKE"][data-prefix="%"]:not([data-suffix])').prop('selected',true);
								framesIt.value(vals[0].replace(/^%?/g, ''));
							}
							else if (cmd == 'CONTAINS')
							{
								row.find('.fieldCriteria option[value="#LIKE"][data-suffix="%"][data-prefix="%"]').prop('selected',true);
								framesIt.value(vals[0].replace(/^\%\s?|\s?\%$/g, ''));
							}
							// adicionar comandos LIKE, STARTSWITH, ENDSWITH
							else if (cmd == 'IEQUAL')
							{
								row.find('.fieldCriteria').val('=').prop('selected',true);
								inp.val(vals[0].replace(/^\s*\'?|'$/g, ''));
							}
							else if (cmd == 'IS')
							{
								if (!Frames.isUndef(mod))
								{
									var option = "#IS " + mod.toUpperCase();
									row.find('.fieldCriteria').val(option).prop('selected',true);
									inp.val(vals[0]);
									if (mod.toUpperCase() === 'NULL' || mod.toUpperCase() ==='NOT NULL')
									{
										row.find('[data-widget]').addClass('hide-element');
									}
								}
								else
								{
									row.find('.fieldCriteria').val('=').prop('selected',true);
								}
							}
							else if (cmd == 'BETWEEN')
							{
								row.find('.fieldCriteria').val('#BETWEEN').prop('selected',true);
								var $field= row.find('[data-widget]');
								val1 = !Frames.isUndef(vals[0]) ? vals[0].trim() : '';
								val2 = !Frames.isUndef(vals[1]) ? vals[1].trim() : '';
								inp.val(val2);
								$('<span class="selectInformation">' + _(Frames.Locale.messages.AND) + '</span>').insertBefore($field);
								this._selectedInformationTmpl(row, val1);
							}
							else
							{
								if (row.find('.fieldCriteria option[value="'+cmd+'"]').length > 0)
								{
									row.find('.fieldCriteria').val(cmd).prop('selected',true);
									inp.val(vals[0]);
								}
								else
								{
									row.find('.fieldCriteria').val('=').prop('selected',true);
								}
							}
						}
						else if (!isValidOperator)
						{
							row.find('.fieldCriteria > option').first().prop('selected',true);
						}
						else
						{
							row.find('.fieldCriteria').val('=').prop('selected',true);
							if (cmd === 'IEQUAL')
							{
								inp.val(vals[0].replace(/^\s*\'?|'$/g, ''));
							}
							else
							{
								row.find('.fieldCriteria > option').first().prop('selected',true);
							}
						}	
					}
					else
					{
						row.find('.fieldCriteria').val('=').prop('selected',true);
					}
				}
			}
		},

		filters: function(block)
		{
			var filters = $();
			if (!Frames.isUndef(block))
			{
				block._BINDS_.reset();
				while (block._BINDS_.hasNext())
				{
					var it = block._BINDS_.next();
					bindable = it.bindable();

					if (!Frames.isUndef(bindable) && !Frames.isUndef(bindable._filter))
					{
						filters = filters.add(bindable._filter);
					}
				}
			}
			return filters;
		},

		parents: function()
		{
			var $parents = $().add(this.element);

			// ELLFIN-6383 (same block opened in two visible filter panels need to be able to combine input from both filter panels)
			var block = this._bindable ? this.getBlock() : undefined;

			var filters = this.filters(block);

			if (!Frames.isEmpty(filters))
			{
				for (var i = 0, len = filters.length; i < len; i++)
				{
					var filter = filters[i];

					if (!Frames.isUndef(filter) && filter.element != this.element)
					{
						$parents = $parents.add(filter.element);
					}
				}
			}
			return $parents;
		},

		_getRows: function()
		{
			return this.parents().find('.middleDiv > .cloned');
		},

		_getSelectedFields: function()
		{
			var fields = [];
			_$.each(this._getRows(), function()
			{
				var row = $(this);
				var v = row.find('select.fieldSelect').val();
				if (!Frames.isUndef(v))
				{
					fields.push(v);
				}
			});
			return fields;
		},

		_getSortCriterias: function()
		{
			var sortCriterias = [];

			_$.each(this._getRows(), function()
			{	var row = $(this);
				if (Frames.isTrue(row.find('input.selectSort').is(':checked')))
				{
					var fsel = row.find('select.fieldSelect');
					var sorder = row.find('select.selectOrder');

					sortCriterias.push(fsel.val() + ':' + sorder.val());
				}
			});

			return sortCriterias;
		},

		_getGroupCriterias: function()
		{
			var groupCriterias = [];

			_$.each(this._getRows(), function()
			{	var row = $(this);
				if (Frames.isTrue(row.find('input.selectGroup').is(':checked')))
				{
					var groupSel = row.find('select.fieldSelect');
					groupCriterias.push(groupSel.val());
				}
			});

			return groupCriterias;
		},

		applyModel: function(data)
		{
			var that = this;
			var query = [];
			var block = this.getBlock();
			var blkData = Frames.find(data, 'block', block.name);
			if (blkData)
			{
				blkData = blkData[0];
				if (blkData)
				{
					_$.each(this._getRows(), function()
					{
						var $row = $(this);
						var $elem = $row.find('[data-widget]');
						var item = Frames.get_frames($elem);

						if (blkData.record)
						{
							var rec = blkData.record[0];

							var node = Frames.find(rec, 'item', item.member);
							if (node)
							{
								item.block = block;
								item.model(blkData);
								delete item.block;
							}
						}
					});
				}
			}
		},

		getItemAdvancedValue: function(item)
		{
			var row = item.elem.parent();

			var fsel = row.find('select.fieldSelect');
			var csel = row.find('select.fieldCriteria');
			var opt = csel.children('option:selected');
			var vinf = row.find('input.selectInformation, button.selectInformation'); // this can return multiples
			var query = opt.data('query');

			if (vinf.length > 1)
			{
				var vinf0 = vinf.eq(0);
				var fobj0 = vinf0.data('frames');
				item = fobj0;
			}

			var type = item.props('type') || 'String';
			var format = item.props('format');
			var options = { allowedKeywords: Frames.Item.getAllowedKeywords(item) };
			var v;

			var isDate = false;
			if (!Frames.isUndef(item))
			{
				isDate = item.widgetcls() === 'datefield' || type === 'Date';
			}

			if (Frames.isTrue(query) || query === undefined)
			{
				// For date items the query should have the canonical value because some format Masks doesn't have the all value (e.g MM/YY misses the day)
				v = isDate ? Frames.Format.formatToCanonical(item.ovalue(), format, type, options) : item.value();
				if (Frames.isEmpty(v))
				{
					// don't process this query
					return;
				}

				// InputTransform modifies the model
				if (item.props('InputTransform') == 'upper')
				{
					if (!Frames.isUndef(v))
					{
						v = v.toUpperCase();
					}
				}
			}
			else
			{
				v = '';
			}

			var q = '';


			var opt = csel.find('option:selected');

			var s = Frames.isUndef(opt.data('suffix')) ? '' : opt.data('suffix');
			var p = Frames.isUndef(opt.data('prefix')) ? '' : opt.data('prefix');

			q = csel.val();

			if (v)
			{
				if (q !== '#LIKE' && q !== '=')
				{
					var hasSpace = /^\s+|\s+$/.test(v);
					v = v.replace(/\s+$/g,'');
					if (hasSpace)
					{
						v = "'" + v + "'"; 
					}
				}

				if (q === '=')
				{
					// use value directly
					q = v;
				}
				else
				{
					q += ' ' + p + v + s;
				}
			}

			if (csel.val() === '#BETWEEN')
			{
				if (vinf)
				{
					var vinf1 = vinf.eq(1);
					var fobj1 = vinf1.data('frames');
					var options = { allowedKeywords: Frames.Item.getAllowedKeywords(fobj1) };
					var vinf_val1 = fobj1 ? (isDate ? Frames.Format.formatToCanonical(fobj1.ovalue(), format, type, options) : fobj1.value()) : vinf1.val();

					if (vinf_val1 === '')
					{
						// don't process this query
						return;
					}

					q += ' AND ' + p + vinf_val1 + s;
				}
			}

			return q;
		},

		setItemBasicValue: function(item, value)
		{
			var ast = Frames.Query.parse(value);
			var type = item.props('type') || 'String';
			var format = item.props('format');
			var formatter = Frames.Format._getFormatter('Date');
			var frm = formatter._convertFormat(format);
			var options = { allowedKeywords: Frames.Item.getAllowedKeywords(item) };
			var v;

			var ast = Frames.Query.parse(value);
			if (ast.criteria)
			{
				var vals = _$.map(ast.values, function(v)
				{
					return Frames.Format.formatFromCanonical(v,  format, type, options);
				});
				v =  Frames.Query.reverse(ast.criteria, ast.modifier, vals);
			}
			else
			{
				v =  Frames.Format.formatFromCanonical(value,  format, type, options);
			}

			if (item.widgetcls() == 'combobox')
			{
				this.forceComboValueOriginal = true;
				item.value(v);
				delete this.forceComboValueOriginal;
			}
			else
			{
				if (item.props('type') == 'Date' && !Frames.isUndef(frm.timeFormat) && v.indexOf(':') > -1)
				{
					item.value(v.split(" ")[0]);
				}
				else
				{
					item.value(v);
				}
			}
		},

		setItemAdvancedValue: function(item, value)
		{
			var row = item.elem.parent();

			var csel = row.find('select.fieldCriteria');
			var opt = csel.children('option:selected');
			var query = opt.data('query');

			var type = item.props('type') || 'String';
			var format = item.props('format');
			var formatter = Frames.Format._getFormatter('Date');
			var frm = formatter._convertFormat(format);
			var widget = item.data('widget');
			var options = { allowedKeywords: Frames.Item.getAllowedKeywords(item) };

			var ast = Frames.Query.parse(value);
			var criteria = ast.criteria;
			var vals = ast.values;

			var s = !Frames.isEmpty(opt.data('suffix'));
			var p = !Frames.isEmpty(opt.data('prefix'));

			var isDate = item.widgetcls() === 'datefield' || type === 'Date';

			if (criteria)
			{
				if (ast.criteria == 'LIKE')
				{
					var vals = Frames.Query._unquote(vals[0], type);
					if (s && p)
					{
						vals = vals.replace(/^%|%$/g, '');
					}
					else if (s)
					{
						vals = vals.replace(/%$/g, '');
					}
					else if (p)
					{
						vals = vals.replace(/^%/g, '');
					}
				}
				else
				{
					var vals = Frames.Query._unquote(vals[0], type);
				}

				if (Frames.isTrue(query, true) && isDate)
				{
					vals = Frames.Format.formatFromCanonical(vals, format, type, options);
				}

				if (item.widgetcls() == 'combobox')
				{
					this.forceComboValueOriginal = true;
					item.value(vals);
					delete this.forceComboValueOriginal;
				}
				else
				{
					if (isDate && !Frames.isUndef(frm.timeFormat) && vals.indexOf(':') > -1)
					{
						item.value(vals.split(" ")[0]);
					}
					else
					{
						item.value(vals);
					}
				}
			}
			else
			{
				if (isDate && !Frames.isUndef(frm.timeFormat) && value.indexOf(':') > -1)
				{
					item.value(value.split(" ")[0]);
				}
				else
				{
					item.value(value);
				}
			}
		},

		getQuery: function()
		{
			var that = this;
			var query = [];
			_$.each(this._getRows(), function()
			{
				var row = $(this);

				var fsel = row.find('select.fieldSelect');
				var csel = row.find('select.fieldCriteria');
				var vinf = row.find('input.selectInformation, button.selectInformation'); // this can return multiples
				var vinf0 = vinf.eq(0);

				var type = row.find('[data-widget]').data('type') || 'String';
				var format = row.find('[data-widget]').data('format');

				var fobj0 = vinf0.data('frames');

				var vinf0_val = fobj0 ? fobj0.value() : vinf0.val();
				if (vinf0_val === '')
				{
					// don't process this query
					return;
				}

				// InputTransform modifies the model
				if (vinf0.parent().data('case') == 'upper')
				{
					vinf0_val = vinf0_val.toUpperCase();
				}

				var q = '';

				if (Frames.isTrue(that._isBasicMode()))
				{
					if (vinf0_val !== undefined)
					{
						vinf0_val = vinf0_val === null ? "''" : vinf0_val;
						q = vinf0_val;
					}
				}
				else
				{
					var opt = csel.find('option:selected');

					var s = Frames.isUndef(opt.data('suffix')) ? '' : opt.data('suffix');
					var p = Frames.isUndef(opt.data('prefix')) ? '' : opt.data('prefix');

					q = csel.val();

					if (vinf0_val !== undefined)
					{
						vinf0_val = vinf0_val === null ? "''" : vinf0_val;

						if (q === '=')
						{
							// use value directly
							q += ' ' + vinf0_val;
						}
						else
						{
							q += ' ' + p + vinf0_val + s;
						}
					}

					if (csel.val() === '#BETWEEN')
					{
						var vinf1 = vinf.eq(1);
						var fobj1 = vinf1.data('frames');
						var vinf_val1 = fobj1 ? fobj1.value() : vinf1.val();

						if (vinf_val1 === '')
						{
							// don't process this query
							return;
						}

						q += ' AND ' + p + vinf_val1 + s;
					}
				}

				query.push({field: fsel.val(), value: q, type: type, format: format});
			});

			return query;
		},

		_applyQuery: function(query)
		{
			var _lastMapValues = Frames.Config.get('MAPVALUES_ENABLED');
			Frames.Config.set('MAPVALUES_ENABLED', false);

			if (this._bindable.widgetcls() === 'datagrid' || this._bindable.widgetcls() === 'repeater')
			{
				this._bindable.query(query, false);
			}

			var that = this;
			var block = this.getBlock();
			// Items to be filled with chosen criteria values
			var queryItems = new Frames.HashMap();

			var _items = block.getRegisteredItems();
			_items.reset();
			var item;
			while (_items.hasNext())
			{
				item = _items.next();
				// only add to query searchable or sortable items ( if that options are available in the filter)
				if (item && (that._searchable(item) || that._sortable(item)))
				{
					queryItems.put(item.member, item);
				}
			}

			_items = block._BINDS_;
			_items.reset();
			while (_items.hasNext())
			{
				item = _items.next();
				// Add / replace original item by the registered extension
				if (item && Frames.isTrue(item._isextension))
				{
					queryItems.put(item.member, item);
				}
			}

			Frames.Query.applyValues(query, queryItems.values());

			Frames.Config.set('MAPVALUES_ENABLED', _lastMapValues);
		},

		_executeQuery: function(query, actionname)
		{
			var action = {
				name: actionname ? actionname : 'EXECUTE_QUERY',
				params : []
			};

			if (Frames.isTrue(this.options.sort))
			{
				var sortCriterias = this._getSortCriterias();
				action.name =  'SORT';

				action.params.push({
					name: 'members',
					value: sortCriterias.join(','),
					type: 'string'
				});
			}

			if (Frames.isTrue(this.options.groupby))
			{
				var groupCriterias = this._getGroupCriterias();
				action.name = 'SORT_GROUP';

				action.params.push({
					name: 'groups',
					value: groupCriterias.join(','),
					type: 'string'
				});

			}
			if (Frames.isTrue(this.options.sort) || Frames.isTrue(this.options.group))
			{
				var block = this.getBlock();

				Frames.Application.execute(
					action,
					undefined,
					Frames.Model.create('block'),
					block.name,
					undefined,
					false
				);
			}
			else
			{
				delete action.params;
				Frames.FilterPanel.execute(action, query, this);
			}

			if (this.element.hasClass('ui-filterpanel-dialog'))
			{
				this.element.parent().dialog('close');
			}

			// RESET EXTENSION ITEMS! because of filter again
			// We can't keep the binding with the extension items.
			this.unregisterExtensions();
		},

		_initTemplateAdvancedFilterDiv: function()
		{	// template for the quick search menu
			this._advancedFilter_middleDiv = $('<div class="middleDiv"></div>');

			this._TemplateAdvancedFilterDiv = $('<div>').addClass('advSearchContent');

			// up section
			this._initTemplateAdvancedFilter_h3UpPanel();
			this._TemplateAdvancedFilterDiv.append(this._templateAdvancedFilter_h3UpPanelDiv);

			// middle section
			this._TemplateAdvancedFilterDiv.append(this._advancedFilter_middleDiv);

			// down section
			this._initTemplateAdvancedFilterDownPanel();
			this._TemplateAdvancedFilterDiv.append(this._templateAdvancedFilter_h3DownPanel);
			// this._TemplateAdvancedFilterDiv.hide();

			$('<label class="ui-active-filters">' + _(Frames.Locale.messages.FILTER_ACTIVE_FIELDS) + '</label>')
				.prependTo(this._advancedFilter_middleDiv);

			this._buttonClearAllMiddleDiv = $('<a class="ui-clear-fields ui-buttonClearAllMiddleDiv">' + _(Frames.Locale.messages.BUTTON_CLEAR_FIELDS) + '</a>')
				.insertAfter(this._advancedFilter_middleDiv);

			this._buttonFilterAgainMiddleDiv = $('<button class="primary-button ui-buttonFilterAgainMiddleDiv">' +
				_(Frames.Locale.messages.FILTER_AGAIN) + '</button>');

			this._buttonCloseAdvancedFilterPanelMiddleDiv = $('<a href="javascript:;" class="ui-buttonCloseBasicFilterPanelMiddleDiv btn btn-default"' +
				' title="' + _(Frames.Locale.messages.BUTTON_CLOSE) + '"><i class="fa fa-times-circle"></i></a>');

			$('<span style="display: none;"/>')
				.addClass('button-group-middle-div')
				.append(this._buttonFilterAgainMiddleDiv)
				.append(this._buttonCloseAdvancedFilterPanelMiddleDiv)
				.insertAfter(this._buttonClearAllMiddleDiv);
		},

		_initTemplateAdvancedFilter_h3UpPanel: function()
		{
			// up section of advanced Filter

			this._templateAdvancedFilter_h3UpPanelDiv = $('<div class=advPanelUp>');

			this._templateAdvancedFilter_h3UpPanel = $('<h3 class="legendUp"></h3> ');

			this._buttonFilterAgain = $('<button class="primary-button ui-buttonFilterAgain">' + _(Frames.Locale.messages.FILTER_AGAIN) + '</button>')
					.hide();

			this._buttonCloseAdvancedFilterPanel = $('<a href="javascript:;" class="ui-buttonCloseBasicFilterPanel btn btn-default"' +
				' title="' + _(Frames.Locale.messages.BUTTON_CLOSE) + '"><i class="fa fa-times-circle"></i></a>');

			this._templateAdvancedFilter_h3UpPanelDiv.append(this._templateAdvancedFilter_h3UpPanel);

			$('<span />')
				.addClass('button-group')
				.append(this._buttonFilterAgain)
				.append(this._buttonCloseAdvancedFilterPanel)
				.appendTo(this._templateAdvancedFilter_h3UpPanel);
		},

		// middle section of advanced Filter
		_initTemplateAdvancedSearchMiddleDiv: function()
		{
			// TODO: localize strings
			var _FilterSelectedInformation =
					$('<label>' + '&nbsp;' + '</label>' + '<select class="ui-corner-all selectFilter fieldSelect" aria-label="' + _(Frames.Locale.messages.FILTER_CRITERIA_FIELD) + '">' +
						'<option value="" selected>' + _(Frames.Locale.messages.FILTER_SELECTED_INFORMATION) + '</option>' +
					'</select>');

			if (Frames.isTrue(this.options.filter))
			{
				this.__criteriaCheckbox = $('<label class="ui-corner-all selectFilter">' +
					'<input type="checkbox" checked="checked"> ' + _(Frames.Locale.messages.FILTER_FIELD_CRITERIA_ENABLE) + '</label>');

				this.__fieldCriteriaTmpl =
						$('<select class="ui-corner-all selectFilter fieldCriteria">' +
							// '<option value=""></option>' +
							'<option value="#LIKE" data-prefix="%" data-suffix="%">' + _(Frames.Locale.messages.FIELD_CRITERIA_CONTAINS) + '</option>' +
							'<option value="#LIKE">' + _(Frames.Locale.messages.FIELD_CRITERIA_LIKE) + '</option>' +
							'<option value="#LIKE" data-suffix="%">' + _(Frames.Locale.messages.FIELD_CRITERIA_STARTS_WITH) + '</option>' +
							'<option value="#LIKE" data-prefix="%">' + _(Frames.Locale.messages.FIELD_CRITERIA_ENDS_WITH) + '</option>' +
							'<option value="=">' + _(Frames.Locale.messages.FIELD_CRITERIA_EQUALS) + '</option>' +
							'<option value="<>">' + _(Frames.Locale.messages.FIELD_CRITERIA_NOT_EQUAL) + '</option>' +
							'<option value="#IS NULL #OR <>">' + _(Frames.Locale.messages.FIELD_CRITERIA_NOT_EQUAL_OR_IS_NULL) + '</option>' +
							'<option value="#BETWEEN">' + _(Frames.Locale.messages.FIELD_CRITERIA_BETWEEN) + '</option>' +
							'<option value=">">' + _(Frames.Locale.messages.FIELD_CRITERIA_GREATER_THAN) + '</option>' +
							// '<option value="#IS NULL #OR >">Greater Than or IS NULL</option>' +
							'<option value=">=">' + _(Frames.Locale.messages.FIELD_CRITERIA_GREATER_THAN_OR_EQUAL) + '</option>' +
							// '<option value="#IS NULL #OR >=">Greater Than or Equal or IS NULL</option>' +
							'<option value="<">' + _(Frames.Locale.messages.FIELD_CRITERIA_LESS_THAN) + '</option>' +
							'<option value="#IS NULL #OR <">' + _(Frames.Locale.messages.FIELD_CRITERIA_LESS_THAN_OR_IS_NULL) + '</option>' +
							'<option value="<=">' + _(Frames.Locale.messages.FIELD_CRITERIA_LESS_THAN_OR_EQUAL) + '</option>' +
							'<option value="#IS NULL #OR <=">' + _(Frames.Locale.messages.FIELD_CRITERIA_LESS_THAN_OR_EQUAL_OR_IS_NULL) + '</option>' +
							'<option value="#IS NULL" data-query="false">' + _(Frames.Locale.messages.FIELD_CRITERIA_IS_NULL) + '</option>' +
							'<option value="#IS NOT NULL" data-query="false">' + _(Frames.Locale.messages.FIELD_CRITERIA_IS_NOT_NULL) + '</option>' +
							// '<option value="#IN">In ...</option>' +
						'</select>');
			}

			if (Frames.isTrue(this.options.sort))
			{
				this.__criteriaSort = $('<label class="ui-corner-all selectFilter">' +
					'<input type="checkbox" class="selectSort" checked="checked"> ' + _(Frames.Locale.messages.FILTER_SORT_ENABLE) + '</label>' +
					'<select class="ui-corner-all selectFilter selectOrder">' +
					'<option value="true">' + _(Frames.Locale.messages.FILTER_SORT_ASCENDENT) + '</option>' +
					'<option value="false">' + _(Frames.Locale.messages.FILTER_SORT_DESCENDENT) + '</option>' +
					'</select>');
			}

			if (Frames.isTrue(this.options.groupby))
			{
				this.__criteriaGroupBy = $('<label class="ui-corner-all selectFilter">' +
					'<input type="checkbox" class="selectGroup"> ' + _(Frames.Locale.messages.FILTER_GROUP_BY_ENABLE) + '</label>');
			}

			this._templateAdvancedSearchMiddleDiv = $('<div class="middleDivRow ui-layout-horizontal">')
					.append(_FilterSelectedInformation.show());

		},

		_selectedInformationTmpl: function($row, value, ovalue, init, focus)
		{
			var $el;
			var that = this;
			var item;
			var selectedFieldOption = $row.find('.fieldSelect option:selected');

			var id = Frames.uuid();
			var data = selectedFieldOption.data('data');
			var action = selectedFieldOption.data('action');

			var editor = selectedFieldOption.attr('data-editor');
			var label = selectedFieldOption.text();
			var type = selectedFieldOption.attr('data-type');
			var format = selectedFieldOption.attr('data-format');
			var maxlength = selectedFieldOption.attr('data-maxlength');
			var _case = selectedFieldOption.attr('data-case');
			var width = selectedFieldOption.attr('data-width') || '';
			var autocomplete = 'off';

			value = selectedFieldOption.attr('data-value') || value;

			var $fieldCriteria = $('.fieldCriteria', $row);
			var member = $row.find('select.fieldSelect').val();
			var block = this._version2 ? this.getBlock() : undefined;
			var name = block ? block.name + '_' + id : id;

			// TODO: DateTime!? and others...
			if (editor === 'calendar')
			{
				$el = $('<div id="' + Frames.uuid() + '"data-widget="datefield" data-type="' + type + '" class="ui-widget ui-calendar ui-hidelabel" data-autocomplete="' + autocomplete + '">' +
						'<label for="' + id + '">' + label + '</label>' +
						'<input id="' + id + '" class="ui-widget-content ui-corner-all selectInformation">' +
					'</div>');

				if (format !== undefined)
				{
					// remove time stamps
					var formatter = Frames.Format._getFormatter('Date');
					var frm = formatter._convertFormat(format);

					if (Frames.isUndef(frm.timeFormat))
					{
						$el.attr('data-format', frm.dateFormat);
					}
					else if (Frames.isUndef(frm.dateFormat))
					{
						$el.attr('data-format', frm.timeFormat);
					}
					else
					{
						$el.attr('data-format', frm.dateFormat + ' ' + frm.timeFormat);
					}
				}

				if (maxlength !== undefined && !this._isBasicMode())
				{
					$el.attr('data-maxlength', maxlength);
				}
				if (_case !== undefined)
				{
					$el.attr('data-case', _case);
				}

				if (name)
				{
					$el.find('input').attr('name', name);
				}

				$el.insertAfter($fieldCriteria);
				item = Frames.create($el.attr('id'), $el, Frames.Application.task.view);

				// force original width
				item.input()[0].style.width = width;

				// validate the format
				$('input', $el).on('change', function()
				{
					var item = $(this).data('frames');
					var formatter = Frames.Format._getFormatter('Date');
					var frm = formatter._convertFormat(item.props('format'));
					var prop = item.props('type');

					if (_checkIfNeedsValidation($el))
					{
						Frames.Validation.reset(item);
						var valid = Frames.Validation.validateFormat(item);
						if (valid)
						{
							var options = { allowedKeywords: Frames.Item.getAllowedKeywords(item) };
							var modeName = !Frames.isUndef(item.mode) ? item.mode.name : undefined;
							if (jQuery && jQuery.multicalendar._isCalendarShown && modeName == 'SEARCH'||item.value().indexOf(':') == -1 && prop == 'Date' && !Frames.isUndef(frm.timeFormat))
							{
								$(this).val(Frames.Format.format(item.value(), frm.dateFormat, item.props('type'), options));
							}
							else
							{
								$(this).val(Frames.Format.format(item.value(), item.props('format'), item.props('type'), options));
							}
						}
					}
					else if (that._isBasicMode())
					{
						if (jQuery && jQuery.multicalendar._isCalendarShown && prop == 'Date' && !Frames.isUndef(frm.timeFormat) && item.value().indexOf(':') > -1)
						{
							$(this).val(item.value().split(" ")[0]);
						}
						else
						{
							$(this).val(item.value());
						}
					}

					var val = item.value();
					if (item._filter_last_value != val)
					{
						item._value_has_changed = true;
						item._filter_last_value = val;
					}
				});
			}
			else if (editor === 'checkbox')
			{
				var v = selectedFieldOption.data('value') || '';
				var fvalue = selectedFieldOption.data('fvalue') || '';
				var visnull = selectedFieldOption.data('valueisnull');
				var fisnull = selectedFieldOption.data('fvalueisnull');

				$el = $('<div data-widget="checkbox" id="' + Frames.uuid() + '" class="ui-widget ui-checkbox">' +
						'<label for="' + id +'">' + label + '</label>' +
						'<input id="' + id + '" class="ui-widget-content ui-corner-all"' +
							(visnull ? ' data-valueisnull="true"' : ' data-value="' + v + '"')+
							(fisnull ? ' data-fvalueisnull="true"' : ' data-fvalue="' + fvalue + '"')+
						'>' +
					'</div>');

				$el.insertAfter($fieldCriteria);
				item = Frames.create($el.attr('id'), $el, Frames.Application.task.view);
				item.elem.find('input').prop('indeterminate', true);

				// for checkboxes the frames instance is held by the button
				$('button', $el).addClass('selectInformation');

				// put the checkbox in standalone mode
				$el.checkbox('option', 'clickModel', 'standalone');
			}
			else if (editor === 'combobox')
			{
				data = JSON.parse(decodeURIComponent(data));

				var opts = '';
				if (Frames.isArray(data))
				{
					_$.each(data, function(index, option)
					{
						var isnull = Frames.isTrue(Frames.Application._supportnulls) && option.value === null;
						var v = isnull ? 'data-valueisnull="true"' : 'value="' + option.value + '"';
						opts += '<option ' + v + '>' + option.label + '</option>';
					});
				}
				else
				{
					for (var v in data)
					{
						if (data.hasOwnProperty(v))
						{
							opts += '<option value="' + v + '">' + data[v] + '</option>';
						}
					}
				}

				$el = $('<div data-type="'+ type +'" data-widget="combobox" id="' + Frames.uuid() + '" class="ui-widget ui-combobox ui-hidelabel">' +
						'<label for="' + id +'">' + label + '</label>' +
						'<select id="' + id + '" name="' + id + 'y" class="ui-widget-content ui-corner-all">' +
							opts +
						'</select>' +
					'</div>');

				$el.insertAfter($fieldCriteria);

				// clear default selection
				$('select', $el).val([]);

				item = Frames.create($el.attr('id'), $el, Frames.Application.task.view);

				// force original width
				item.input()[0].style.width = width;
				var inputwidth = item.input()[0].offsetWidth;
				var btnwidth  = $('button', $el)[0].offsetWidth;
				$('select', $el).css('width', inputwidth + btnwidth);

				$('input', $el)
					.addClass('selectInformation')
					.on('change', function()
					{
						if (_checkIfNeedsValidation($el))
						{
							var item = $(this).data('frames');
							Frames.Validation.reset(item);
							Frames.Validation.validateFormat(item);
						}
					});
			}
			else if (editor === 'radiogroup')
			{
				data = JSON.parse(decodeURIComponent(data));

				var buttons = '';
				var i = 0;

				if (Frames.isArray(data))
				{
					_$.each(data, function(index, btn)
					{
						var isnull = Frames.isTrue(Frames.Application._supportnulls) && btn.value === null;
						var v = isnull ? 'data-valueisnull="true"' : 'value="' + btn.value + '"';
						//opts += '<option ' + v + '>' + btn.label + '</option>';
						var radioId = id + '_' + i++;
						buttons +=
						'<div id="' + radioId + '" data-widget="radiobox" class="ui-widget ui-radiobox">' +
						'<input type="radio" ' + v + ' name="' + id + '" id="#' + radioId + '" />' +
						'<label id="l:#' + radioId + '" for="#' + radioId + '">' + btn.label + '</label>' +
						'</div>';
					});
				}

				$el = $('<div data-widget="radiogroup" id="' + id + '" data-type="' + type + '" class="ui-widget ui-radiogroup ui-layout-horizontal">' +
						'<label style="display: none;">' + label + '</label>' +
						buttons +
					'</div>');

				$el.insertAfter($fieldCriteria);
				item = Frames.create($el.attr('id'), $el, Frames.Application.task.view);

				$('> input', $el).addClass('selectInformation');

				// put the radiogroup in standalone mode
				$el.radiogroup('option', 'clickModel', 'standalone');

			}
			else if (editor === 'lovbox' && this._version2)
			{
				// default is a textinput, ignore custom format on purpose
				$el = $('<div data-widget="lovinput" id="' + Frames.uuid() + '" class="ui-widget ui-textinput ui-hidelabel"' +
							'data-autocomplete="' + autocomplete + '"' +
							(_case !== undefined ? ' data-case="' + _case + '"' : '') +
							(type !== undefined ? ' data-type="' + type + '"' : '') +
							'>' +
						'<label for="' + id + '">' + label + '</label>' +
						'<input type="text" id="' + id + '" class="ui-widget-content ui-corner-all selectInformation">' +
					'</div>');

				if (format !== undefined)
				{
					$el.attr('data-format', format); 
				}
				if (maxlength !== undefined && !this._isBasicMode())
				{
					$el.attr('data-maxlength', maxlength);
				}
				if (name)
				{
					$el.find('input').attr('name', name);
				}

				$el.insertAfter($fieldCriteria);
				item = Frames.create($el.attr('id'), $el, Frames.Application.task.view);

				// force original width
				item.input()[0].style.width = width;

				// validate the format
				$('input', $el).on('change', function()
				{
					var it = $(this).data('frames');
					if (_checkIfNeedsValidation($el))
					{
						Frames.Validation.reset(it);
						var valid = Frames.Validation.validateFormat(it);
						if (valid)
						{
							var options = { allowedKeywords: Frames.Item.getAllowedKeywords(it) };
							$(this).val(Frames.Format.format(it.value(), it.props('format'), it.props('type'), options));
						}
					}
					else if (that._isBasicMode())
					{
						$(this).val(it.value());
					}

					var val = it.value();
					if (it._filter_last_value != val)
					{
						it._value_has_changed = true;
						it._filter_last_value = val;
					}
				});

				$('button', $el).on('click', function()
				{
					var item = $(this).parent().data('frames');
					var prevItem = !Frames.isUndef(block) && !Frames.isUndef(block._filterItem) ? block._filterItem : Frames.Application.current();
					var act = !Frames.isUndef(action) ? action : 'LIST_VALUES';

					Frames.Application.execute({
						name: 'PROC:GOTOITEM',
						params: [
							{name: 'previousItem',		value: prevItem.member,		type: 'string'},
							{name: 'previousBlock',		value: prevItem.block.name,	type: 'string'},
							{name: 'previousRecord',	value: prevItem.block.selid,	type: 'string'},
							{name: 'item',				value: item.member,			type: 'string'},
							{name: 'block',				value: block.name,		type: 'string'},
							{name: 'record',			value: block.selid,		type: 'string'},
							{name: 'actionValue',		value: '',					type: 'string'},
							{name: 'fireItemAction',	value: act, type: 'string'}
						]},
						Frames.Application.task, undefined, undefined, undefined, false
					);
				});
			}
			else
			{

				// default is a textinput, ignore custom format on purpose
				$el = $('<div data-widget="textinput" id="' + Frames.uuid() + '" class="ui-widget ui-textinput ui-hidelabel"' +
							(_case !== undefined ? ' data-case="' + _case + '"' : '') +
							(type !== undefined ? ' data-type="' + type + '"' : '') +
							'data-autocomplete="' + autocomplete + '"' +
							'>' +
						'<label for="' + id + '">' + label + '</label>' +
						'<input type="text" id="' + id + '" class="ui-widget-content ui-corner-all selectInformation"' +'>' +
					'</div>');

				if (format !== undefined)
				{
					$el.attr('data-format', format);
				}
				if (maxlength !== undefined && !this._isBasicMode())
				{
					$el.attr('data-maxlength', maxlength);
				}
				if (name)
				{
					$el.find('input').attr('name', name);
				}

				$el.insertAfter($fieldCriteria);

				if (this._version2)
				{
					var obj = block.get(member) || that._EXTRA_.get(member);
					if (!Frames.isUndef(obj))
					{
						var $widget = obj.elem;
						var $next =  $widget.next();
						var isButtonInput = $widget.is('.ui-buttoninput') && $next.is('button.ui-buttoninput');
						if (isButtonInput)
						{
							$el.addClass('ui-buttoninput');

							var act = $next.data('action') || $next.data('eventclick');
							var itButton = $next.data('frames');

							// HACK: 21px should be added, from compact theme, like the other widgets
							var $btn = $('<button type="button" class="ui-widget ui-button ui-buttoninput ui-state-default ui-corner-all ui-button-icon-only" ' + 
							'role="button" style="vertical-align: bottom; height: 21px; margin-left: 0px">' +
							'<span class="ui-icon search"></span>' +
							'</button>')
							.on('click', function()
							{
								var prevItem = Frames.Application.current();

								Frames.Application.execute(act, Frames.Application.task, undefined, itButton.block.name, itButton.member, false);
							})
							.appendTo($el);
						}
					}
				}

				item = Frames.create($el.attr('id'), $el, Frames.Application.task.view);

				// force original width
				item.input()[0].style.width = width;

				// validate the format
				$('input', $el).on('change', function()
				{
					var it = $(this).data('frames');
					if (_checkIfNeedsValidation($el))
					{
						Frames.Validation.reset(it);
						var valid = Frames.Validation.validateFormat(it);
						if (valid)
						{
							var options = { allowedKeywords: Frames.Item.getAllowedKeywords(it) };
							$(this).val(Frames.Format.format(it.value(), it.props('format'), it.props('type'), options));
						}
					}
					else if (that._isBasicMode())
					{
						$(this).val(it.value());
					}

					var val = it.value();
					if (it._filter_last_value != val)
					{
						it._value_has_changed = true;
						it._filter_last_value = val;
					}
				});
			}

			//add rules to new item
			Frames.Validation.rules(item);

			if (this._version2)
			{
				if (block && init)
				{
					if (!block._FILTER_)
					{
						block._FILTER_ = new Frames.HashMap();
					}
					block._FILTER_.put(member, item);

					if (Frames.isUndef(item.block))
					{
						item.block = block;
					}
				}

				item.elem.data('frames', item);
				item.member = member;
				item.mode = { name: 'SEARCH', leave: _$.noop, enter: _$.noop };

				item.input().on('focus', function()
				{
					var filter = that;
					var it = Frames.get_frames($(this).parent());
					if (it)
					{
						//if is not parte of _ITEMS_ do not change current item (like on extensions)
						if (block._ITEMS_.indexOf(it.member) !== -1)
						{
							block.item =  block.get(it.member);
							delete block._filterItem;
						}
					}
				});

				item.on('keydown', block._keyEventHandler.bind(block));

				item._filterDestroy = item.destroy;
				item.destroy = function()
				{
					var input = item.input();
					if (input)
					{
						input.off('focus');
					}
					this._filterDestroy.apply(this);
					item.off('keydown');
				};

				item._filterModel = item.model;
				item.model = function()
				{
					var filter = that;
					if (arguments.length === 0)
					{
						if (filter._version2)
						{
							var self = this;
							var v = filter._isBasicMode() ? this.value() : filter.getItemAdvancedValue(this);
							var options = { allowedKeywords: Frames.Item.getAllowedKeywords(this) };
							var ast = Frames.Query.parse(v);
							if (ast.criteria)
							{
								var vals = _$.map(ast.values, function(vv)
								{
									// when is date already are in canonical format
									var val = self.props('type') == 'Date' && !filter._isBasicMode() ? vv : Frames.Format.formatToCanonical(vv, self.props('format'), self.props('type'), options);
									if (self.widgetcls() == 'combobox' && filter._isBasicMode() && val != v)
									{
										self.value(val);
										val = self.value();
										// re-set original value
										self.value(v);
									}
									return val;
								});
								if (ast.criteria == 'LIKE')  // if the search operator is LIKE, we can't formatToCanonical, because the % can be placed anywhere (eg: %123%56%)
								{
									vals = ast.values;
								}
								v = Frames.Query.build(ast.criteria, ast.modifier, vals, this.props('type'));
							}
							else
							{
								v = Frames.Format.formatToCanonical(v, this.props('format'), this.props('type'), options);
							}

							if (typeof(v) == 'string' && this.props('InputTransform') == 'upper' && !Frames.isFunction(this.optmodel))
							{
								v = v.toUpperCase();
							}

							var info;
							if (Frames.Config.getbool('MODEL_ITEM_TYPES', false))
							{
								var format;
								var defaultTime = '00:00:00';
								var isDate = this.widgetcls() === 'datefield' || this.props('type') === 'Date';
								if (v.indexOf(defaultTime) > -1 && this.value().indexOf(defaultTime) == -1 && isDate && frm && !Frames.isUndef(frm.timeFormat))
								{
									format = this.props('format').split(" ")[0];
								}
								else
								{
									format = this.props('format');
								}
								var type = this.props('type');
								if (Frames.Locale.formats.IS_RTL && !Frames.Locale.formats.DATE_IS_RTL && type == 'Date')
								{
									format = format.split('').reverse().join(''); // reverse format
								}

								info = Frames.Format.getTypeInformation(this.mode.name, format, this.props('type'));
							}
							return Frames.Model.createItem(this.member, v, info);
						}
						else
						{
							return this._filterModel.apply(this);
						}
					}
					else
					{
						//TODO radiogroup value (setter) has a specific code when in search mode,
						// that does not make sense for this filterpanel. This needs to be fixed.
						if (!Frames.isUndef(this.elem))
						{
							if (this.elem.data('widget') === 'radiogroup')
							{
								var blkMode = this.block.props('blockMode');
								this.block.props('blockMode', '');
							}
						}

						if (filter._version2)
						{
							var data = arguments[0];
							if (data)
							{
								var records = data.record;
								if (records)
								{
									var ridx = this.rowidx();

									if (Frames.isUndef(ridx) || ridx == -1 || ridx > (records.length - 1))
									{
										ridx = 0;
									}

									var record = records[ridx];
									var item = Frames.find(record, 'item', this.member);
									var text = Frames.Model.text(item);
									var v = Frames.Model.text(item);

									filter._isBasicMode() ? filter.setItemBasicValue(this, v) : filter.setItemAdvancedValue(this, v);
								}
							}
						}
						else
						{
							this._filterModel.apply(this, arguments);
						}

						if (!Frames.isUndef(this.elem))
						{
							if (this.elem.data('widget') === 'radiogroup')
							{
								this.block.props('blockMode', blkMode);
							}
						}
					}

				};

				item._filterOvalue = item.ovalue;
				item.ovalue = function()
				{
					if (arguments.length === 0)
					{
						var filter = that;
						if (filter._isBasicMode() && filter._version2)
						{
							this._ovalue = this.value();
							return this._ovalue;
						}
						else
						{
							return this._filterOvalue.apply(this);
						}
					}
					else
					{
						this._filterOvalue.apply(this, arguments);
					}
				};
			}

			if (value)
			{
				item.value(value);
				item.ovalue(ovalue);

				if (_checkIfNeedsValidation(item.elem))
				{
					var valid = Frames.Validation.validateFormat(item);
					if (!valid)
					{
						item.value('');
						item.ovalue(undefined);

						Frames.Validation.reset(item);
					}
				}
			}

			if (init)
			{
				Frames.later(function() {
					item.focus();
				});
			}

			item.on('keydown', function(ev)
			{
				var key = Frames.Keys.string(ev);
				if (item.processNavigationKey(key))
				{
					ev.preventDefault();
					ev.stopImmediatePropagation();
					return false;
				}

				var $parent = $(ev.target).parent();

				// outside of acc mode, skip input button on tab
				if (Frames.Navigation.mode() === 'default' && key === 'TAB' && $parent.hasClass('ui-textinput'))
				{
					var $el = $parent.parent().find('.ui-erasecombotext');
					$el.focus();
					ev.preventDefault();
					ev.stopImmediatePropagation();
					return false;
				}
			});

			return $el;
		},

		_appendNewAdvFilterRow: function(animation)
		{
			var that = this;

			var newrow = this._templateAdvancedSearchMiddleDiv.clone(true)
				.append($('<a href="javascript:;" class="btn btn-default ui-erasecombotext"' +
					' title="' + _(Frames.Locale.messages.BUTTON_CLEAR_CRITERIA) + '"><i class="fa fa-minus-circle"></i></a>').hide());

			if (this._version2)
			{
				newrow.css('display', 'inline-block');
				newrow.append($('<a href="javascript:;" class="btn btn-default ui-erasecombotext-filteragain"' +
					' title="' + _(Frames.Locale.messages.BUTTON_CLEAR_CRITERIA) + '"><i class="fa fa-minus-circle"></i></a>').hide());
			}

			// Disable already chosen fields ( in other filters)
			_$.each(this._getSelectedFields(), function(index, element)
			{
				newrow.find('.selectFilter.fieldSelect option[value="' + element + '"]').attr('disabled','disabled');
			});

			if (Frames.isTrue(this.options.sort))
			{
				newrow.append($('<a href="javascript:;" class="btn btn-default ui-criteriadown"' +
						' title="' + _(Frames.Locale.messages.BUTTON_MOVE_CRITERIA_DOWN) + '"><i class="fa fa-arrow-down"></i></a>').hide())
					.append($('<a href="javascript:;" class="btn btn-default ui-criteriaup"' +
						' title="' + _(Frames.Locale.messages.BUTTON_MOVE_CRITERIA_UP) + '"><i class="fa fa-arrow-up"></i></a>').hide());
			}

			if (animation)
			{
				var last = this._advancedFilter_middleDiv.children('.middleDivRow').last();

				last.before(newrow.hide());
				newrow.show();
				newrow.addClass('cloned');
			}
			else
			{
				if (this._advancedFilter_middleDiv.children('.middleDivRow').length === 0)
				{
					this._advancedFilter_middleDiv.append(newrow);

					// on first select in middleRow changes
					newrow.on('change', '.selectFilter.fieldSelect', function(event)
					{
						that._rowChanged(this, true);
					});
				}
			}

			return newrow;
		},

		_rowChanged: function(elem, focus)
		{
			var that = this;
			var fieldSelect = $(elem);

			// set field name dropdown width
			var templateSelect = that._templateAdvancedSearchMiddleDiv.find('select.fieldSelect');
			if (templateSelect.width() === 0)
			{
				templateSelect.css('width', fieldSelect.outerWidth());
				fieldSelect.css('width', fieldSelect.outerWidth());
			}

			var newrow = that._appendNewAdvFilterRow(true);

			that.__selectedFields = that.__selectedFields || [];

			newrow.find('.ui-erasecombotext').css('display', '');

			that._redrawPosIcons();

			var newFieldSelect = newrow.find('select.fieldSelect');

			newFieldSelect
				.find('option[value=""]')
					.remove()
				.end()
				.val(fieldSelect.val())
				.data('value', fieldSelect.val())
				.on('change', function(event)
				{
					var pVal = $(this).data('value');
					var val = $(this).val();

					// Enable previous option in other filters
					that._disableFilterOption(pVal);

					// remove previous item from block
					var $row = $(this).parent();
					that._clearItems($row);

					// re-add previous value and remove new one from other selects
					that._advancedFilter_middleDiv.find('.middleDivRow .fieldSelect').not($(this)[0])
						.each(function()
						{
							that._removeFilterOption($(this), val);
							that._addFilterOption($(this), pVal);
						});

					that.__selectedFields.splice(that.__selectedFields.indexOf(pVal), 1);
					that.__selectedFields.push(val);

					that._setFieldCriteria($(this));

					$(this).data('value', val);
				});

			_$.each(that.__selectedFields, function(index, element)
			{
				// remove pre-existing fields
				newFieldSelect.find('option[value="' + element + '"]').remove();
			});

			that.__selectedFields.push(fieldSelect.val());

			// remove selected option from other fieldSelects
			var otherClones = $('.cloned', that._advancedFilter_middleDiv).not(newrow[0]);

			$('.fieldSelect option[value=\'' + fieldSelect.val() + '\']', otherClones).remove();

			that._setFieldCriteria(newFieldSelect, focus);

			var selected = fieldSelect.find(':selected');

			// reset selection
			fieldSelect.val('');

			selected.remove();

			newFieldSelect.focus();

			// hide row if there are no more fields to filter
			if (fieldSelect.children().length == 1)
			{
				fieldSelect.parent().hide();
			}

			return newrow;
		},

		_redrawPosIcons: function()
		{
			var rows = $('.middleDiv').children('.cloned');

			_$.each(rows, function(index, element)
			{
				var rowindex = $(this).index();

				var up = $(this).find('.ui-criteriaup');
				var down = $(this).find('.ui-criteriadown');

				if (rowindex !== 0)
				{
					up.css('display', '');
				}
				else
				{
					up.css('display', 'none');
				}

				if (rowindex !== rows.length - 1)
				{
					down.css('display', '');
				}
				else
				{
					down.css('display', 'none');
				}
			});
		},

		// Change filter option status, default is enable
		_disableFilterOption: function(member, disable)
		{
			var that = this;
			var block = this.getBlock();

			_$.each(this.filters(block), function(idx, filter)
			{
				if (that == filter)
				{
					// continue
					return true;
				}
				var $option = filter._advancedFilter_middleDiv.find('.selectFilter.fieldSelect option[value="' + member + '"]');

				if (!Frames.isEmpty($option))
				{
					if (disable)
					{
						$option.attr('disabled','disabled');
					} else
					{
						$option.removeAttr('disabled');
					}
				}
			});
		},

		_removeFilterOption: function($fieldSelect, val)
		{
			$('option[value=\'' + val + '\']', $fieldSelect).remove();
		},

		_addFilterOption: function($fieldSelect, val)
		{
			var $option = this.__fieldSelectTmpl.find('option[value=\'' + val + '\']').clone(true);

			// insert filter option in order
			var $options = $fieldSelect.find('option[data-order]');
			var len = $options.length;
			if (len === 0)
			{
				$fieldSelect.append($option);
			}
			else
			{
				$options.each(function(index)
				{
					var $o = $(this);

					if ($o.data('order') > $option.data('order'))
					{
						$option.insertBefore($o);
						return false;
					}
					else if (index === len - 1)
					{
						$option.insertAfter($o);
						return false;
					}
				});
			}
		},

		_clearItems: function($row)
		{
			var that = this;

			_$.each($('input.selectInformation, button.selectInformation', $row), function()
			{
				var item = $(this).data('frames');
				if (item)
				{
					if (!that._isBasicMode())
					{
						Frames.Validation.reset(item);
					}
					item.destroy();

					if (that._version2)
					{
						var block = that.getBlock();
						if (block._FILTER_)
						{
							block._FILTER_.remove(item);
						}
					}
				}
			});
		},

		_setFieldCriteria: function($fieldSelect, focus)
		{
			var that = this;

			// remove existing criteria fields if they exists
			$fieldSelect.nextAll().not('a').remove();

			var selectedOption = $fieldSelect.find('option:selected');
			var member = selectedOption.attr('value');

			// Filter option enabled
			if (Frames.isTrue(this.options.filter))
			{

				var fieldCriteria = this.__fieldCriteriaTmpl.clone(true).insertAfter($fieldSelect);

				var criteriaCheckbox = this.__criteriaCheckbox.clone(true).insertBefore(fieldCriteria);

				criteriaCheckbox.on('click', function()
				{
					var $criteria = $('.fieldCriteria, .ui-widget', $(this).parent());

					if ($('input', this).is(':checked'))
					{
						$criteria.show();
					}
					else
					{
						$criteria.hide();
					}
				});

				var fieldDataType = selectedOption.data('type');
				var editor = selectedOption.data('editor');

				var block = Frames.Application.task.get(this.getBlock().name);
				// Get item if registered or extensions if it's a filter extension item
				var item = block.get(member) || block.getextitem(member);

				if (item)
				{
					var searchOps = item.extensions ? item.extensions('VALID_SEARCH_OPERATORS') : item.VALID_SEARCH_OPERATORS;
				}

				if (!Frames.isEmpty(searchOps)) 
				{
					searchOps = searchOps.split(';');
					var allOptions = fieldCriteria.find('option');
					fieldCriteria.find('option').remove(); // remove all options and we'll proceed to adding only the operators we want
					for (var opIdx in searchOps)
					{
						var targetOption = allOptions.filter('option[value="' + searchOps[opIdx] + '"]');
						fieldCriteria.append(targetOption);
					}
				}

				else if (editor === 'checkbox' || editor === 'radiogroup')
				{
					// remove everything but equals
					fieldCriteria.find('option').not('[value="="]').remove();
				}
				else if (fieldDataType !== undefined && fieldDataType !== 'String')
				{
					// remove LIKE operators for non text fields
					fieldCriteria.find('option[value="#LIKE"]').remove();
				}
				else
				{
					// remove >,>=,<,<= operators for text fields
					// TODO: simplify this?
					fieldCriteria
						.find('option')
							.not('[value$="<>"]')
							.filter('[value^=">"]' +
								', [value^="<"]' +
								', [value="#BETWEEN"]' +
								', [value^="#IS NULL #OR"]' +
								', [value^="#IS NOT NULL #OR"]').remove();
				}

				if (editor === 'combobox')
				{
					fieldCriteria.find('option[value="#LIKE"]').remove();
				}

				fieldCriteria.val(fieldCriteria.find('option').first().val());
				fieldCriteria.on('change', function(event)
				{
					that._onFieldCriteriaSelection($(this), true, true);
				});

				// handle default
				this._onFieldCriteriaSelection(fieldCriteria, false, focus);
			}

			// Sort option enabled
			if (Frames.isTrue(this.options.sort) && !Frames.isFalse(Frames.Application.current().block.props('AllowSort')) &&
				Frames.Application.current().block.item.props('AllowSort'))
			{
				var $firstButton = $('a', $fieldSelect.parent()).first();

				this.__criteriaSort.clone(true).insertBefore($firstButton);

				$('.selectSort', $fieldSelect.parent()).on('change', function(event)
				{
					var $this = $(this);

					if (Frames.isTrue($this.is(':checked')))
					{
						$('.selectOrder', $fieldSelect.parent()).show();
					}
					else
					{
						$('.selectOrder', $fieldSelect.parent()).hide();
					}
				});
			}

			// Groupby option enabled
			if (Frames.isTrue(this.options.groupby))
			{
				var $firstButton2 = $('a', $fieldSelect.parent()).first();

				this.__criteriaGroupBy.clone(true).insertBefore($firstButton2);
			}

			var nrCriterias = Frames.isTrue(this.options.filter) + Frames.isTrue(this.options.sort) + Frames.isTrue(this.options.groupby);

			if (nrCriterias == 1)
			{
				$('label.selectFilter', $fieldSelect.parent()).hide();
			}

			this._disableFilterOption(member, true);
		},

		_onFieldCriteriaSelection: function($fieldCriteria, saveValue, focus)
		{
			var that = this;
			var $row = $fieldCriteria.parent();
			var selectedFieldOption = $row.find('.fieldSelect option:selected');
			var selectedOption = $fieldCriteria.children('option:selected');
			var query = selectedOption.data('query');
			var value = '';
			var ovalue = null;

			// destroy frames widgets
			$row.find('input.selectInformation, button.selectInformation').each(function()
			{
				var item = $(this).data('frames');
				if (item)
				{
					if (saveValue)
					{
						value = item.value();
						ovalue = item.ovalue();
					}
					if (!that._isBasicMode())
					{
						Frames.Validation.reset(item);
					}
					item.destroy();
				}
			});

			$row.find('[data-widget]')
					.remove()
				.end()
				.find('.selectInformation') // remove remaining non widget fields (like between's separator text)
					.remove();

			var hasElem = Frames.isTrue(query) || query === undefined;
			if (hasElem || (this._version2 && !hasElem))
			{
				var hasHiddenElem = this._version2 && !hasElem;
				if (hasHiddenElem)
				{
					value = '';
					ovalue = '';
				}

				if (!this._version2)
				{
					focus = true;
				}

				var $field = this._selectedInformationTmpl($row, value, ovalue, true, focus);

				if (hasHiddenElem)
				{
					$row.find('[data-widget]').addClass('hide-element');
				} 
				if ($fieldCriteria.val() === '#BETWEEN')
				{
					$('<span class="selectInformation">' + _(Frames.Locale.messages.AND) + '</span>').insertBefore($field);
					this._selectedInformationTmpl($row, value, ovalue, true);
				}
			}
		},

		_initTemplateAdvancedFilterDownPanel: function()
		{
			// down section of advanced Filter

			this._templateAdvancedFilter_h3DownPanel = $('<div class=legendDown ></div> ');
			this._AdvancedFilter_h3DownPanelSpan = $('<span>');
			this._AdvancedFilter_h3DownPanelSpan.addClass('AdvancedFilter_h3DownPanelSpan');

			this._buttonClearAll = $('<button class="primary-button">' + _(Frames.Locale.messages.BUTTON_CLEAR_ALL) + '</button>')
				.addClass('ui-buttonClearAll');
			this._buttonGoSearch = $('<button class="primary-button">' + _(Frames.Locale.messages.BUTTON_GO) + '</button>')
				.addClass('ui-buttonGo');

			this._AdvancedFilter_h3DownPanelSpan.append(this._buttonClearAll);
			this._AdvancedFilter_h3DownPanelSpan.append(this._buttonGoSearch);

			this._templateAdvancedFilter_h3DownPanel.append(this._AdvancedFilter_h3DownPanelSpan);

		},

		destroy: function()
		{
			// Simulates the >1.8 jquery-ui.js @destroy logic.
			// Executes the intern @destroy and then delegates out to _destroy() for custom, widget-specific, cleanup
			// _$.Widget.prototype.destroy.call(this);
			Frames.Application.off('endbind.filterpanel_' + this.instanceId, this._onEndBind);
			Frames.Application.off('startover.filterpanel_' + this.instanceId, this._restartFilter);

			if (this._bindable)
			{
				$(this.getBlock())
				.off('prebind.filterpanel_' + this.instanceId, this._onStartBind);
				delete this._bindable._filter;
				delete this._bindable;
			}

			this.element.removeClass('.ui-widget ui-filterpanel');
		}
	});

	function _checkIfNeedsValidation($el)
	{
		var filter = $el.closest('.ui-filterpanel').data('ui-filterpanel');
		if (!Frames.isUndef(filter))
		{
			if (filter._isBasicMode())
			{
				return false;
			}
		}
		return $el.closest('.middleDivRow').children('.fieldCriteria').val() != '#LIKE';
	}

	Frames.Application.registerActionHandler('FilterPanelAction', function(action)
	{
		Frames.FilterPanel.execute(action);
	});

	Frames.ready(function()
	{
		Frames.Config.getaction_name('EXECUTE_QUERY').type = 'FilterPanelAction';
		Frames.Config.getaction_name('SEARCH').type = 'FilterPanelAction';
		Frames.Config.regaction({ name: 'REQUERY', accesskey: 'REQUERY', type: 'FilterPanelAction'});
	});

	Frames.FilterPanel = {
		execute: function(action, query, filter)
		{
			var item;
			var block;

			if (Frames.isUndef(filter))
			{
				item = Frames.Application.current();
				var bindable = item.bindable();
				filter = bindable ? bindable._filter : undefined;

				// Current item may not have a bindable with filter, we will use the first we get on his block items
				if (!Frames.isUndef(bindable) && Frames.isUndef(filter))
				{
					var filters = _$.ui.filterpanel.prototype.filters(bindable.block);
					if (!Frames.isEmpty(filters))
					{
						filter = filters[0];
					}
				}

				// Executing query by shortcut the onChange only occurs after server response. So the validation msg was being cleared.
				// We want to reset the validation before the reponse
				if (filter)
				{
					filter.focus();
				}
			}
			else
			{
				block = filter.getBlock();
				item = block.item;
			}

			if (typeof(action) == 'string')
			{
				var act = Frames.Config.getaction_name(action);
				if (Frames.isUndef(act))
				{
					action = {name: action};
				}
				else
				{
					action = act;
				}
			}

			if (filter)
			{
				block = block || filter.getBlock();

				// notice that user could execute EXECUTE_QUERY and wasn't in SEARCH mode
				if (action.name == 'EXECUTE_QUERY')
				{
					if (filter._version2)
					{
						filter._go = true;
					}

					if (block._lastmode == 'SEARCH')
					{
						if (filter._version1)
						{
							filter._go = true;

							query = query || filter.getQuery();
							filter._applyQuery(query);
						}
					}
					else if (block._lastmode == 'EXIT_FILTER')
					{
						if (filter._version1)
						{
							this._executeFilterAction(action, item, Frames.Model.create('model'), block);
						}
						else
						{
							this._executeFilterAction(action, item, undefined, block);
						}

						return true;
					}
				}
				else if (action.name == 'REQUERY')
				{
					filter._keepfilter = true;
					block.forceModelState(true);
				}
				else if (action.name == 'SEARCH')
				{
					if (!Frames.Application._actionvalidate(action))
					{
						return false;
					}

					filter._keepfilter = true;

					if (filter._version2)
					{
						if (filter._lastfilter)
						{
							filter._filterAgainMode = true;
						}
					}
				}

				// validate all fields
				var valid = true;
				var $widgets = filter.parents().find('[data-widget]');
				$widgets.each(function()
				{
					var $wel = $(this);
					if (_checkIfNeedsValidation($wel))
					{
						var it = $wel.find('input').data('frames');
						if (it)
						{
							Frames.Validation.reset(it);
							if (!Frames.Validation.validateFormat(it))
							{
								valid = false;
								return false;
							}
						}
					}
				});

				if (valid)
				{
					var options = { allowedKeywords: Frames.Item.getAllowedKeywords(item) };
					$(this).val(Frames.Format.format(item.value(), item.props('format'), item.props('type'), options));

					var model;
					if (filter._version1)
					{
						// with N filterpanels active per block we might have filterpanels in two views simultaneously opened and we need to bind items from all views!
						item.block.bindAllViews = true;
						model = Frames.Application.task.model();
						item.block.bindAllViews = false;

						// with N filterpanels active per block we'll end up with the model with N records that need to be merged into a single one
						if (!Frames.isEmpty(model.children))
						{
							var recordWithSearchFilter = model.children[0].children[0];

							while (model.children[0].children.length > 1)
							{
								var recordToMerge = model.children[0].children.pop();
								while (recordToMerge.children.length > 0)
								{
									recordWithSearchFilter.children.push(recordToMerge.children.pop());
								}
							}
						}
					}

					this._executeFilterAction(action, item, model, block);
				}
			}
			else
			{
				this._executeFilterAction(action, item, undefined, block);
			}
		},

		_executeFilterAction: function(action, item, model, block)
		{
			if (Frames.isUndef(item.block))
			{
				if (block && block._filterItem)
				{
					item.block = block;
				}
			}
			// TODO implement action SEARCH without the PROC:GOTOITEM?

			// In case of multiple filterpanels visible, current item can be in a different block from the filter panel clicked
			var prevItem = Frames.Application.current();

			if (item.block.name === prevItem.block.name)
			{
				Frames.Application.execute(action.name, Frames.Application.task, model, undefined, undefined, false);
			}
			else
			{
				Frames.Application.execute({
					name: 'PROC:GOTOITEM',
					params: [
						{name: 'previousItem',		value: prevItem.member,		type: 'string'},
						{name: 'previousBlock',		value: prevItem.block.name,	type: 'string'},
						{name: 'previousRecord',	value: prevItem.block.selid,	type: 'string'},
						{name: 'item',				value: item.member,			type: 'string'},
						{name: 'block',				value: item.block.name,		type: 'string'},
						{name: 'record',			value: item.block.selid,	type: 'string'},
						{name: 'actionValue',		value: '',					type: 'string'},
						{name: 'fireItemAction',	value: 'DEFERRED:' + action.name, type: 'string'}
					]},
					Frames.Application.task, model, undefined, undefined, false
					);
			}
		},

		getBasicFilterValue: function(row)
		{
			var result = '';

			var option = row.find('.fieldCriteria option:selected');
			var criteria = option[0].value;

			var elem = row.find('.selectInformation');
			var $el = elem;

			//we can have multiple elements, like on between
			if (elem.length > 1)
			{
				$el = elem.eq(0);
			}

			var val = $el.val();
			switch(criteria)
			{
				case '#LIKE':
					var hasPrefix = !Frames.isUndef(option.data('prefix'));
					var hasSuffix = !Frames.isUndef(option.data('suffix'));
					var prefix = hasPrefix ? option.data('prefix') : '';
					var suffix = hasSuffix ? option.data('suffix') : '';
					var criteria = '';
					if (!hasPrefix && !hasSuffix)
					{
						criteria = '#LIKE ';
					}
					else if (!hasPrefix)
					{
						criteria = '#STARTSWITH ';
					}
					else if (!hasSuffix)
					{
						criteria = '#ENDSWITH ';
					}

					else if (hasPrefix && hasSuffix)
					{
						criteria = '#CONTAINS ';
					}
					if (Frames.isEmpty(val) && (!Frames.isEmpty(hasPrefix) || !Frames.isEmpty(hasSuffix)))
					{
						result = criteria;
					}
					else
					{
						result = criteria + prefix + val + suffix;
					}
					break;
				case '#BETWEEN':
					var val1 = elem.last().val();
					result = criteria + ' ' + val + ' and ' + val1;
					break;
				case '=':
					val = /^\s+|\s+$/.test(val) ? "'" + val + "'" : val;
					result = val;
					break;
				default:
					if (!Frames.isEmpty(val))
					{
						val = /^\s+|\s+$/.test(val) ? "'" + val + "'" : val;
						result = criteria + val;
					}
					else
					{
						result = criteria;
					}
			}
			return result;
		}
	};



	Frames.FilterItem = _$.inherit(
		Frames.Item,
	{
		__constructor: function(member, block, exts)
		{
			this.member = member;
			this.block = block;
			this.view = Frames.Application.task.view;

			this._exts = exts || {};
			this._isextension = exts ? true : false;

			var deftype;
			var allowSearch = true;

			if (exts)
			{
				if (!Frames.isUndef(exts.AllowSearch))
				{
					allowSearch = Frames.isTrue(exts.AllowSearch);
				}

				if (member.indexOf('USER') >= 0)
				{
					this._name = 'ACTIVITY_USER';
				}
				else if (member.indexOf('DATE') >= 0)
				{
					this._name = 'ACTIVITY_DATE';
				}
				else
				{
					var bprefix = block.name + '_';
					this._name = member.indexOf(bprefix) !== -1 ? member.substring(bprefix.length, member.length) : member;
				}

				if (exts.DataType)
				{
					deftype = exts.DataType;
				}

				if (exts.Label)
				{
					this._label = exts.Label;
				}

				if (exts.Editor)
				{
					this._editor = exts.Editor;

					switch (this._editor)
					{
						case 'checkbox':
							this.tvalue = function()
							{
								return exts.Value;
							};
							this.fvalue = function()
							{
								return exts.FalseValue;
							};
							break;
						case 'radiogroup':
							this._dataModel = exts.data;
							if (exts.data)
							{
								var data = [];
								_$.each(exts.data, function(value, label)
								{
									data.push({value: value, label: label});
								});
								this._dataModel = data;
							}
							break;
						default:
							break;
					}
				}
			}

			var type = member.indexOf('DATE') !== -1 && Frames.isUndef(deftype) ? 'Date' : deftype || 'String';
			this._props = {AllowSearch: allowSearch, Visible: true, type: type, block: block.name, member: member, Editor: this._editor};

			this.elem = $('<div id="' + Frames.uuid() + '"><input></div>');

			if (exts && member.indexOf('USER') >= 0)
			{
				this.restrictCase('upper');
			}

			// Stores original item if exists
			this.item = block.get(member);
			if (!Frames.isUndef(this.item))
			{
				if (Frames.isUndef(exts.Editor))
				{
					var editorType =  this.item.widgetcls();
					switch (editorType)
					{
						case 'datefield':
							editorType = 'calendar';
							break;
						case 'checkbox':
							editorType = 'checkbox';
							this.tvalue = function()
							{
								return exts.Value;
							};
							this.fvalue = function()
							{
								return exts.FalseValue;
							};
							break;
						case 'lovinput':
							editorType = 'lovbox';
							break;
						case 'combobox':
							editorType = 'combobox';
							break;
						case 'radiogroup':
							this._dataModel = exts.data;
							if (exts.data)
							{
								var data = [];
								_$.each(exts.data, function(value, label)
								{
									data.push({value: value, label: label});
								});
								this._dataModel = data;
							}
							editorType = 'radiogroup';
							break;
						default:
							editorType = 'textinput';
					}
					this._props.Editor = editorType;
				}

				if (Frames.isUndef(exts.Label))
				{
					this._label = this.item.label();
				}
			}

			// registered extension for this member
			var regExtension = block.getbnd(this.objid());

			if (!Frames.isUndef(this.item) && this.item.bindable().isContext())
			{
				delete this.item;
				// Binds will be called from the bindable() - datagrid/repeater
				// remove existing extension bind if exists
				if (!Frames.isUndef(regExtension))
				{
					regExtension.destroy();
				}
			} else
			{
				// Alhough we can have more than one extension for the same item ( multiple filter panels from the same block)
				// only register the extension once.
				if (Frames.isUndef(regExtension))
				{
					// Register extension as bindable or replace the original item if this.item exists
					if (!Frames.isUndef(this.item))
					{	// Override extension item id by the original one
						this.objid = function(){
							return this.item.objid();
						};
					}
					block.bindable(this);
				}
			}

			Frames.Modes.enter('SEARCH', this);

			// Bind will not occur after the item has been created, so we need to execute it manually
			this._loadDynModel();
		},

		_loadDynModel: function()
		{
			var lstName = this.block.name + '.' + this.member;
			var lstData = this.block.task.list(lstName);
			if (!Frames.isUndef(lstData))
			{
				this.dynmodel(lstData);
			}
		},

		dataModel: function()
		{
			return this._dataModel;
		},

		dynmodel: function(data)
		{
			if (!Frames.isUndef(data) && !Frames.isEmpty(data.listElement))
			{
				var model = [];
				for (i = 0; i < data.listElement.length; i++)
				{
					var elem = data.listElement[i];
					var opt = {};
					opt.value = elem['@data'];
					opt.label = elem['@label'];
					model.push(opt);
				}
				this._dataModel = model;
			}
		},

		model: function()
		{
			// getter
			if (arguments.length === 0)
			{
				if (this.block._ctrinf['@blockMode'] != 'SEARCH')
				{
					return null;
				}
				else
				{
					return Frames.Item.prototype.model.apply(this, arguments);
				}
			}

			// setter
			else
			{
				Frames.Item.prototype.model.apply(this, arguments);

				var v = this.value();
				if (Frames.isEmpty(v))
				{
					this.visible(false);
				}
				else
				{
					this.visible(true);
				}
			}
		},

		value: function()
		{
			if (arguments.length === 0)
			{
				return this._value || '';
			}
			else
			{
				this._value = arguments[0];
			}
		},

		label: function()
		{
			if (arguments.length === 0)
			{
				if (!this._label && this._isextension)
				{
					return _(this._name);
				}
				else
				{
					return this._label;
				}
			}
			else
			{
				this._label = arguments[0];
			}
		},

		destroy: function()
		{
			if (this.item)
			{
				// Restore the original item if exsits
				this.block.bindable(this.item);
			} else
			{
				// remove the extension from bindables
				this.block.remove(this);
			}

			Frames.Item.prototype.destroy.call(this);
		},

		objid: function()
		{
			// Override object id to allow only regist 1 extension for each member.
			return this.view.id + ':ext-' + this.member.toLocaleLowerCase();
		},

		widgetcls: function()
		{
			return this._props.type == 'Date' ? 'datefield' : 'textinput';
		}
	});
//# sourceURL=app/flat/widgets/filterpanel/js/frames.filterpanel.js