{
	// the widget definition, where 'workspace' is the namespace,
	// 'workspacefooter' the widget name
	_$.widget('workspace.notificationsmenu',
	{
		// default options
		options: {
			container: document.body,
			template_main: '/base/widgets/notificationsmenu/html/notificationsmenu.tmpl.html#notifications-template',
			template_item: '/base/widgets/notificationsmenu/html/notificationsmenu.tmpl.html#notifications-item-template',
			button_force: false,
			types: {
				success: 'success',
				info: 'info',
				information: 'info',
				warning: 'warning',
				error: 'danger',
				danger: 'danger'
			},
			icons: {
				success: 'fa fa-check-circle',
				info: 'fa fa-info-circle',
				warning: 'fas fa-exclamation-triangle',
				danger: 'fa fa-exclamation-circle'
			}
		},

		// the constructor
		_create: function()
		{
			var that = this;
			var appsroot = Frames.Config.get('APPS_ROOT', '.');
			this.templates = {};

			Frames.Template.get(appsroot + this.options.template_main, function(result) {
				that.templates.main = result;
				that._refresh();
				if (!Frames.isUndef(that.templates.item))
				{
					that._afterTemplate();
				}
			});
			Frames.Template.get(appsroot + this.options.template_item, function(result) {
				that.templates.item = result;
				if (!Frames.isUndef(that.templates.main))
				{
					that._afterTemplate();
				}
			});

			var _resize_fn = function()
			{
				if (that.element.hasClass('open'))
				{
					if (!Frames.isTrue(that.hasAlerts()))
					{
						that.hide();
					}
				}
			};

			if (integrationMode != 'EXPERIENCE')
			{
				_$(window).on('resize', _resize_fn);
			}
		},

		_afterTemplate: function()
		{
			this._ready = true;

			if (!Frames.isUndef(Frames.Workspace._workspaceReady))
			{
				Frames.Workspace._workspaceReady.notificationsmenu = true;
			}

			if (Frames.isFunction(this.options.onready))
			{
				this.options.onready();
			}
		},
		// events bound via _on are removed automatically
		// revert other modifications here
		_destroy: function()
		{
			// ...
		},

		// called when created, and later when changing options
		// and menu methods
		_refresh: function()
		{
			var that = this;

			if (!this.templates.main)
			{
				return;
			}

			if (!this._initialized)
			{
				this._initialized = true;

				var html = this.templates.main({});
				this.element.html(html);

				this.$menu = _$('.workspace-notifications-menu', this.element);
				this.$toggle = _$('a.notification-toggle', this.element);

				this.$toggle.on('click', function()
				{
					if (that.$menu.find('button').length === 0 || !alert.popup)
					{
						that.toggle();
					}
					return false;
					// the "return false" above prevents weird bug in IE10, because without it, the beforeunload event MIGHT be executed on the window!
					// for more details see:
					// http://stackoverflow.com/questions/26405439/why-ie10-fires-beforeunload-event-when-clicking-on-anchor-element-with-javascrip
					// http://stackoverflow.com/questions/17826032/onbeforeunload-issue-in-ie-browser
				});

				Frames.Application.trigger('notificationsInitComplete', this);
			}
		},

		isReady: function()
		{
			return Frames.isTrue(this._ready);
		},

		hasNotifications: function()
		{
			return this.element.hasClass('open');
		},

		hasAlerts: function()
		{
			var lst = this._getAlerts();
			return (lst && lst.length > 0);
		},

		hasMessages: function()
		{
			var lst = this._getMessages();
			return (lst && lst.length > 0);
		},

		_getAlerts: function()
		{
			if (Frames.Application.task)
			{
				if (!Frames.Application.task._ALERTS_)
				{
					Frames.Application.task._ALERTS_ = [];
				}
				return Frames.Application.task._ALERTS_;
			}
			return [];
		},

		_getMessages: function()
		{
			if (Frames.Application.task)
			{
				if (!Frames.Application.task._MESSAGES_)
				{
					Frames.Application.task._MESSAGES_ = [];
				}
				return Frames.Application.task._MESSAGES_;
			}
			return [];
		},

		_clearMessages: function()
		{
			if (Frames.Application.task)
			{
				Frames.Application.task._MESSAGES_ = [];
			}
		},

		closeMessage: function()
		{
			var alerts = this._getAlerts();
			if (alerts.length > 0)
			{
				var o = alerts[alerts.length - 1];
				if (!o.popup)
				{
					alerts.pop();
					this.close();
				}
			}
		},

		toggle: function()
		{
			var action; 
			if (this.element.hasClass('open'))
			{
				//this.element
				this.hide();
				action = 'hide';
			}
			else
			{
				this.open(true);
				action = 'show';
			}

			Frames.Application.trigger('handlenotifications', {action: action});
		},

		clear: function()
		{
			if (!this.isReady())
			{
				return;
			}

			this.empty();
			/*if (Frames.Application.task)
			{
				Frames.Application.task._ALERTS_ = [];
			}*/
			this.close();
		},

		hide: function()
		{
			this._toggle = true; // hack
			this.close();
			delete this._toggle;
		},

		open: function(force)
		{
			var alerts = this._getAlerts();
			if (force || alerts.length > 0)
			{
				this.element.addClass('open');
				var height = _$('body > .workspace-container').css('height');
				this.element.find('.scrollable-menu').css('max-height', height);
				this.element.addClass('show');

				//this.element.attr('style','display: block !important');
				//this.element.css("display", "block !important");
				//this.element.show();

			}
		},

		close: function(close)
		{
			if (!this.isReady())
			{
				return;
			}

			Frames.Workspace.arianotify();

			this.element.removeClass('open');

			if (this.$container)
            {
                this.$container.unblock();
            }

			if (!this._toggle)
			{
				this._clearMessages();
				this.empty(); // for now we need to clear all msg
			}

			var alerts = this._getAlerts();

			if (close)
			{
				alerts.pop();

				if (alerts.length > 0)
				{
					var o = alerts[alerts.length - 1];
					this._alert(o);
				}

				// else if (!Frames.isEmpty(Frames.Workspace._message))
				// {
				// 	Frames.Workspace.showMessage(Frames.Workspace._message);
				// 	Frames.Workspace._message = '';
				// }
			}

			if (!this._toggle)
			{
				this._updatecount();

				if (alerts.length === 0)
				{
					this.element.removeClass('show');
				}
			}
		},

		message: function(message, type, callback)
		{
			if (!this.isReady())
			{
				return;
			}

			var o = this._createObject(undefined, message, type, undefined, false, callback);
			this._getMessages().push(o);
			this._alert(o);
		},

		alert: function(title, message, type, btns, popup)
		{
			if (!this.isReady())
			{
				return;
			}

			var o = this._createObject(title, message, type, btns, popup);
			this._getAlerts().push(o);
			this._alert(o);
		},

		_createObject: function(title, message, type, btns, popup, callback)
		{
			type = type ? type.toLowerCase() : undefined;
			popup = Frames.isUndef(popup) ? true : popup;
			var atype = this.options.types[type] || this.options.types.information;
			var o = {
				id: Frames.uuid(),
				title: title ? _$.escapeHtml(title): undefined,
				message: message,
				type: atype,
				icon: this.options.icons[atype],
				btns: btns,
				popup: popup,
				callback: callback
			};
			return o;
		},

		_alert: function(alert)
		{
			if (!this.isReady())
			{
				return;
			}

			var that = this;
			var buttons = [];
			var buttons_k = {};

			if (!this.$container)
			{
				this.$container = _$(this.options.container);
			}

			if ((this.options.button_force && !this.hasNotifications()) || alert.popup)
			{
				if (Frames.isUndef(alert.btns))
				{
					alert.btns = {};
					alert.btns[_(Frames.Locale.messages.OK)] = function()
					{
						Frames.focus();
					};
				}

				_$.each(alert.btns, function(k, f)
				{
					var accessKey = k && k[0].toUpperCase();

					if (!Frames.isUndef(f.accessKey))
					{
						accessKey = f.accessKey;
					}

					var btn = {
						id: Frames.uuid(),
						label: k,
						click: f.callback,
						accessKey: accessKey
					};
					buttons.push(btn);
					buttons_k[btn.id] = btn;
				});

				alert.buttons =  buttons;
			}

			if (alert.popup)
			{
				this.clear(); // for now we need to clear all msg
			}

			Frames.Workspace.arianotify(alert.message, alert.popup ? 'alert' : undefined, undefined, alert.type);

			var $item = _$(this.templates.item(alert));
			this.$menu.prepend($item);

			var $buttons = _$();
			if (alert.popup)
			{
				$buttons = _$('[data-uuid=' + alert.id + '].notification-buttons button', this.$menu);
				$buttons.on('click', function()
				{
					var $el = _$(this);
					var id = $el.attr('id');

					_$('[data-uuid=' + alert.id + ']', this.$menu).remove();

					buttons_k[id].click();

					that.close(true);
				});
				$buttons.parent().trap();
			}
			
			else if (Frames.isFunction(alert.callback) || this.options.button_force)
			{
				_$('[data-uuid=' + alert.id + ']', this.$menu).on('click', function()
				{
					if (Frames.isFunction(alert.callback))
					{
						alert.callback();
					}
					
					that.toggle();
				});
			}

			this.open(true);

			if (alert.popup)
			{
				Frames.Workspace.blockUI(this.$container, {
					overlayCSS:  _$.extend({}, Frames.Loader.OVERLAY, {opacity: 0}),
					css: Frames.Loader.BOX,
					message: '',
					baseZ: 1099
				});

				Frames.later(function ()
				{
					$buttons.filter(':first').trigger('focus');
				});
			}

			this._updatecount();
			this.notifyChanges();
		},

		_updatecount: function()
		{
			if (!this.isReady())
			{
				return;
			}

			var count = _$('.notifications-item', this.$menu).length;
			this.$toggle.attr("data-count", count);

			if ( count > 0 )
			{
				this.$toggle.addClass("count-badge");
			}
			else
			{
				this.$toggle.removeClass("count-badge");
			}
		},

		hideNotifications: function()
		{
			_$(window).unblock();
			this.empty();
			_$('#notifications').removeClass('show open');
		},

		showNotifications: function()
		{
			var self = this;
			var alerts = this._getAlerts();
			var messages = this._getMessages();
			_$.each(alerts, function() {
				self._alert(this);
			});
			_$.each(messages, function() {
				self._alert(this);
			});
		},

		notifyChanges: function()
		{
			Frames.Application.trigger('notificationupdate',
			{
				messages: this._getMessages(),
				alerts: this._getAlerts(),
				empty: this.isEmpty()
			});
		},

		empty: function()
		{
			this.$menu.empty();
			this.notifyChanges();
		},

		isEmpty: function()
		{
			return this.$menu.is(':empty');
		}
	});
};

//# sourceURL=app/base/widgets/notificationsmenu/js/notificationsmenu.js
