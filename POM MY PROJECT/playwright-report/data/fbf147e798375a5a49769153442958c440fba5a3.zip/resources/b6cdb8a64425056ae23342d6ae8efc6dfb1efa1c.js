	var textinputFocus =  _$.ui.textinput.prototype.focus;

	_$.ui.textinput.prototype.focus = function()
	{
		if (Frames.Calculator.isModalOpen())
		{
			// Don't focus the editor.We want the focus in the modal widget
			return;
		} else
		{
			textinputFocus.apply(this, arguments);
		}
	};

	var input =  _$.ui.textinput.prototype.input;

	_$.ui.textinput.prototype.input = function()
	{
		return Frames.Calculator.isModalOpen() ? Frames.Calculator.widgetinput() : input.apply(this, arguments);

	};
//# sourceURL=app/flat/widgets/workspace/js/textinput.js
