{
	Frames.MenuItem = _$.inherit(
		Frames.Item,
	{
		__constructor: function(elem)
		{
			this.elem = elem;

			Frames.Item.prototype.__constructor(this, arguments);
		},

		input: function()
		{
			return this.elem;
		},

		value: _$.noop,
		model: _$.noop
	});

	Frames.MenuItem.create = function(objId, block, member)
	{
		var elem = $('#' + objId);
		elem.attr('data-block', block);
		elem.attr('data-member', member);
		elem.attr('data-widget', 'menuitem');

		return Frames.create(objId, elem, undefined, {_OBJS_: []});
	};

	Frames.regtype("menuitem", Frames.MenuItem);
};

//# sourceURL=app/flat/widgets/objects/js/menuitem.js