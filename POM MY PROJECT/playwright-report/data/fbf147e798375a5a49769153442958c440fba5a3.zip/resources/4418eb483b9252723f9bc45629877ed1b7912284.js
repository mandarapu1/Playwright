{
	var _initItem = Frames.Item.prototype.init;
	Frames.Item.prototype.init = function()
	{
		var that = this;

		_initItem.apply(this, arguments);

		var notInComponent = !Frames.isUndef(this.elem) && !this.elem.hasClass('ui-component') && !this.elem.parent().hasClass('ui-component');
		var isValid = !Frames.isUndef(this.elem) && this.elem.not('[data-widget=checkbox]').not('[data-widget=radiogroup]').not('[data-widget=radiobox]').length > 0;
		var inResponsiveLayout = !Frames.isUndef(this.elem) && this.elem.parent().hasClass('ui-layout-responsive');

		if (notInComponent && isValid && inResponsiveLayout)
		{
			ReponsiveKeyBlock.create(this.elem);

			this._endbind_fn = function()
			{
				ReponsiveKeyBlock.apply(that.elem);
			};
			Frames.Application.on('endbind', this._endbind_fn);
		}
	};

	var _autounregister = Frames.Item.prototype.autounregister;
	Frames.Item.prototype.autounregister = function()
	{
		_autounregister.apply(this, arguments);
		if (!Frames.isUndef(this._endbind_fn))
		{
			Frames.Application.off('endbind', this._endbind_fn);
		}
	};

	var _createComponent = _$.ui.component.prototype._create;
	_$.ui.component.prototype._create = function()
	{
		_createComponent.apply(this, arguments);

		if (this.element.parent().hasClass('ui-layout-responsive'))
		{
			ReponsiveKeyBlock.create(this.element);
		}
		else
		{
			var self = this;
			var task = Frames.Application.task;
			if (task)
			{
				// registering the event on ALL child widgets,
				// because the calculation has to occur after ALL widgets have been initialized
				// their initialization may change the DOM and impact on the total width.
				// right now the calculation will be made several times (as many widgets are inside the component), but that's safer
				// if we could identify the timing where all widgets have finished initialization it would be better
				var $el = this.element.children('[data-widget]');
				var forceComputeWidth = function()
				{
					self.computeComponentWidth(true);
				};
				$el.on('frames:labelstyle', forceComputeWidth);
				$el.on('frames:visible', forceComputeWidth);

				this.element.on('frames:refresh', function(e)
				{
					self.computeComponentWidth(e.data ? e.data.repaint : false);
				});

				this._resize_fn = forceComputeWidth;

				//instanceid is created in core component.js. Force the same logic to prevent errors if removed from the core
				this.instanceid = this.instanceid || this.element.attr('id') || Frames.uuid();
				_$(window).on('resize.component-' + this.instanceid, this._resize_fn);
			}
		}
	};

	var _destroyComponent = _$.ui.component.prototype._destroy;
	_$.ui.component.prototype._destroy = function()
	{
		_destroyComponent.apply(this, arguments);

		_$(window).off('resize.component-' + this.instanceid, this._resize_fn);
	};

	_$.ui.component.prototype.updateComponents = function()
	{
		if (_$(this.element).parents('.keyblock').length === 0)
		{
			return;
		}

		var $widgets = _$('> [data-widget]', this.element)
			.not('[data-widget=checkbox]')
			.not('[data-widget=radiogroup]')
			.not('[data-widget=radiobox]')
			.not('[data-widget=fileinput]');
		$widgets.each(function()
		{
			ReponsiveKeyBlock.apply($(this));
		});
	};

	_$.ui.component.prototype.computeComponentWidth = function(force)
	{
		if (this.element.css('position') === 'relative' &&
			(this.element[0].style.width === '' || (force && this._computedWidth)))
		{
			// not needed but just to make sure
			var isresponsive = this.element.parent().hasClass('ui-layout-responsive');
			if (isresponsive)
			{
				return;
			}

			var $last = this.element.children('[data-widget]').last();
			var hasdescription = $last.data('widget') === 'textfield';
			if (hasdescription)
			{
				return;
			}

			if (this.options.repeater && force !== true)
			{
				return;
			}

			var w1 = 'auto';
			if (this._computedWidth)
			{
				this.element[0].style.width = '';
			}


			var len = this.element.children('[data-widget]').length;
			if (len == 1)
			{
				var $first = this.element.children('[data-widget]').first();
				if ($first.data('widget') == 'checkbox')
				{
					var $lbl = this.element.children('label');
					var $firstLbl = $first.children('label');

					$firstLbl.hide();

					this.element.width('100%');
					var w = this.element.outerWidth(true);
					var buttonW =  $first.children('button').outerWidth(true);
					var firstlblW = w - $lbl.outerWidth(true) - buttonW - 10;

					$firstLbl.show();
					$firstLbl.css({
						width: firstlblW
					});

					this._computedWidth = true;
					return;
				}
			}

			var whiteSpace = this.element[0].style.whiteSpace;

			// ui-component-maximize is used to determine the absolute maximum size
			// eg: state dependent font weights changes an elements width
			this.element.addClass('ui-component-maximize');
			this.element.css('white-space', 'nowrap');

			var w2 = this.element[0].scrollWidth;
			this.element.width(w2 === 0 ? w1 : w2);
			this._computedWidth = true;

			// reset original styles
			this.element.css('white-space', whiteSpace);
			this.element.removeClass('ui-component-maximize');
		}
	};

	var _input= _$.ui.textinput.prototype.input;
	_$.ui.textinput.prototype.input = function()
	{
		var $input;

		var $span = _$('span.ui-input-readonly', this.element);
		if ($span.length > 0)
		{
			var $parent = this.element.parent();
			// responsive class will be in div not in component
			$parent = !$parent.hasClass('ui-component') ? $parent : $parent.parent();
			if ($parent.hasClass('ui-layout-responsive'))
			{
				$input = $span;
			}
		}

		return !Frames.isUndef($input) ? $input : _input.apply(this, arguments);
	};

	var ReponsiveKeyBlock = {
		create: function($elem)
		{
			// remove float lefts
			$elem.find('label').css('float', '');

			var $widget = _$('div.ui-buttoninput', $elem);
			$widget.each(function()
			{
				var $w = $(this);
				var $el = $w.next();
				while ($el.is('button'))
				{
					var $e = $el.next();
					$el.appendTo($w);
					$el = $e;
				}
			});
		},

		applyResponsiveness: function($elem)
		{
			var $el = $elem.children('input').first();
			var $span = _$('span.ui-input-readonly', $elem);
			var $p = $el.parent();
			var dir = $el.attr('dir');

			var task = Frames.Application.task;
			if (task)
			{
				var $win = task._container || task.view.window();
				var $btn = _$('.keyblock-button-container button[data-action=CLEAR-FORM]', $win);
				if ($btn.length > 0)
				{
					if ($btn.is(':visible') || $elem.hasClass('ui-description'))
					{
						if ($elem.hasClass('ui-state-disabled') || $elem.hasClass('ui-state-readonly'))
						{
							$el.hide();

							if ($span.length === 0)
							{
								$span = _$('<span class="ui-widget-content ui-input-readonly"></span>');
								// allow span focus
								$span.attr('tabindex', 0);
								// allow update footer current item
								$span.data('frames', $el.data('frames'));

								$p.find('label').after($span);
							}

							if (!Frames.isUndef(dir))
							{
								$span.attr('dir', dir);
							}

							if ($el.css('text-transform') != 'none')
							{
								$span.css('text-transform', $el.css('text-transform'));
							}
							if ($el.attr('type') == 'password')
							{
								var maskValue = $el.val().replace(/./g, '*');
								$span.html(maskValue);
								$span.attr('title', maskValue);
							}
							else
							{
								$span.html(_$.escapeHtml($el.val()));
								$span.attr('title', $el.val());
							}

						}
						else
						{
							if ($span.length > 0)
							{
								$span.remove();
								$el.show();
								// force that element is enabled
								$el.removeAttr('disabled');
							}
						}
					}
					else
					{
						if ($span.length > 0)
						{
							$span.remove();
							$el.show();
							// force that element is enabled
							if (!$elem.hasClass('ui-state-disabled'))
							{
								$el.removeAttr('disabled');
							}
						}
					}
				}
			}
			
		},

		applyNA: function($elem)
		{
			var $el = $elem.children('input').first();
			var $span = _$('span.ui-input-readonly', $elem);
			if ($el.length === 0)
			{
				if ($elem.is('button') && $elem.is('.ui-buttoninput'))
				{
					return;
				}
				else if ($elem.is('[data-widget="datefield"], [data-widget="textfield"]'))
				{
					// ex: date fields don't have input
					$el = $elem.children('span').first();
					$span = $el;
				}
			}

			var labelIsVisible = true;
			var itemLabel = $elem.parent().find('label[for="' + $el.attr('id') + '"]');
			if (itemLabel.length > 0)
			{
				labelIsVisible = itemLabel.is(':visible');
			}

			var elValue = $el.val();
			if ($el.is('span'))
			{
				elValue = $el.html();
			}

			if (elValue === '' && !$elem.is('.ui-description') && labelIsVisible)
			{
				$span.html(_('NOT_APPLICABLE'));
				$span.addClass('ui-notapplicable');
			}
			else
			{
				$span.removeClass('ui-notapplicable');
			}
		},

		apply: function($elem)
		{
			this.applyResponsiveness($elem);
			// this.applyNA($elem);
		}
	};

};

//# sourceURL=app/flat/widgets/component/js/component.js
