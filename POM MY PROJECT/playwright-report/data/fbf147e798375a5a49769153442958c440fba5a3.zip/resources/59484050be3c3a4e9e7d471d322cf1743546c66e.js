/*
 * Frames Calculator @VERSION
 *
 * Depends:
 *   jquery.ui.core.js
 *   jquery.ui.widget.js
 */
{

	//
	// Calculator jQuery Widget
	//
	_$.widget('ui.xcalculator',
	{
		version: '@VERSION',
	
		options:
		{
			button: true,
			grid: false,
			calcType: 'standard',
			layoutStandard: ['  BSCECA', '_7_8_9_+@X', '_4_5_6_-@U', '_1_2_3_*@E', '_0_._=_/'],
			showFormula: false,
			maxDigits: 12,
			inline: false,
			onSelect: undefined,
			value: undefined
		},
	
		_create: function()
		{
			Frames._Calculator.init();
	
			this.element.addClass('ui-widget ui-calculator ui-buttoninput');
	
	
			var onSelect = this.options.onSelect ?  this.options.onSelect :  _$.proxy(this._onSelect, this);
			// Override the jquery.calculator standard layout if it is a standard calculator
			var layoutType = this.options.calcType === 'standard' ? this.options.layoutStandard : $.calculator[this.options.calcType + 'Layout'];
	
			var options = {
				showOn: 'button',
				// buttonImage: 'app/widgets/textinput/css/img/calculator.png',
				useThemeRoller: true,
				layout: layoutType,
				showFormula: this.options.showFormula,
				prompt: '',
				showAnim: '',
				onOpen: _$.proxy(this._onOpen, this),
				onClose: onSelect,
				onButton: _$.proxy(this._onButton, this),
				onErase: _$.proxy(this._onErase, this),
				onAdd: _$.proxy(this._onAdd, this),
				onSubtract: _$.proxy(this._onSubtract, this),
				onMultiply: _$.proxy(this._onMultiply, this),
				onDivide: _$.proxy(this._onDivide, this),
				constrainInput: false
			};
	
			var regOptions = ($.calculator.regionalOptions[Frames.Locale.lang] || $.calculator.regionalOptions['']);
			regOptions.decimalChar = Frames.Locale.formats.DECIMAL_SEPARATOR;
	
			if (!this.options.inline)
			{
				this._lbl = _$('label', this.element);
				this._inp = _$('input', this.element); /*.remove().attr("type", "date").insertBefore(this._lbl);*/
	
				if (Frames.Locale.formats.IS_RTL)
				{
					this._inp.attr('dir', 'ltr');
				}
	
				// calculator needs diferent IDs
				this._inp.attr('id', this.element.attr('id') + new Date().getTime());
				this._lbl.attr('for', this._inp.attr('id'));
	
				this._inp.addClass('ui-widget-content');
	
				this._inp.calculator(options);
				this._inp.calculator('option', regOptions);
	
				this.button = this.element.find('button');
				if (this.showButton())
				{
					this._inp.removeClass('ui-corner-all')
						.addClass('ui-corner-left');
	
					// add theme to button
					this.button
						.attr('tabIndex', -1)
						.button({
							icon: 'fa fa-calculator',
							text: false
						})
						.attr('title', null)
						.removeClass('ui-corner-all')
						.addClass('ui-state-default ui-corner-right ui-button-icon ui-button-icon-only');
	
					// Disable button double click to avoid the modal opening
					this.button.on('dblclick', function(e)
					{
						e.preventDefault();
						e.stopImmediatePropagation();
					});
				}
				else
				{
					this.button.hide();
				}
			}
			else
			{
				if (this.options.value)
				{
					options.value = this.options.value;
				}
	
				options.showOn = 'focus';
	
				this.element.calculator(options);
				this.element.calculator('option', regOptions);
			}
	
			this.refresh();
		},
	
		showButton: function()
		{
			var btn = this.element.data('button');
			return this.options.button && (Frames.isUndef(btn) || btn != 'hide');
		},
	
		// fix input and button sizes
		refresh: function(force)
		{
			if (this.showButton())
			{
				if (force || (this._inp.is(':visible')/* && Frames.isUndef(this._size)*/))
				{
					var w = this._inp.outerWidth();
					var h = this._inp.outerHeight();
	
					if (Frames.isUndef(this._size))
					{
						this._size = this._inp.outerHeight();
						w = this._inp.outerWidth() - this._size;
						h = this._size;
					}
	
					var css =  {};
					if (this.options.grid)
					{
						css.right = 0; // -this._size;
					}
					else if (this.element.css('position') === 'absolute')
					{
						css.left = w;
					}
					else
					{
						css.left = '';
					}
	
					this.button.css({
						width: this._size,
						height: Frames.isTrue(this.options.grid) ? this.element.parent().outerHeight() - 2 : h
					});
	
					if (true /*this._lbl.index() >= 1*/ || Frames.isTrue(this.options.grid))
					{
						this.button.css(css);
					}
					this._inp.css('width', w);
				}
			}
		},
	
		_destroy: function()
		{
			this.element.removeClass('ui-calculator ui-widget');
			if (this._inp)
			{
				this._inp.removeClass('ui-widget-content ui-corner-left');
				this._inp.data('frames', null);
			}
			this._inp = null;
			this._lbl = null;
			delete this._inp;
			delete this._lbl;
		},
	
		wrapper: function(obj)
		{
			// TODO: think a better way to link to the main object
			this._inp.data('frames', obj);
		},
	
		input: function()
		{
			return Frames.Calculator.isModalOpen() ? Frames.Calculator.widgetinput() : this._inp;
		},
	
		value: function()
		{
			return this._inp.val.apply(this._inp, arguments);
		},
	
		format: _$.noop,
	
		label: function()
		{
			if (arguments.length > 0)
			{
				this._lbl.text(arguments[0]);
			}
			else
			{
				return this._lbl.text();
			}
		},
	
		labelObj: function()
		{
			return this._lbl;
		},
	
		buttonObj: function()
		{
			return this.button;
		},
	
		focus: function()
		{
			// Don't focus the input if widget is open in a modal. we want the focus in the modal widget
			if (this.design() || Frames.Calculator.isModalOpen())
			{
				return;
			}
	
			Frames.applySelect(this._inp, true);
		},

		setDescriptionContext: $.ui.textinput.prototype.setDescriptionContext,
	
		design: function()
		{
			var wrap = this._inp.data('frames');
			return wrap ? wrap.design() : Frames.inDesignMode;
		},
	
		openDialog: function()
		{
			this._inp.calculator('show');
		},
	
		closeDialog: function()
		{
			this._inp.calculator('hide');
		},
	
		isDialogOpened: function()
		{
			return _$('.ui-widget.calculator-popup').is(':visible');
		},
	
		_onOpen: function(value, inst)
		{
			this._useButtonTyped = false;
	
			var grid = Frames.isTrue(this.options.grid);
			var f = Frames.Format.unformat(value, ''/*item.props("format")*/, 'Number'/*item.props("type")*/);
			var item = this._inp.data('frames');
	
			if (Frames.isUndef(item) && grid)
			{
				item = this._inp.parent().data('frames');
			}
	
			if (Frames.isUndef(item))
			{
				return;
			}
	
			inst._mainDiv.css({
				zIndex: this._inp.closest('.ui-dialog').css('z-index') || Frames.Application.task.view.getCanvasCount() + 1
			});
	
			inst._input.val(f);
		},
	
		_onSelect: function(value, inst)
		{
	
			var grid = Frames.isTrue(this.options.grid);
			var item = this._inp.data('frames');
	
			if (Frames.isUndef(item) && grid)
			{
				item = this._inp.parent().data('frames');
			}
	
			if (Frames.isUndef(item))
			{
				return;
			}
	
			var format = item.props('format') || Frames.Locale.formats.NUMBER_FORMAT;
			var f = Frames.Format.format(value, format , 'Number' /*item.props("type")*/);
	
			item.value(f);
	
			if (grid)
			{
				item.input().val(f);
			}
	
			if (this._useButtonTyped)
			{
				this.selectedHandler(value);
			}
		},
	
		_onButton: function(label, value, inst)
		{
			if (value.length > this.options.maxDigits)
			{
				var fixedVal = value.slice(0,-1);
	
				inst._formula = fixedVal;
				inst.dispValue = fixedVal;
			}
	
			inst.__lastButton = label;
	
			if (label == inst.options.useText)
			{
				this._useButtonTyped = true;
			}
		},
	
		// Override calculator erase method to don't close the widget
		_onErase: function(inst, label)
		{
			$.calculator._reset(inst, 0);
			$.calculator._updateCalculator(inst);
		},
	
		// Override jquery calculator methods to use Big Objects
		_onAdd: function(inst) {
			inst.curValue = new Big(inst.prevValue).add(inst.curValue).toFixed();
		},
	
		_onSubtract: function(inst) {
			inst.curValue = new Big(inst.prevValue).sub(inst.curValue).toFixed();
		},
	
		_onMultiply: function(inst) {
			inst.curValue = new Big(inst.prevValue).mul(inst.curValue).toFixed();
		},
	
		_onDivide: function(inst) {
			inst.curValue = new Big(inst.prevValue).div(inst.curValue).toFixed();
		},
	
		selectedHandler: function(num)
		{
			Frames.Log.debug('calculator:selectedHandler %s', num);
			Frames.Log.debug('calculator:selectedHandler _inp.val() =%s', this._inp.val());
	
			Frames.Application.elemexec(this.element);
		},
	
		processNavigationKey: function(key)
		{
			var mode = Frames.Config.get('NAVIGATION_MODE', 'default');
			if (mode === 'all')
			{
				if (key === 'TAB' || key === 'SHIFT+TAB')
				{
					var input = this.input();
					var button = this.buttonObj();
					if (key === 'TAB' && document.activeElement === input[0])
					{
						button.trigger('focus');
						return true;
					}
					else if (key === 'SHIFT+TAB' && document.activeElement === button[0])
					{
						this.input().trigger('focus');
						return true;
					}
				}
			}
			return false;
		}
	
	});
	
	//
	// Calculator Widget Wrapper
	//
	_$.extend(Frames.Calculator, 
		{
			clickable: function() { return true; },
	
			format: function()
			{
				if (arguments.length === 0)
				{
					return Frames.Item.prototype.format.apply(this, arguments);
				}
				else
				{
					this._call('format', arguments[0]);
					Frames.Item.prototype.format.apply(this, arguments);
				}
			},
	
			erroranchor: function()
			{
				return this.buttonObj();
			},
	
			buildXvcPropsMap: function() {
				var propsMap = Frames.TextInput.prototype.buildXvcPropsMap.apply(this, arguments);
				delete propsMap.multiline;
				return propsMap;
			}
		},
		{
			isModalOpen: function()
			{
				var calculator = _$('#widget-dialog.ui-calculator');
				return calculator.is(':visible') && calculator.hasClass('widget-inline');
			},
	
			widgetinput: function()
			{
				return _$('#widget-dialog > .calculator-keyentry');
			},
	
			openInDialog: function(currvalue)
			{
	
				var container = _$('<div id="widget-dialog" title="Calculator" style="width:200px"/>');
				container.appendTo('body');
	
	
				//create overlay
				_$('<div class="modal-backdrop show"></div>').appendTo('body');
	
				currvalue = parseFloat(currvalue);
				container.xcalculator(
				{
					value: currvalue,
					button: false,
					inline: true,
					onSelect:  function(val, inst)
					{
						if (inst.__lastButton && inst.__lastButton === inst.options.closeText)
						{
							// If close button was the last clicked, value shouldn't be updated. WIDGET_CANCEL action should be sent to server
							val = undefined;
							delete inst.__lastButton;
						}
						Frames.Calculator._onWidgetClose(val);
					}
				});
	
				var top = (_$(window).height() / 2) - (container.height() / 2) + 'px';
				var left = (_$(window).width() / 2) - (container.width() / 2) + 'px';
	
	
				container.modal(
					{
						keyboard: false
					});
	
				var css = {
					top: top,
					zIndex: _$('.modal-backdrop').css('zIndex') + 1
				};
	
				if (Frames.Locale.formats.IS_RTL)
				{
					css.right = left;
				}
				else
				{
					css.left = left;
				}
	
				container.css(css);
				container.addClass('widget-inline');
				container.on('hide', function() {
	
					Frames.Calculator._onWidgetClose();
				});
	
				Frames.Calculator.widgetinput().focus();
	
				//close calculator when clicking on the overlay
				_$('.modal-backdrop').on('click', function() {
					Frames.Calculator._onWidgetClose();
				});			
			},
	
			_onWidgetClose: function(val)
			{
				var payload;
	
				if (!Frames.isUndef(val))
				{
					val = Frames.Format.formatToCanonical(val, Frames.Locale.formats.NUMBER_FORMAT, 'Number');
	
					payload = {
						name: 'WIDGET_OK',
						params: [
						{
							name: 'value',
							value: val,
							type: 'String'
						}]
					};
				}
				else
				{
					payload = {
						name: 'WIDGET_CANCEL'
					};
				}
	
				Frames.Application.execute(payload, null, null, null, null, false);
	
				_$('.modal-backdrop').remove();
				_$('#widget-dialog').remove();
	
			},
	
			hideWidget: function()
			{
				_$('.calculator-popup').hide();
			}
		}
	);
	
	Frames.Application.on('execute', function(ev, result)
	{
		Frames.Calculator.hideWidget();
	});
	
	Frames.regtype('calculator', Frames.Calculator);
	
	}
	
	//# sourceURL=app/flat/widgets/calculator/js/frames.calculator.js
	