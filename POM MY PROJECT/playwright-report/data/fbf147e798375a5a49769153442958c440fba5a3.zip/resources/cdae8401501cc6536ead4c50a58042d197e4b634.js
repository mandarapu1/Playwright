{
	Frames.Workspace = _$.extend({},
	{
		CONFIG: { welcome: true },

		DEFAULT_TOOLS: [
			{ id: 'toolbar', type: 'section', label: _('ACTIONS'), items: [
				{ id: 'tb-rollback', action: 'CLEAR-FORM', label: _('REFRESH')},
				{ id: 'tb-export', action: 'EXPORT', label: _('EXPORT')},
				{ id: 'tb-print', action: 'PRINT', label: _('PRINT')},
				{ id: 'tb-scale', action: 'SCALE', label: _('PRINT_SCALE')},
				{ id: 'tb-record-clear', action: 'CLEAR_RECORD', label: _('CLEAR_RECORD') },
				{ id: 'tb-block-clear', action: 'CLEAR_BLOCK', label: _('CLEAR_BLOCK') },
				{ id: 'tb-item-props', action: 'ITEM_PROPERTIES', label: _('ITEM_PROPERTIES') }
			]}
		],

		init: function(options)
		{
			var that = this;

			Frames.Workspace._disableViewPreReady = true;
			Frames.Workspace._workspaceReady = {
				header: false,
				footer: false,
				notificationsmenu: false,
				verticalmenu: false,
			};

			Frames.Workspace.arianotifyAlertQueue = 0;
			Frames.Workspace.arianotifyMessageQueue = 0;

			Frames.Workspace.initialize();

			_$('.workspace-title', document.body).text(document.title);

			if (_$.workspace.workspaceheader)
			{
				if (Frames.Workspace.HEADER_CONFIG)
				{
					_$.workspace.workspaceheader.setup(Frames.Workspace.HEADER_CONFIG);
				}

				_$('.workspace-header').workspaceheader({
					onready: function()
					{
						if (_$.workspace.notificationsmenu)
						{
							_$('#notifications').notificationsmenu(
							{
								container: '.workspace-footer, .workspace-header, .workspace-container',
								onready: function()
								{
									that.componentready(options);
								}
							});
						}

						if (_$.workspace.verticalmenu)
						{
							if (Frames.Workspace.MENU_CONFIG)
							{
								_$.workspace.verticalmenu.setup(Frames.Workspace.MENU_CONFIG);
							}

							var _type = _$.workspace.verticalmenu.prototype.options.type;
							if (_type == 'horizontal')
							{
								_$('.workspace-header > .workspace-header-buttons').before('<div id="menu" class="container-fluid workspace-header-menu" data-widget="workspacemenu" data-block="$MAIN$_BLOCK" data-member="MENU_TREE"></div>');
							}
							else
							{
								_$(document.body).prepend('<nav id="menu" class="workspace-menu" data-widget="workspacemenu" data-block="$MAIN$_BLOCK" data-member="MENU_TREE"></nav>');
							}

							var verticalMenus = _$('#menu, .workspace-menu');
							var verticalMenuCount = verticalMenus.length;
							var verticalMenuReady = 0;

							verticalMenus.verticalmenu(
							{
								container: '.workspace-container',
								onready: function()
								{
									verticalMenuReady++;
									if (verticalMenuReady >= verticalMenuCount && !Frames.isUndef(Frames.Workspace._workspaceReady))
									{
										Frames.Workspace._workspaceReady.verticalmenu = true;
										that.componentready(options);
									}
								}
							});

							var tools = Frames.Workspace.DEFAULT_TOOLS ? Frames.Workspace.DEFAULT_TOOLS.slice(0) : [];
							var $tools = _$('#menu-tools');
							$tools.verticalmenu('option', 'items', tools);
							$tools.verticalmenu('option', 'click', Frames.Workspace._handleMenuClick);
						}

						if (_$.workspace.workspacetoolbar)
						{
							var _toolb = _$('#toolbar');
							if (_toolb.length === 0)
							{
								_$('.workspace-header').before('<nav id="toolbar" class="workspace-toolbar vertical-toolbar btn-group btn-group-vertical"></nav>');
							}

							if (Frames.Workspace.TOOLBAR_CONFIG)
							{
								_$.workspace.workspacetoolbar.setup(Frames.Workspace.TOOLBAR_CONFIG);
							}

							_$('.workspace-toolbar').workspacetoolbar();
						}
						else
						{
							Frames.ToolBar.init(_$());
						}

						// load template for firt tab
						if (Frames.Workspace.CONFIG && Frames.Workspace.CONFIG.welcome)
						{
							var approot = Frames.Config.get('APP_ROOT', '.');
							Frames.Template.get(approot + '/html/welcome.html#workspace-welcome', function(tpl) {
								_$('#tabs-1').html(tpl({ rtl: (_$('#tabs-1').css('direction') === 'rtl')}));
							});
						}

						// Tab container
						Frames.Application._container = _$('#tab-container');
						if (Frames.Application._container.tabs)
						{
							Frames.Application._container.tabs({
								activate: function(event, ui)
								{
									var tskId = ui.newTab.find('a').attr('href').substr(1);
									if (tskId != 'tabs-1')
									{
										Frames.Application._showTask(tskId);
									}
								}
							});
						}

						that.componentready(options);
					}
				});
			}

			if (_$.workspace.workspacefooter)
			{
				if (Frames.Workspace.FOOTER_CONFIG)
				{
					_$.workspace.workspacefooter.setup(Frames.Workspace.FOOTER_CONFIG);
				}

				_$('.workspace-footer').workspacefooter({
					onready: function()
					{
						that.componentready(options);
						_resize_fn();
					}
				});
			}


			if (_$.workspace.workspaceheader || _$.workspace.workspacefooter)
			{
				var _resize_fn = function()
				{
					// var h1 = $('.workspace-header').outerHeight();
					var h2 = _$('.workspace-footer').outerHeight();

					// $('.workspace-container').css('height', $(window).height() - (h1 + h2));
					_$('.workspace-container').css('bottom', h2);
				};
				_$('.workspace-container').on('resize', _resize_fn);
				Frames.Application.on('themeswitch', _resize_fn);
				_resize_fn();

				_$('.workspace-container').on('scroll', function(ev)
				{
					_$(window).triggerHandler('scroll', ev);
				});
			}

		},

		componentready: function(options)
		{
			if (!Frames.isUndef(Frames.Workspace._workspaceReady) &&
				!Frames.Workspace._workspaceReady.ready &&
				Frames.Workspace._workspaceReady.header &&
				Frames.Workspace._workspaceReady.footer &&
				Frames.Workspace._workspaceReady.notificationsmenu &&
				Frames.Workspace._workspaceReady.verticalmenu)
			{
				Frames.Workspace._workspaceReady.ready = true;

				Frames.StatusBar.init(_$('#status'));

				Frames._init(options);

				Frames.Workspace._disableViewPreReady = false;

				var task = Frames.Application.task;
				var view = task.view;
				var status = 'success';
				Frames.Application._viewPreReady(task, view, status);
			};
		},

		initialize: function()
		{
			// common code is executed in the init() method.
			// this should be extendend in other apps if needed.
		},

		hasNotifications: function()
		{
			var notifications = _$('#notifications');
			if (notifications.length === 0)
			{
				return false;
			}
			return notifications.notificationsmenu('hasNotifications');
		},

		hasAlerts: function()
		{
			var notifications = _$('#notifications');
			if (notifications.length === 0)
			{
				return false;
			}
			return notifications.notificationsmenu('hasAlerts');
		},

		hasMessages: function()
		{
			var notifications = _$('#notifications');
			if (notifications.length === 0)
			{
				return false;
			}
			return notifications.notificationsmenu('hasMessages');
		},

		showMessage: function(message, type, callback)
		{
			var $el = _$('#notifications');

			if (Frames.isEmpty(message))
			{
				if (type === undefined)
				{
					Frames.Workspace.closeAlert();
				}
			}
			else if ($el.length > 0)
			{
				if (!Frames.isFunction(callback))
				{
					message = _$.escapeHtml(message).replace(/\n/g, '<br>');
				}
				_$('#notifications').notificationsmenu('message', message, type || 'information', callback);
			}
			else
			{
				var task = Frames.Application.task;

				// if we don't have the notification widget let's check
				// if it's the login page or it's the first request
				if (task && task.view && Frames.Application.isWorkspaceView(task.view.id))
				{
					// we don't have no place to put messages on the login page
					// so just create a message alert

					var atp = (type && type.toLowerCase() == 'error') ? 'danger': 'warning';

					$el = _$('<div class="alert alert-' + atp + ' alert-dismissible alert-absolute-center fade show login-message" role="alert">' +
					'	<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
					message +
					'</div>').appendTo(document.body);

					if (Frames.isFunction($el.alert))
					{
					$el.alert().on('closed.bs.alert', function()
					{
						Frames.focus();
					});
				}
				}
				else
				{
					// almost sure it's the first request so display a system error
					Frames.Application._show_system_error('Error', message);
				}
			}
		},

		closeMessage: function()
		{
			var elem = _$('#notifications');
			if (Frames.isFunction(elem.notificationsmenu))
			{
				elem.notificationsmenu('close');
			}
		},

		showAlert: function(title, message, type, btns)
		{
			Frames.Workspace._showAlert(title, message, type, btns, true);
		},

		_showAlert: function(title, message, type, btns, popup)
		{
			if (typeof(title) == 'string')
			{
				title = title.replace(/[ ]+/g, '\u00a0');
			}
			if (typeof(message) == 'string')
			{
				message = _$.escapeHtml(message).replace(/\n/g, '<br>');
			}

			var icon = type ? type.toLowerCase() : 'normal';
			if (_$.inArray(icon, Frames.Workspace.VALID_ICONS) == -1)
			{
				icon = 'warning';
			}

			_$('#notifications').notificationsmenu('alert', title, message, type, btns, popup);
		},

		closeAlert: function(close)
		{
			if (!Frames.Application._container)
			{
				//remove workspace messages - login messages
				var task = Frames.Application.task;
				if (task && task.view && Frames.Application.isWorkspaceView(task.view.id))
				{
					if (_$(document.body).find('.login-message').length > 0)
					{
						_$(document.body).find('.login-message').remove();
					}
				}
				return;
			}

			_$('#notifications').notificationsmenu('close', close);
		},

		arianotify: function(msg, role, priority, type)
		{
			if (Frames.isEmpty(msg))
			{
				return;
			}

			if (msg.substr(msg.length - 1, 1) != '.')
			{
				msg += '.';
			}

			if (!Frames.isEmpty(type))
			{
				msg = type + ': ' + msg;
			}

			if (role == 'alert')
			{
				if (Frames.Workspace.arianotifyAlertQueue > 0)
				{
					var previousMsg = _$('#workspace-screenreader-alert').text();
					if (Frames.isTrue(priority))
					{
						msg = msg + '\n' + previousMsg;
					}
					else
					{
						msg = previousMsg + '\n' + msg;
					}
				}

				_$('#workspace-screenreader-alert').remove();

				var alert = document.createElement('div');
				alert.setAttribute('role', 'alert');
				alert.setAttribute('aria-live', 'assertive');
				alert.setAttribute('id', 'workspace-screenreader-alert');
				alert.appendChild(document.createTextNode(msg));
				document.body.appendChild(alert);

				Frames.Workspace.arianotifyAlertQueue++;
				setTimeout(function()
				{
					Frames.Workspace.arianotifyAlertQueue--;
				}, 500);
			}
			else
			{
				var $el = _$('#workspace-screenreader-status');
				if ($el.length === 0)
				{
					$el = _$('<span id="workspace-screenreader-status" aria-live="polite"></span>');
					_$(document.body).append($el);
				}

				if (Frames.Workspace.arianotifyMessageQueue > 0)
				{
					var previousMsg = $el.text();
					if (Frames.isTrue(priority))
					{
						msg = msg + '\n' + previousMsg;
					}
					else
					{
						msg = previousMsg + '\n' + msg;
					}
				}

				//XSS prevention
				$el.html('<p></p>');
				$el.find('p').text(msg);

				Frames.Workspace.arianotifyMessageQueue++;
				setTimeout(function()
				{
					Frames.Workspace.arianotifyMessageQueue--;
				}, 500);
			}
		},

		print: function(it)
		{
			window.print();
		},

		scale: function(it)
		{
			var that = this;
			var appsroot = Frames.Config.get('APPS_ROOT', '.');
			var templatePath = appsroot + '/base/views/morphis/frames/workspace/ScalingDialog.html#scale-template';
			Frames.Template.get(templatePath, function(template) {
				var html = template({});
				var $el = _$(html).dialog({
					appendTo: Frames.Dialog.container(),
					modal: true,
					resizable: false,
					autoOpen: true,
					autoResize: true,
					width: 'auto',
					closeOnEscape: true
				});

				//if no cookie saved, default will be 100%
				that.scaling = _$.sanitize(Cookies.get('scaling')) || '100';
				//just save selected option
				_$('select', $el).val(that.scaling).change(function(e) {
					var select = e.target;
					var option = select.options[select.selectedIndex];
					that.selectedOpt = option.value;
				});

				//just apply new scale after button click
				_$('button', $el).on('click', function()
				{
					_$('.workspace-container').removeClass('ui-scale-'+ that.scaling + '');
					that.scaling = that.selectedOpt;
					_$('.workspace-container').addClass('ui-scale-'+ that.scaling + '');
					Cookies.set('scaling', that.scaling);
					$el.dialog('close');
				});
			});
		},

		printScreenShot: function()
		{
			_$.blockUI({ overlayCSS: {backgroundColor: '#666', opacity: .8}, css: _$.extend({}, Frames.Loader.BOX, { color: '#fff', fontSize: '2rem'}), message: Frames.Locale.messages.PRINTING});
			_$('html').addClass('ui-screenshot');

			if (_$.browsercss()[0] == "firefox" || _$.browsercss()[0] == "chrome")
			{
				this._printRasterizehtml();
			}
			else
			{
				this._printHtml2canvas();
			}
		},

		_printRasterizehtml: function()
		{
			var width = _$(document).width();
			var height = _$(document).height();
			var canvas = _$('<canvas id="canvas" ></canvas>');

			//create iframe to clone the content
			var frm1 = document.createElement("iframe");
			_$(frm1).css('width', width);
			_$(frm1).css('height', height);
			document.body.appendChild(frm1);

			//content to clone
			//clone to head
			_$('head link').clone(false).appendTo(_$(frm1).contents().find('head'));
			_$('head style').clone(false).appendTo(_$(frm1).contents().find('head'));
			//clone to body
			_$('.workspace-header').clone(false).appendTo(_$(frm1).contents().find('body'));
			_$('.workspace-container').clone(false).appendTo(_$(frm1).contents().find('body'));
			_$('.workspace-footer').clone(false).appendTo(_$(frm1).contents().find('body'));

			_$(frm1).contents().find('.workspace-container, .workspace-footer').addClass('ui-screenshot-rasterize');

			var dir = Frames.Locale.formats.IS_RTL ? 'rtl' : 'ltr';
			_$(frm1).contents().find('html').attr('dir', dir);

			//If print is executed by selecting menu screenshot action
			_$(frm1).contents().find('.workspace-container .blockUI.blockOverlay').css('display', 'none');
			_$(frm1).contents().find('#related-tools > .icon').removeClass('menu-active');

			_$(frm1).contents().find('.ui-header-fixed').css('width', '100%');
			_$(frm1).contents().find('.ui-header-fixed, .ui-pager-fixed').css('width', '100%');

			rasterizeHTML.drawDocument(frm1.contentWindow.document, canvas[0], {width: width, height: height, cache: false}).then(function(result) {
				var image = result.image;
				var strHtml = '<html><head></head><body style="padding: 0; margin: 0;">' +
				'<img src="' + image.src + '" style="display: block; width: 100%" />' +
				'</body></html>';

				var frm = document.createElement("iframe");
				frm.style.width = '0';
				frm.style.height = '0';
				document.body.appendChild(frm);
				var w = frm.contentWindow;
				w.document.write(strHtml);
				w.document.close();

				// For IE browser we still need to focus(), but it's unnecessary on other browsers
				var isIE = _$.browsercss()[0] == 'ie';
				if (isIE)
				{
					w.focus();
				}

				_$.unblockUI();
				w.print();
				_$('html').removeClass('ui-screenshot');
				_$(frm).remove();
				_$(frm1).remove();
			});
		},

		_printHtml2canvas: function(it)
		{
			var that = this;
			_$.blockUI({ overlayCSS: {backgroundColor: '#666', opacity: .8}, css: _$.extend({}, Frames.Loader.BOX, { color: '#fff', fontSize: '2rem'}), message: Frames.Locale.messages.PRINTING});
			var wheader = document.querySelector('.workspace-header');
			var wview = _$('.workspace-container').get(0);
			var wfooter = document.querySelector('.workspace-footer');

			_$('html').addClass('ui-screenshot');
			html2canvas(wheader).then(function(cv1) {
				if (!cv1 || !Frames.isFunction(cv1.toDataURL)) 
				{
					return;
				}
				var im1 = cv1.toDataURL('image/png');

				_$(wview).addClass('ui-screenshot-align');
				html2canvas(wview).then(function(cv2) {
					if (!cv2 || !Frames.isFunction(cv2.toDataURL))
					{
						return;
					}
					var im2 = cv2.toDataURL('image/png');
					_$(wview).removeClass('ui-screenshot-align');

					html2canvas(wfooter).then(function(cv3) {
						if (!cv3 || !Frames.isFunction(cv3.toDataURL))
						{
							return;
						}
						var im3 = cv3.toDataURL('image/png');

						that._printImages(im1, im2, im3);
					});
				});

				_$('html').removeClass('ui-screenshot');
			});
		},

		_printImages: function(i1, i2, i3)
		{
			var isIE = _$.browsercss()[0] == 'ie';
			var strHtml = '<html><head></head><body style="padding: 0; margin: 0">' +
					'<img src="' + i1 + '" style="width: 100%; display: block" />' +
					'<img src="' + i2 + '" style="width: 100%; display: block" />' +
					'<img src="' + i3 + '" style="width: 100%; display: block" />' +
					'</body></html>';
			var frm = document.createElement("iframe");
			frm.style.width = '0';
			frm.style.height = '0';
			document.body.appendChild(frm);
			var w = frm.contentWindow;
			w.document.write(strHtml);
			w.document.close();

			// For IE browser we still need to focus(), but it's unnecessary on other browsers
			if (isIE)
			{
				w.focus();
			}

			setTimeout(function() {
				_$.unblockUI();
				w.print();
				document.body.removeChild(frm);
			}, 0);
		},

		_handleMenuClick: function(it)
		{
			if (it.action !== undefined)
			{
				var action = it.action;
				var enabled = it.enabled === undefined ? true : Frames.isTrue(it.enabled);

				if (it.option)
				{
					var item = it.item;
					var name = it.name;
					var id = it.id;

					if (!enabled)
					{
						return;
					}

					Frames.Workspace.callmenu(undefined, action, id, name);
				}
				else
				{
					if (enabled)
					{
						if (action == 'ITEM_PROPERTIES')
						{
							Frames.Debug.properties();
						}
						else if (action == 'PRINT')
						{
							// make sure the menu doesn't show on preview
							_$('.workspace-menu').verticalmenu('close');
							Frames.Workspace.print();
						}
						else if (action == 'SCREENSHOT')
						{
							// make sure the menu doesn't show on preview
							_$('.workspace-menu').verticalmenu('close');
							Frames.Workspace.printScreenShot();
						}
						else if (action == 'SCALE')
						{
							// make sure the menu doesn't show on preview
							_$('.workspace-menu').verticalmenu('close');
							Frames.Workspace.printScale();
						}
						else
						{
							var context = it.context === 'main' ? Frames.Application.getMainTask() : Frames.Application.getCurrentTask();
							Frames.Application.valexec(action, undefined, undefined, context);
						}
					}
				}
			}

			else
			{
				var page = it.page;
				if (!Frames.isUndef(page) && it.enabled)
				{
					var p = Frames.ToolBar.paging();
					switch (page)
					{
						case 'first':
							p.first();
							break;
						case 'prev':
							p.previous();
							break;
						case 'next':
							p.next();
							break;
						case 'last':
							p.last();
							break;
					}
				}
			}

			if (it.action !== undefined  || it.page)
			{
				_$('.workspace-menu').verticalmenu('close');
			}
		},

		callmenu: function(task, action, item, name)
		{
			Frames.Application.callmenu(task, action, item, name);
		},

		callform: function(item, menu, kind, block, member)
		{
			Frames.Application.callform(item, menu, kind, block, member);
		},

		callformByName: function(name, parameters)
		{
			var model = Frames.Model.create('model');
			var callform = Frames.Model.create('callForm');
			Frames.Model.attr(callform, 'taskName', name);

			Frames.Model.append(model, callform);

			if (Frames.isArray(parameters) && parameters.length > 0)
			{
				var params = Frames.Model.create('parameters');
				_$.each(parameters, function(k, o)
				{
					var param = Frames.Model.create('parameter');
					Frames.Model.attr(param, 'name', o.name);
					Frames.Model.attr(param, 'value', o.value);
					if (o.datatype)
					{
						Frames.Model.attr(param, 'datatype', o.datatype);
					}

					Frames.Model.append(params, param);
				});

				Frames.Model.append(callform, params);
			}

			Frames.Application.execute('CALL_FORM', Frames.Application.mainTask, model);
		},

		blockUI: function(blockTarget, options)
		{
			var fn = function()
			{
				blockTarget.block(options);
			}

			if (_$(document.body).css('opacity') == 0)
			{
				Frames.Application.one('cssloaded', function()
				{
					fn();
				});
			}
			else
			{
				fn();
			}
		}
	});

};

//# sourceURL=app/base/js/workspace.js
