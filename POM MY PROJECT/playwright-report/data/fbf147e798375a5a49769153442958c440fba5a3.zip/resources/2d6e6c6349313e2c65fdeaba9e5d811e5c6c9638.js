
var ComponentDescription =
{
	isExtendable: function(item)
	{
		if (Frames.inDesignMode || Frames.isUndef(item.elem))
		{
			return false;
		}

		var wname = item.widgetcls();
		var valid = (wname == 'textfield' || wname == 'textinput' || wname == 'radiogroup');

		if (valid)
		{
			var $parent = item.elem.parent();
			var incomponent = $parent.hasClass('ui-component');

			var nolabel = item.elem.hasClass('ui-nolabel') || item.elem.hasClass('ui-hidelabel');
			var notfirst = $parent.find('[data-widget]').index(item.elem) !== 0;

			var isdescription = notfirst && nolabel;
			var isradiogroup = wname == 'radiogroup';

			return incomponent && (isdescription || isradiogroup);
		}

		return false;
	},

	register: function(item)
	{
		if (ComponentDescription.isExtendable(item))
		{
			item._resizefn_id = Frames.uuid();
			item._resizefn = _$.proxy(ComponentDescription._resize, item.elem);
			$(window).on('resize.' + item._resizefn_id, {item: item}, item._resizefn);
			item.elem.on('resize.' + item._resizefn_id, {item: item}, item._resizefn);
			Frames.Application.on('viewready.' + item._resizefn_id, {item: item}, item._resizefn);

			var wname = item.widgetcls();
			if (wname != 'radiogroup' & !item.elem.hasClass('ui-nodescription'))
			{
				item.elem.addClass('ui-description');

				var $inp = item.input();
				if ($inp && $inp.is('span'))
				{
					$inp.css('width', '');
				}
			}
		}
	},

	_recalculate: function(item)
	{
		if (item.elem)
		{
			item.elem.removeClass('ui-line-labeloverflow');
			item.elem.removeClass('ui-line-overflow');

			var pos = item.elem.position();
			if (pos.top !== 0)
			{
				item.elem.addClass('ui-line-overflow');
			}

			var $lbl = item.elem.parent().children('label');
			var lineH = parseInt($lbl.css('line-height'), 10);
			if ($lbl.height() > lineH)
			{
				item.elem.addClass('ui-line-labeloverflow');
			}
		}
	},

	_resize: function(e)
	{
		if (e.data && e.data.item)
		{
			ComponentDescription._recalculate(e.data.item);
		}
	},

	unregister: function(item)
	{
		if (ComponentDescription.isExtendable(item))
		{
			$(window).off('resize.' + item._resizefn_id, item._resizefn);
			item.elem.off('resize.' + item._resizefn_id, item._resizefn);
			Frames.Application.off('viewready.' + item._resizefn_id, item._resizefn);
			delete item._resizefn;
			delete item._resizefn_id;
		}
	}
};

Frames.regplug("component.description", ComponentDescription, Frames.PLUGIN_WIDGET);

var AccessibilityDescription =
{
	register: function(item)
	{
		if (!Frames.isUndef(item.elem))
		{
			var $srcEl = item.elem;
			var $targetEl = item.input();

			// if item has no input, add accessibility attributes to elem
			if (Frames.isUndef($targetEl))
			{
				$targetEl = $srcEl;
			}

			var key;
			for (key in $srcEl.data())
			{
				if (key.indexOf('addAria') === 0)
				{
					var attrName = key.replace('addAria', 'aria-').toLowerCase();
					$targetEl.attr(attrName, $srcEl.data(key));
				}
			}

			/* var ariaDescribedBy = item.elem.attr('data-add-aria-describedby');
			if (!Frames.isEmpty(ariaDescribedBy))
			{
				item.elem.attr('aria-describedby', ariaDescribedBy);
			}*/
		}
	},

	unregister: function(item)
	{
		if (!Frames.isUndef(item.elem))
		{
			var $srcEl = item.elem;
			var $targetEl = item.input();

			if (Frames.isUndef($targetEl))
			{
				$targetEl = $srcEl;
			}
			var key;
			for (key in $srcEl.data())
			{
				if (key.indexOf('addAria') === 0)
				{
					var attrName = key.replace('addAria', 'aria-').toLowerCase();
					$targetEl.removeAttr(attrName);
				}
			}
		}
	}
};

Frames.regplug("accessibility.description", AccessibilityDescription, Frames.PLUGIN_WIDGET);

var createDescriptionContext = function()
{
	var id = this.element.attr('id');

	// ES-1666 - Descriptions have a generated ID starting with "id-description"
	if (!Frames.isEmpty(id) && id.indexOf('id-description') == 0)
	{
		// input described by the description has "aria-describedby" attribute
		var relatedInp = $('input[aria-describedby="' + id + '"]');
		if (relatedInp.length == 1 && !Frames.isUndef(relatedInp.data('frames')))
		{
			this._relatedInp = relatedInp;

			// FRAMES-1952 - Make elements described by a textinput refer directly to the input
			// ES-2257 - Limit this fix to not affect elements in responsive keyblock
			if (this.element.data('widget') == 'textinput' && this.element.parents('.ui-layout-responsive').length == 0)
			{
				var inpId = this.input().attr('id');
				relatedInp.attr('aria-describedby', inpId);
			}

			else if (this.element.data('widget') == 'textfield')
			{
				this.input().removeAttr('aria-labelledby');
			}
		}
	}
}

var _createTextinput = _$.ui.textinput.prototype._create;
_$.ui.textinput.prototype._create = function()
{
	_createTextinput.apply(this, arguments);
	createDescriptionContext.apply(this);
};

var _createTextfield = _$.ui.textfield.prototype._create;
_$.ui.textfield.prototype._create = function()
{
	_createTextfield.apply(this, arguments);
	createDescriptionContext.apply(this);
};

var __prepareTemplateRow = _$.ui.repeater.prototype._prepareTemplateRow;
_$.ui.repeater.prototype._prepareTemplateRow = function(el)
{
	__prepareTemplateRow.apply(this, arguments);
	var ariaDescribedBy = el.data('addAriaDescribedby');
	if (!Frames.isEmpty(ariaDescribedBy))
	{
		el.data('addAriaDescribedby', ariaDescribedBy + '_' + this._rowsnum);
	}
};

//# sourceURL=app/flat/widgets/component/js/description.js
