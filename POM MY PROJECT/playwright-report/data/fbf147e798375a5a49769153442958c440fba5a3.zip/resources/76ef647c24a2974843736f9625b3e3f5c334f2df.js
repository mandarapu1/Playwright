
Frames.Modes.Search = _$.inherit(
	Frames.Modes.Read,
{
	// overrude any method if needed
});

Frames.Block.prototype.__preModelControlInfo = Frames.Block.prototype._preModelControlInfo;
Frames.Block.prototype._preModelControlInfo = function(control, data)
{
	if (this.props('blockMode') != 'SEARCH' && this.isFilterEnabled() && Frames.Model.attr(control, 'blockMode') == 'SEARCH')
	{
		var filterpanel = this.getFilterPanel().data('ui-filterpanel');
		if (!Frames.isUndef(filterpanel))
		{
			filterpanel._filterAgainMode = true;
		}
	}

	Frames.Block.prototype.__preModelControlInfo.apply(this, arguments);
};

Frames.Block.prototype._model = Frames.Block.prototype.model;
Frames.Block.prototype.model = function(item, key)
{
	var data;
	var searchMode = this.props('blockMode') === 'SEARCH';
	var filterVersion = !Frames.isUndef(this._exts.FilterVersion) ? this._exts.FilterVersion : Frames.Config.get('FILTER_VERSION', '1');
	var version2 = searchMode && filterVersion === '2';

	// getter
	if (arguments.length === 0)
	{
		if (version2 || this._forceFilters)
		{
			if (this._addDummyRow)
			{
				this._selid = this._prevDummySelId;
				delete this._addDummyRow;
			}

			var model = Frames.Model.createBlock(this.name);
			Frames.Model.attr(model, 'selected', this._selid);
			var record = Frames.Model.createRecord(this._selid);
			Frames.Model.attr(record, 'status', 'C');

			Frames.Model.append(model, record);

			if (this._ITEMS_)
			{
				this._ITEMS_.reset();
				while (this._ITEMS_.hasNext())
				{
					var it = this._ITEMS_.next();
					var isSearchable = Frames.isTrue(it.props('AllowSearch'), true);
					var isVisible = (Frames.isTrue(it.props('Visible'), true) && it.visible()) || !Frames.isEmpty(it._exts);

					// var isInput checks if the current item is a button. If so, don't send him on the server request.
					var isInput = it.props('widget') != 'button' ? true : false;

					if (isSearchable && isVisible && isInput)
					{
						var member = it.member;
						var item = this._FILTER_.get(member);
						data = item ? item.model() : Frames.Model.createItem(member, '');
						if (data)
						{
							Frames.Model.append(record, data, 'item');
						}
					}
				}
			}

			var that = this;
			var block = this.item.block;
			if (Frames.isUndef(block))
			{
				this.item.block = block = this;
			}
			var extItems = block.getextitem();
			$.each(extItems, function(i, extMember)
			{
				if (Frames.isUndef(that._ITEMS_.get(extMember)))
				{
					var extItem = that._FILTER_.get(extMember);
					data = extItem ? extItem.model() : Frames.Model.createItem(extMember, '');
					if (data)
					{
						Frames.Model.append(record, data, 'item');
					}
				}
			});

			if (this._forceFilters)
			{
				this.restoreModelState();
			}

			return model;
		}
		else
		{
			return Frames.Block.prototype._model.apply(this);
		}
	}

	// setter
	else
	{
		if (version2 && !this._clear)
		{
			data = arguments[0];
			$(this).trigger('prebind', data);
			this.dirty(false);

			if (data)
			{
				var blkData = Frames.find(data, 'block', this.name);
				if (blkData)
				{
					var updateSelid = true;
					data = blkData[0];
					if (Frames.isUndef(this._lastmode) || this._lastmode == 'SEARCH')
					{
						if (!Frames.isUndef(this.$content))
						{
							var datagrid = this.$content.find('.ui-datagrid');
							var isDatagrid = datagrid.length > 0;
							if (Frames.isTrue(isDatagrid))
							{
								var datagridItem = datagrid.data('frames');

								delete this._addDummyRow;
								if (Frames.isUndef(this.paging))
								{
									updateSelid = false;
									this._addDummyRow = true;
									this.forceModelState(true);
									
									//add pagination
									var pagerCtrl = $.xmlToJSON('<page enabled="false" pageNumber="1" pageSize="1" totalPages="1" totalRecords="1" />');
									var page = [pagerCtrl];
									this.paging = new Frames.Paging(this);
									this.paging.controlInfo(page[0]);
	
									datagridItem._pagEl = $('<div class="ui-grid-pager" style="width:100%;"></div>');
									datagridItem._pagEl.insertAfter(datagrid);
									datagridItem._pager = new Frames.DataGrid.Pager(this.paging, datagridItem._pagEl);
									datagridItem._pager.init();
	
									//add dummy record
									var record = Frames.Model.findSingle(data, 'record');
									if (!Frames.isUndef(record))
									{
										this._prevDummySelId = Frames.Model.attr(record, 'id');
										Frames.Model.attr(record, 'id', this._selid);
										Frames.Model.attr(record, 'selected', this._selid);
									}
								}
							}
						}
					}
					if (updateSelid)
					{
						var selected = Frames.Model.attr(data, 'selected');
						if (!Frames.isUndef(selected))
						{
							this._selid = selected;
						}
						$(this).trigger('startbind', data);
						$(this).trigger('endbind', data);
					}

				}
			}
			$(this).trigger('postbind', data);

			if (this._addDummyRow)
			{
				Frames.Block.prototype._model.apply(this, arguments);
			}
		}
		else
		{
			Frames.Block.prototype._model.apply(this, arguments);
		}
	}
};

Frames.DataGrid.prototype._colenabled = Frames.DataGrid.prototype.colenabled;
Frames.DataGrid.prototype.colenabled = function()
{
	var searchMode = this.block.props('blockMode') === 'SEARCH';
	// getter
	if (arguments.length === 1)
	{
		return Frames.DataGrid.prototype._colenabled.apply(this);
	}

	// setter
	else
	{
		if (!searchMode)
		{
			Frames.DataGrid.prototype._colenabled.apply(this, arguments);
		}
	}
};


Frames.DataGrid.prototype._clearSort = Frames.DataGrid.prototype.clearSort;
Frames.DataGrid.prototype.clearSort = function()
{
	var searchMode = this.block.props('blockMode') === 'SEARCH';
	// getter
	if (arguments.length === 1)
	{
		return Frames.DataGrid.prototype._clearSort.apply(this);
	}

	// setter
	else
	{
		if (!searchMode)
		{
			Frames.DataGrid.prototype._clearSort.apply(this, arguments);
		}
	}
};


Frames.Block.prototype.restoreModelState = function()
{
	if (this._random && this._selid == this._random.id)
	{
		this._selid = this._random.last;
		delete this._random;
	}

	delete this._forceFilters;
};

Frames.Block.prototype.forceModelState = function(random)
{
	this._forceFilters = true;

	if (random)
	{
		this._random = {
			id: 'MORPHIS.FRAMES.' + new Date().getTime() + '-filter',
			last: this._selid
		};
		this._selid = this._random.id;
	}
};

if (_$.ui)
{
	if (_$.ui.combobox)
	{
		var _value = _$.ui.combobox.prototype.value;
		_$.ui.combobox.prototype.value = function()
		{
			// getter: use original method
			if (arguments.length === 0)
			{
				return _value.apply(this, arguments);
			}
			else
			{
				var fitem = this._inp.data('frames');
				var curr = Frames.Application.current();
				var block = (fitem && fitem.block) ? fitem.block : (curr ? curr.block : undefined);

				if (!Frames.isUndef(block) && block.props('blockMode') == 'SEARCH')
				{
					var filter = $(this.element).closest('.filterForm').data('ui-filterpanel');
					if (!Frames.isUndef(filter) && !Frames.isTrue(filter.forceComboValueOriginal))
					{
						var v = arguments[0];
						this.clearselection();
						this._inp.val(v);
						return;
					}
				}

				_value.apply(this, arguments);
			}
		};
	}

	if (_$.ui.buttoninput)
	{
		var _execclick = _$.ui.buttoninput.prototype.execclick;
		_$.ui.buttoninput.prototype.execclick = function()
		{
			var fitem = this._inp.data('frames');
			var curr = Frames.Application.current();
			var block = (fitem && fitem.block) ? fitem.block : (curr ? curr.block : undefined);
			if (!Frames.isUndef(block) && block.props('blockMode') == 'SEARCH')
			{
				var widget = fitem.data('widget');
				if (widget == 'combobox')
				{
					this._inp.trigger('action');
					return;
				}
			}

			_execclick.apply(this, arguments);
		};
	}
}

var validationFormat = Frames.Validation.validateFormat;

Frames.Validation.validateFormat = function(curr, action)
{
	if (curr.elem)
	{
		var $el = curr.elem.closest('.filterForm');
		if ($el.length > 0)
		{
			var filter = $el.data('ui-filterpanel');
			if (!Frames.isUndef(filter) && $el.is(':visible'))
			{
				if (filter._isBasicMode())
				{
					if (action && action.accesskey == 'F9')
					{
						Frames.Application._actexecute(action);
					}
					return false;
				}
			}
		}
	}

	return validationFormat.apply(this, arguments);
};

Frames.Modes.regtype('SEARCH', Frames.Modes.Search);

//# sourceURL=app/flat/widgets/filterpanel/js/modes/search.js