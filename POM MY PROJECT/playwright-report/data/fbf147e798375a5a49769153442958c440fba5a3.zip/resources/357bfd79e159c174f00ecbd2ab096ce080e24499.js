{
	_resetHeader = function(e)
	{
		this._unfixHeaderFn.apply(this, arguments);
		this._fixedHeaderFn.apply(this, arguments);
	};

	_resetPager = function(e)
	{
		this._unfixPagerFn.apply(this, arguments);
		this._fixedPagerFn.apply(this, arguments);
	};

	_moveGridDialogHeader = function(e, diff)
	{
		var $gridContainer = Frames.Application.getContainer(this.elem);
		if ($gridContainer.hasClass('ui-drag-selected-dialog'))
		{
			var fixedHeader = this.elem.find('.ui-header-fixed');
			if (fixedHeader.length > 0)
			{
				var headertop = parseInt(fixedHeader.css('top').replace('px', ''));
				fixedHeader.css('top', headertop - diff.top);
			}
		}
	};

	_moveGridDialogPager = function(e, diff)
	{
		var $gridContainer = Frames.Application.getContainer(this.elem);
		if ($gridContainer.hasClass('ui-drag-selected-dialog'))
		{
			var fixedPager = this.elem.siblings('.ui-pager-fixed');
			if (fixedPager.length > 0)
			{
				var headertop = parseInt(fixedPager.css('top').replace('px', ''));
				fixedPager.css('top', headertop - diff.top);
			}
		}
	};
	
	_onWindowResize = function()
	{
		var self = this;
		var container = this.elem.parents('.ui-dialog'); 

		if (container.length == 0)
		{
			return;
		}

		Frames.later(function() {
			self._unfixHeaderFn.apply(self, arguments);
			self._fixedHeaderFn.apply(self, arguments);
			self._unfixPagerFn.apply(self, arguments);
			self._fixedPagerFn.apply(self, arguments);
			if (self.elem.find('.ui-header-fixed').length > 0 )
			{
				var options = self._grid.getOptions();
				options.preventHeaderResize = true;
			}
		}, 0);
	}

	var constructor = Frames.DataGrid.prototype.__constructor;

	Frames.DataGrid.prototype.__constructor = function(elem)
	{
		constructor.apply(this, arguments);
		var self = this;
		this.instanceId = Frames.uuid();
		if (this.elem.hasClass('ui-datagrid-fixedlabels'))
		{
			var $gridContainer = Frames.Application.getContainer(this.elem);
			if (!Frames.isUndef($gridContainer))
			{

				this.resetHeader = _$.proxy(_resetHeader, this);
				Frames.Application.on('themeswitch.' + this.instanceId + ' filtertoggle.' + this.instanceId, this.resetHeader);

				if ($gridContainer.hasClass('ui-dialog-content'))
				{
					this.moveGridDialogHeader = _$.proxy(_moveGridDialogHeader, this);
					Frames.Application.on('dialogdragdiff.' + this.instanceId, this.moveGridDialogHeader)
				}
			}
		}

		if (this.elem.hasClass('ui-datagrid-fixedpager'))
		{
			var $gridContainer = Frames.Application.getContainer(this.elem);
			if (!Frames.isUndef($gridContainer))
			{
				this.resetPager = _$.proxy(_resetPager, this);
				Frames.Application.on('themeswitch.' + this.instanceId + ' filtertoggle.' + this.instanceId, this.resetPager);

				if ($gridContainer.hasClass('ui-dialog-content'))
				{
					this.moveGridDialogPager = _$.proxy(_moveGridDialogPager, this);
					Frames.Application.on('dialogdragdiff.' + this.instanceId, this.moveGridDialogPager);
				}
			}
		}

		this.onWindowResize = _$.proxy(_onWindowResize, this);
		$(window).on('resize.' + this.instanceId, this.onWindowResize);

		Frames.Application.on('dialogreszied.' + this.instanceId, this.onWindowResize);
	}

	var focusColumn =  Frames.DataGrid.ColumnItemContext.prototype.focus;

	Frames.DataGrid.ColumnItemContext.prototype.focus = function()
	{
		var calendarIsOpen = Frames.MultiDateField && Frames.isFunction(Frames.MultiDateField.isModalOpen) && Frames.MultiDateField.isModalOpen();
		if (Frames.Calculator.isModalOpen() || calendarIsOpen)
		{
			// Don't focus the editor.We want the focus in the modal widget
			return;
		} else
		{
			focusColumn.apply(this, arguments);
		}
	};

	var destroyGrid =  Frames.DataGrid.prototype.destroy;

	Frames.DataGrid.prototype.destroy = function()
	{
		Frames.Application.off('themeswitch.' + this.instanceId + ' filtertoggle.' + this.instanceId, this.resetHeader);
		Frames.Application.off('themeswitch.' + this.instanceId + ' filtertoggle.' + this.instanceId, this.resetPager);
		Frames.Application.off('dialogdragdiff.' + this.instanceId, this.resetDialogPosition);
		Frames.Application.off('dialogdragdiff.' + this.instanceId, this.resetDialogPosition);
		$(window).off('resize.' + this.instanceId, this.onWindowResize);
		Frames.Application.off('dialogreszied.' + this.instanceId, this.onWindowResize);

		destroyGrid.apply(this, arguments);
	};

};

//# sourceURL=app/flat/widgets/workspace/js/datagrid.js
