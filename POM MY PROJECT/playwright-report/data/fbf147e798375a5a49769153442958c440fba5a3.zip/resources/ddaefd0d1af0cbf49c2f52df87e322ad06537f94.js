(function($)
{
	$.widget('ui.richtext', $.ui.textarea,
	{
		version: '@VERSION',

        options: {
			config: {
				language: Frames.Locale.lang,
				width: '100%',
				fullPage: true,
				allowedContent: true,
				extraPlugins: 'autogrow',
				autoGrow_onStartup: true,
				removePlugins: 'resize',
				toolbarGroups : [
            		{ name: 'styles', groups: [ 'styles' ] },
            		{ name: 'clipboard', groups: [ 'clipboard', 'undo' ] },
            		{ name: 'editing', groups: [ 'find', 'selection', 'spellchecker', 'editing' ] },
            		{ name: 'forms', groups: [ 'forms' ] },
            		{ name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ] },
            		{ name: 'paragraph', groups: [ 'list', 'indent', 'blocks', 'align', 'bidi', 'paragraph' ] },
            		{ name: 'links', groups: [ 'links' ] },
            		{ name: 'insert', groups: [ 'insert' ] },
            		{ name: 'colors', groups: [ 'colors' ] },
            		{ name: 'tools', groups: [ 'tools' ] },
            		{ name: 'about', groups: [ 'about' ] },
            		{ name: 'document', groups: [ 'document', 'doctools', 'mode' ] },
            		{ name: 'others', groups: [ 'others' ] }
            	],

            	removeButtons : 'Save,NewPage,Print,Templates,Preview,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,BidiLtr,BidiRtl,Language,Anchor,Flash,Smiley,PageBreak,Iframe,About,Styles'
			}
        },

		_create: function()
		{
			var that = this;
			this.element.addClass('ui-richtext');

			// Apply theme color
			// this.options.config.uiColor = this.element.css('background-color') || '#AAAAAA';
			this.options.config.uiColor = '#CCCCCC';

			// Apply template
			var appsroot = Frames.Config.get('APPS_ROOT', '.');
			var templatePath = appsroot + '/flat/widgets/richtext/html/richtext.html#richtext-template';
			Frames.Template.get(templatePath, function(template) {
				var html = template({});
				that.element.html(html);
				$.ui.textarea.prototype._create.apply(that);

				// Apply default label
				that.label(that.element.data('label'));

				that._bindElement();
			});
		},

		_triggerEvent: function(event) {
			var inp = this.input() || this.element.find('textarea');
			if (!event || !event.type)
            {
                return;
            }
			var ev = $.Event(event.type, {
				target: inp,
				keyCode: event.keyCode,
				which: event.which,
				altKey: event.altKey,
				shiftKey: event.shiftKey,
				ctrlKey: event.ctrlKey
			});
			inp.triggerHandler(ev);
		},

		_commitChanges: function()
		{
			var inp = this.input() || this.element.find('textarea');
			this.editor.updateElement();
			if (this._last_value !== inp.val())
			{
				inp.triggerHandler('valuechange');
				this._last_value = inp.val();
			}
		},

		updatevalue: function()
		{
			this.editor.setData(this.input().val());
		},

		_bindElement: function ()
		{
			var that = this;

			this.editor = CKEDITOR.replace(this._inp[0], this.options.config);

			this._onchange = function (event) {
				that._commitChanges();
			};
			this.editor.on('change', this._onchange);


			this._onfocus = function(e) {
				that._triggerEvent({type: 'focusin'});
			};
			this.editor.on('focus', this._onfocus);

			this._onblur = function (event) {
				that._triggerEvent({type: 'focusout'});
			};
			this.editor.on('blur', this._onblur);

			this._onkeydown = function(e) {
				that._triggerEvent(e.data.$);
			};

			this._oncontentdom = function() {
    			that.editor.document.on('keydown', that._onkeydown);
			};

			this.editor.on('contentDom', this._oncontentdom);
		},

		focus: function()
		{
			this.editor.focus();
		},

		wrapper: function(obj)
		{
			// TODO: think a better way to link to the main object
			this.element.data('frames', obj);
		},

		destroy: function()
		{
			$.ui.textarea.prototype.destroy.apply(this);

			this.editor.removeListener('change', this._onchange);
			this.editor.removeListener('focus', this._onfocus);
			this.editor.removeListener('blur', this._onblur);
			this.editor.removeListener('contentDom', this._oncontentdom);
			this.editor.document.removeListener('keydown', this._onkeydown);
			this.editor.destroy();
			this.editor = null;
			this._onchange = null;
			this._onblur = null;
		}
	});

	Frames.RichText = _$.inherit(Frames.TextArea,
	{
		widgetcls: function()
		{
			return 'richtext';
		},

		model: function()
        {
            // setter
            if (arguments.length !== 0)
            {
                Frames.TextArea.prototype.model.apply(this, arguments);
                this._call('updatevalue');
                return;
            }

            // getter
            return Frames.TextArea.prototype.model.apply(this, arguments);
        },

        _ev_obj: function()
        {
        	return this.input();
        },

		template: function()
		{
			var tpl = '<div class="ui-widget ui-label-position-left ui-richtext" data-widget="richtext" id="{{=data.uuid}}" data-block="{{=data.block}}" data-member="{{=data.item}}">' +
						'<textarea style="width: 210px; height: 40px;" class="ui-widget-content ui-corner-all" name="{{=data.uuid}}"></textarea>' +
						'<label for="#{{=data.uuid}}">{{=data.label}}</label>' +
					'</div>';
			return tpl;
		},

		designprops: function(props, current)
		{
			delete props.general.properties.tooltip;
			props.general.properties.size.set = function(value, curr)
			{
				curr = Frames.isUndef(curr) ? current : curr;
				var d = curr.describe();

				if (!$.isPlainObject(value) || Frames.isUndef(d.resizable) || d.resizable === false)
				{
					return;
				}

				if (Frames.inDocumentationMode)
				{
					if (!Frames.isUndef(value.widthUnit) && Frames.isUndef(value.width))
					{
						value.width = $(event.target).prev().val();
						curr.elem.children('div').prop('style').width = parseInt(value.width, 10) + value.widthUnit;
					}

					if (Frames.isUndef(value.widthUnit) && !Frames.isUndef(value.width))
					{
						value.widthUnit = $(event.target).next().val();
						curr.elem.children('div').prop('style').width = parseInt(value.width, 10) + value.widthUnit;
					}

					if (!Frames.isUndef(value.heightUnit) && Frames.isUndef(value.height))
					{
						value.height = $(event.target).prev().val();
						curr.elem.find('.cke_contents').prop('style').height = parseInt(value.height, 10) + value.heightUnit;
					}

					if (Frames.isUndef(value.heightUnit) && !Frames.isUndef(value.height))
					{
						value.heightUnit = $(event.target).next().val();
						curr.elem.find('.cke_contents').prop('style').height = parseInt(value.height, 10) + value.heightUnit;
					}
				}
			}
			return props;
		},

		xvcName: function()
		{
			return 'richtext';
		},

		type: function()
		{
			return 'Other';
		},

		buildXvcPropsMap: function() {
			var propsMap = Frames.TextArea.prototype.buildXvcPropsMap.apply(this, arguments);
			delete propsMap.backgroundcolor;
			delete propsMap.fontfamily;
			delete propsMap.fontcolor;
			delete propsMap.fontsize;
			delete propsMap.datatype;
			delete propsMap.required;
			delete propsMap.labeldirection;
			delete propsMap.case;
			delete propsMap.formatmask;
			delete propsMap.accesskey;
			delete propsMap.label;
			delete propsMap.labelcolor;
			delete propsMap.labelfontsize;
			delete propsMap.labelfontfamily;
			delete propsMap.labelwidth;
			delete propsMap.labelstyle;
			delete propsMap.labeloffset;
			delete propsMap.labelposition;
			delete propsMap.labelalign;
			delete propsMap.maxvalue;
			delete propsMap.minvalue;
			delete propsMap.autoskip;
			return propsMap;
		},

		//Prevent to add widget on designer menu
		addOnMenu: function()
		{
			return [];
		}
	});

	Frames.regtype('richtext', Frames.RichText);
})(jQuery);

//# sourceURL=app/flat/widgets/richtext/js/richtext.js
