{

	_$.widget('workspace.themeswitcher',
	{
		// default options
		options: {
			themes: {}
		},

		// the constructor
		_create: function()
		{
			var that = this;
			var tools = Frames.Workspace.DEFAULT_TOOLS;
			var switcher = tools.find(function(element) {
				return element.id === 'theme';
			});

			if (Frames.isUndef(switcher))
			{
				return;
			}

			if (_$.workspace.themeswitcher._cfg === undefined)
			{
				_$.workspace.themeswitcher.init(function(options)
				{
					that.options = _$.extend(true, {}, that.options, options);
					that._refresh();
				});
			}
			else
			{
				this._refresh();
			}
		},

		// events bound via _on are removed automatically
		// revert other modifications here
		_destroy: function()
		{
			// TODO:
			// - destroy what's needed
		},

		_refresh: function()
		{
			var that = this;
			var $link;
			var refreshTheme = false;
			var cookie = _$.sanitize(Cookies.get('themeswitcher:theme'));

			var tools = Frames.Workspace.DEFAULT_TOOLS;
			var switcher = tools.find(function(element) {
				return element.id === 'theme';
			});

			switcher.items.splice(1);

			for (var k in this.options.themes)
			{
				var theme = this.options.themes[k];
				var id = 'th-' + theme.label.toLowerCase();
				var active = cookie ? cookie === k : theme.default ? true : false;

				//it can be already on dom if a new bind is recived
				_$('[data-uuid="' + id + '"]').remove();
				switcher.items.push({
					id: id,
					label: _(theme.label),
					theme: k,
					active: active
				})

				var cssurl = this._geturl(k);
				var $link;
				cssurl = Frames.addversiontourl(cssurl);
				link = _$('link[href="' + cssurl + '"]');
				if (link.length > 0)
				{
					$link = link.addClass('themeswitcher');
				}
				else if (active)
				{
					// FRAMES-3174 - cookie doesn't match current theme, we must refresh the theme to match the cookie
					refreshTheme = true;
				}
			}

			var themeswitcher = _$('.menu-themeswitcher').parent();
			var html = '';
			switcher = switcher.items.slice(1);
			switcher.forEach(function (theme)
			{
				var isActive = theme.active ? ' tb-active-option' : '';
				html+= '<li role="presentation" data-theme='+ theme.theme +'><a role="menu-item" href="javascript:;" title=' + theme.label + ' data-uuid=' + theme.id + ' class="menu-label ui-theme ui-tb-option-selectable ' + isActive + ' ">' + theme.label + '</a></li>';
			});
			_$(html).insertAfter(themeswitcher);

			_$('li[data-theme]').on('click', function()
			{
				var oldTheme = _$.sanitize(Cookies.get('themeswitcher:theme'));
				var oldThemeMenuOpt = _$('#menu-tools').find('a.tb-active-option.ui-theme');
				var newThemeMenuOpt = _$(this).children();

				var theme = _$(this).data('theme');
				var cssurl = that._geturl(theme);
				var $link = _$('link.themeswitcher');
				var $newlink = _$('<link rel="stylesheet" type="text/css" class="themeswitcher" />');
				$newlink.on('load', function()
				{
					// new theme is loaded, remove old theme
					$link.remove();
					Frames.Application.trigger('themeswitch');
				});
				$newlink.on('error', function()
				{
					// theme didn't load correctly, reverse operation
					$link.addClass('themeswitcher');
					$newlink.remove();

					oldThemeMenuOpt.removeClass('tb-active-option');
					newThemeMenuOpt.addClass('tb-active-option');

					Cookies.set('themeswitcher:theme', oldTheme);
				});
				$newlink.insertAfter($link);
				$newlink.attr('href', cssurl);
				$link.removeClass('themeswitcher');
				
				oldThemeMenuOpt.removeClass('tb-active-option');
				newThemeMenuOpt.addClass('tb-active-option');

				Cookies.set('themeswitcher:theme', theme);
				_$('.workspace-menu').verticalmenu('close');
			});

			if ($link === undefined || $link.length === 0)
			{
				$link = $('link:last');
			}

			if (refreshTheme)
			{
				_$('li[data-theme="' + cookie + '"]').click();
			}

		},

		_geturl: function(name)
		{
			return getThemeUrl(name);
		}

	});

	_$.workspace.themeswitcher.init = function(callback)
	{
		function init(pack)
		{
			_$.workspace.themeswitcher._cfg = pack;

			_$.workspace.themeswitcher.setup({
				themes: pack.themes
			});

			callback({
				themes: pack.themes
			});
		}

		var cfg = Frames.Config.get('APP_CONFIG');
		if (cfg === undefined)
		{
			var appname = Frames.Config.get('APP_NAME');
			if (appname)
			{
				var cfgurl = Frames._parseUrl('$appsroot/' + appname + '/package.json');
				_$.getJSON(cfgurl, function(pack)
				{
					if (pack.frames)
					{
						var _p = pack;
						pack = _p.frames;
						pack.version = _p.version;
					}
					init(pack);
				});
			}
		}
		else
		{
			init(cfg);
		}
	};

	// define themeswitcher defaults here, this allows easy client overrides by the same method
	var _tsDefaults = _$.workspace.themeswitcher.prototype.options;
	_$.workspace.themeswitcher.setup = function(options)
	{
		var opts = _$.extend(true,{}, _tsDefaults, options);
		_$.workspace.themeswitcher.prototype.options = opts;
		return opts;
	};

	var getDefaultThemeUrl = function()
	{
		var cfg = Frames.Config.get('APP_CONFIG');
		if (cfg && cfg.themes)
		{
			for (var k in cfg.themes)
			{
				var theme = cfg.themes[k];
				if (theme.default)
				{
					return getThemeUrl(k);
				}
			}
		}
		return undefined;
	};

	var getThemeUrl = function(name)
	{
		var isRTL = Frames.Locale.formats.IS_RTL;

		var appname = Frames.Config.get('APP_NAME');
		var fname = name + (isRTL ? '-rtl' : '');
		var cfg = Frames.Config.get('APP_CONFIG');
		if (cfg && cfg.themes)
		{
			var theme = cfg.themes[fname]
			if (theme && theme.path)
			{
				appname = theme.path;
			}

		}
		var cssurl = Frames._parseUrl('$appsroot/' + appname + '/css/' + fname + '.css');
		return cssurl;
	};

	var initialized = false;
	Frames._parseUrl = Frames.parseUrl;
	Frames.parseUrl = function(url, app_root)
	{
		var currTheme =  Cookies.get('themeswitcher:theme');
		if (!initialized)
		{
			var cfg = Frames.Config.get('APP_CONFIG');
			if (cfg && cfg.themes)
			{
				if (!Frames.isUndef(currTheme) && !cfg.themes.hasOwnProperty(currTheme))
				{
					for (var themeName in cfg.themes)
					{
						var theme = cfg.themes[themeName];
						if (theme.default)
						{
							currTheme = themeName
							Cookies.set('themeswitcher:theme', themeName);
							break;
						}
					}
				}
				initialized = true;
			}
		}

		if (currTheme && url && url.substring(url.length - 4) === '.css')
		{
			var themeurl;
			if (currTheme !== undefined)
			{
				themeurl = getDefaultThemeUrl();
			}

			if (themeurl)
			{
				url = Frames._parseUrl(url, app_root);
				if (url === themeurl)
				{
					return getThemeUrl(currTheme);
				}
				return url;
			}
		}
		return Frames._parseUrl(url, app_root);
	};
};

//# sourceURL=app/base/widgets/themeswitcher/js/theme-switcher.js