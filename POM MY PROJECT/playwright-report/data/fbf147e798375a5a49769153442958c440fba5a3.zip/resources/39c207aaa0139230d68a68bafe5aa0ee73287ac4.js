// the widget definition, where 'workspace' is the namespace,
// 'paneltoolbar' the widget name
_$.widget('workspace.paneltoolbar',
{
	// default options
	options: {
		toggle: true,
		bindable: {},
		template: '/flat/widgets/paneltoolbar/html/paneltoolbar.tmpl.html#paneltoolbar-template',
		toggleIcons: [
			{icon: 'ba ba-toggle-multi-inverted', tooltip: _('GO_TO_MULTI_RECORDS')},
			{icon: 'ba ba-toggle-single', tooltip: _('GO_TO_SINGLE_RECORDS')}
		],
		items: [
			{id: 'insert-bt', action: 'CREATE_RECORD', icon: 'ba ba-add', label: _('INSERT'), tooltip: _('GO_TO_INSERT')},
			{id: 'delete-bt', action: 'DELETE_RECORD', icon: 'ba ba-delete', label: _('DELETE'), tooltip: _('GO_TO_DELETE')},
			{id: 'dulpicate-bt', action: 'DUPLICATE_RECORD', icon: 'ba ba-copy', label: _('COPY'), tooltip: _('GO_TO_COPY')},
			{type: 'separator'},
			{id: 'sde-bt', action: 'SUP_DATA_ENG', style: 'ui-info', icon: 'ba ba-more-empty', label: _('ADDITIONAL_INFORMATION'), tooltip: _('GO_TO_ADDITIONAL_INFORMATION'), visible: false},
			{type: 'separator', style: 'ui-info ui-hide', visible: false},
			{id: 'filter-bt', action: 'SEARCH', icon: 'ba ba-filter', label: _('FILTER'), tooltip: _('GO_TO_FILTER')}
		],
		hasMenu: false,
		menu: {
			icon: 'fa fa-cog',
			label: _('SETTINGS'),
			tooltip: _('GO_TO_SETTINGS'),
			checkboxLabel: _('MASTER_CHECKBOX'),
			items: [
				{id: 'save-grid-bt', action: 'SAVE_GRID_SETTINGS', label: _('SAVE_GRID')},
				{id: 'save-pagination-bt', action: 'SAVE_PAGINATION_SETTINGS', label: _('SAVE_PAGINATION')},
				{id: 'save-filter-bt', action: 'SAVE_FILTER_SETTINGS', label: _('SAVE_FILTER')},
				{id: 'save-all-bt', action: 'SAVE_ALL_SETTINGS', label: _('SAVE_ALL')},
				{id: 'restore-grid-bt', action: 'RESTORE_GRID_SETTINGS', label: _('RESTORE_GRID')},
				{id: 'restore-pagination-bt', action: 'RESTORE_PAGINATION_SETTINGS', label: _('RESTORE_PAGINATION')},
				{id: 'restore-filter-bt', action: 'RESTORE_FILTER_SETTINGS', label: _('RESTORE_FILTER')},
				{id: 'restore-all-bt', action: 'RESTORE_ALL_SETTINGS', label: _('RESTORE_ALL')},
			]
		}
	},

	// the constructor
	_create: function()
	{
		var that = this;

		this._isRTL = this.element.css('direction') === 'rtl';

		this._activeView = 'multi';
		this._multiIcon =  'ba-toggle-multi';
		this._multiInvIcon = 'ba-toggle-multi-inverted';
		this._singleIcon =  'ba-toggle-single';
		this._singleInvIcon =  'ba-toggle-single-inverted';

		var appsroot = Frames.Config.get('APPS_ROOT', '.');
		this.templates = {};
		Frames.Template.get(appsroot + this.options.template, function(result)
		{
			that.templates.main = result;
			that._refresh();
			that._initializeClick();

			if (Frames.isFunction(that.options.callback))
			{
				that.options.callback();
			}

			var block = Frames.Application.task.block;
			if (!Frames.isUndef(block))
			{
				var item = that.options.panelItem;
				if (!Frames.isUndef(item) && Frames.isFunction(item._toolbar_fn))
				{
					var rules = Frames.ToolBar.customRulesObj(block);
					item._toolbar_fn(item, rules);
				}
			}
		});
	},

	_initializeClick: function(selector, parent)
	{
		var that = this;
		var bindable = this.options.bindable;

		selector = selector || '.ui-panel-toolbar';
		parent = parent || this.element.parent();
		$(selector + ' .toolbar-button, .toolbar-menu-option', parent).on('click', function(ev)
		{
			var $el = $(this);
			var action = $el.data('action');
			var disabled = $el.hasClass('ui-state-disabled');

			if (disabled)
			{
				Frames.focus();
				return;
			}

			if (!Frames.isUndef(action) && !Frames.isEmpty(action))
			{
				var result = $('.ui-filterpanel:visible');
				if (result.length == 0)
				{
					Frames.Application.valexec(action);
				}
				else
				{
					Frames.Application.execute(action);
				}
				if ($el.hasClass('toolbar-menu-option'))
				{
					var $menu = $el.parents('.toolbar-menu');
					PanelToolbar.hideToolbarMenu($menu);
				}
				return false;
			}
			else if ($el.hasClass('toolbar-menu-button'))
			{
				PanelToolbar.toggleToolbarMenu($el);
			}
			else if ($el.hasClass('toolbar-checkbox'))
			{
				that.toggleCheckbox($el);
			}
			else
			{
				that._toggleView(ev.target);
			}
		});

		$('.ui-panel-toolbar', parent).on('click', function() { return false; });
	},

	toggleCheckbox: function(el)
	{
		var i = el.children('i');
		if (el.hasClass('toolbar-checkbox-unchecked'))
		{
			el.removeClass('toolbar-checkbox-unchecked');
			el.addClass('toolbar-checkbox-checked');
			i.removeClass('fa-square');
			i.addClass('fa-check-square');
		}
		else
		{
			el.removeClass('toolbar-checkbox-checked');
			el.addClass('toolbar-checkbox-unchecked');
			i.removeClass('fa-check-square');
			i.addClass('fa-square');
		}
	},

	_toggleView: function(target)
	{
		var that = this;
		var $el = this.element;

		if (!Frames.isUndef($el))
		{
			var $parent = $el.parent();
			var item = Frames.Application.current();
			if (Frames.isUndef(target))
			{
				var $bindable = item.bindable().elem;

				if (Frames.isEmpty(this.element.parent().find($bindable)[0]))
				{
					// shortcut only works on the current bindable
					return;
				}
			}

			//overrided isValueChanged to not having to change the framework
			var validItem = true;
			var status = item.props('serverStatus');

			//check if the value was changed
			var hasChanges;
			if (item.context)
			{
				var v1 = item._removeBreakLines(item.ovalue());

				var data = item.context._getData();
				var field = item.context._col.field;
				var v2 = item._removeBreakLines(data[field + ':last_value']);
				var options = { allowedKeywords: Frames.Item.getAllowedKeywords(item) };
				var value = item._differentValues() ? item.value() : Frames.Format.formatToCanonical(v1, item.props('format'), item.props('type'), options);
				var difValue = Frames.Format.formatToCanonical(v2, item.props('format'), item.props('type'), options);

				hasChanges = (!(Frames.isEmpty(value) && Frames.isUndef(v2))) && (value != difValue);
			}
			else
			{
				hasChanges = item.hasChanges();
			}

			if (status != 'INSERTED' || hasChanges)
			{
				Frames.Validation.validate(item);
				validItem = item.props('Valid');
			}
			if (!validItem)
			{
				Frames.focus();
				return;
			}

			var $target = target ? $(target) : $('.' + (this._activeView === 'multi' ? this._singleIcon : this._multiIcon), $parent);

			var $toggle = $('.toolbar-toggle',$parent);

			if (Frames.isEmpty($target[0]) || $toggle.hasClass('ui-state-disabled'))
			{
				return;
			}

			var pager = this._getWidgetPaging();
			if ($target.hasClass(this._multiIcon))
			{
				$target.removeClass(this._multiIcon).addClass(this._multiInvIcon);
				$parent.find('.' + this._singleInvIcon).removeClass(this._singleInvIcon).addClass(this._singleIcon);

				that._hideEditPanel();

				this._activeView = 'multi';

				var widget = PanelToolbar.getmultirecordwidget(this.element);
				var isDataGrid = widget.data('widget') == 'datagrid';
				if (isDataGrid)
				{
					widget.data('frames').invalidate();
				}

				if (pager)
				{
					pager.unit = 'page';
				}
			}
			else if ($target.hasClass(this._singleIcon))
			{
				$target.removeClass(this._singleIcon).addClass(this._singleInvIcon);
				$parent.find('.' + this._multiInvIcon).removeClass(this._multiInvIcon).addClass(this._multiIcon);

				that._openEditPanel();

				this._activeView = 'simple';
				if (pager)
				{
					pager.unit = 'record';
				}
			}
		}
	},

	_getUrl: function(id)
	{
		var path = Frames.View.mapView(id);

		if (Frames.Locale.lang !== null)
		{
			path += (path.indexOf('?') != -1 ? '&' : '?');
			path += 'lang=' + Frames.Locale.lang;
		}

		return path;
	},

	_getEditPane: function(callback)
	{
		var that = this;
		var $editpane;

		if (Frames.isUndef(this._container))
		{
			var bindable = this._getBindable();
			var block = bindable.block;
			var curr = Frames.Application.current();
			var ep = bindable.extensions('EP');

			if (/*ep == 1 ||*/ ep == 2)
			{
				var url = this._getUrl(bindable.props('editpanel'));

				var html = Frames.Template.load(url, block.name, undefined, function(html)
				{
					$(html).each(function()
					{
						if ($(this).is('.ui-view-window'))
						{
							$editpane = $(this);
							$editpane.insertAfter(that.element.next().find('.filterForm'));

							that._container = {
								id: Frames.uuid(),
								elem: $editpane,
								_OBJS_: {},
								_ITEMS_: new Frames.HashMap(),
								_ORIG_: block._ITEMS_
							};
							block._ITEMS_ = that._container._ITEMS_;

							// initialize filter panel
							$editpane.find('[data-widget]').each(function()
							{
								var $el = $(this);
								var objId = $el.attr('id') || Frames.uuid();
								$el.attr('id', objId);
								$el.addClass('ui-editpanel-widget');

								Frames.Application._controlinfo_optimization = false;
								var item = Frames.create(objId, $el, Frames.Application.task.view, that._container);
								Frames.Application._controlinfo_optimization = Frames.Config.getbool('OPTIMIZATION.CONTROLINFO', false);
							});

							block.item = block.get(curr.member);

							return false;
						}
					});

					if (Frames.isFunction(callback))
					{
						callback($editpane);
					}		
				});
			}
		}
		else
		{
			$editpane = this._container.elem;
			if (Frames.isFunction(callback))
			{
				callback($editpane);
			}
		}

		return $editpane;
	},

	_getBindable: function()
	{
		if (this.options.bindable)
		{
			return this.options.bindable;
		}
		else
		{
			var item = Frames.Application.current();
			return item.bindable();
		}
	},

	_getWidgetElem: function()
	{
		var bindable = this._getBindable();
		return bindable && bindable.elem ? bindable.elem : $();
	},

	_getWidgetPaging: function()
	{
		var bindable = this._getBindable();
		return bindable && bindable._pager ? bindable._pager.paging : undefined;
	},

	_openEditPanel: function(forceSingleMode)
	{
		var that = this;
		this._getEditPane(function($pane) {
			if ($pane !== undefined)
			{
				var paging = that._getWidgetPaging();
				var $elem = that._getWidgetElem();
	
				if (paging)
				{
					paging._lastsize = paging.size;
					paging._lastmultiple = paging.multiple;
					that.toggleExecuter(1,'SETUP_TOGGLE',false);
					paging.multiple = false;
				}

				$elem.hide();
				$pane.show();

				if (forceSingleMode)
				{
					that._activeView = 'simple';
					if (paging)
					{
						paging.unit = 'record';
					}

					var singleIcon = that._singleIcon;
					var multiIconInv = that._multiInvIcon;
					that.element.find('.' + singleIcon).removeClass(singleIcon).addClass(that._singleInvIcon);
					that.element.find('.' + multiIconInv).removeClass(multiIconInv).addClass(that._multiIcon);
				}
			}

			Frames.focus();
		});
	},

	toggleExecuter: function(num, setup, reset) {
		var paging = this._getWidgetPaging();
		var actions = [{
			name: 'pageSize',
			value: num,
			type: 'int'
		}];

		if (reset === false)
		{
			actions.push({
				name: 'reset',
				value: 'false',
				type: 'boolean'
			});
		}

		var action;
		if (setup == 'SETUP_TOGGLE')
		{
			action = 'SETUP_TOGGLE';
			paging.execute(action, actions);
		}else
		{
			action = setup ? 'LOV_SETUP_PAGE':'SETUP_PAGE';
			paging.execute(action, actions);
		}
	},

	_removeEditPanel: function(r)
	{
		r.elem.remove();
		delete r.elem;

		for (var prop in r._OBJS_)
		{
			if (r._OBJS_.hasOwnProperty(prop))
			{
				var it = r._OBJS_[prop];
				if (typeof it.destroy === 'function')
				{
					it.destroy();
				}
			}
		}
		delete r._OBJS_;

		r._ITEMS_.clear();
	},

	_hideEditPanel: function()
	{
		var that = this;
		var block = this._getBindable().block;
		var curr = Frames.Application.current();

		this._getEditPane(function($pane) {
			if ($pane !== undefined)
			{
				var paging = that._getWidgetPaging();
				if (paging)
				{
					that.toggleExecuter(paging._lastsize,'SETUP_TOGGLE',false);
					paging.multiple = paging._lastmultiple;
					delete paging._lastsize;
					delete paging._lastmultiple;
				}

				that._removeEditPanel(that._container);
				block._ITEMS_ = that._container._ORIG_;
				block.item = block.get(curr.member);
				delete that._container;

				$pane.hide();
				that._getWidgetElem().show();

				Frames.focus();
			}	
		});
	},

	// events bound via _on are removed automatically
	// revert other modifications here
	_destroy: function()
	{
		$('.ui-panel-toolbar .toolbar-button', this.element.parent()).off('click');
		$('.ui-panel-toolbar', this.element.parent()).off('click');
		$(document).off('keyup', this._toggleViewFn);
	},

	// called when created, and later when changing options
	// and menu methods
	_refresh: function()
	{
		if (!this.templates.main)
		{
			return;
		}

		var that = this;

		if (!this._initialized)
		{
			this._initialized = true;

			_$.workspace.verticalmenu.prototype._apply_shortcuts(this.options.items);

			if (!Frames.isUndef(this.options.menu))
			{
				_$.workspace.verticalmenu.prototype._apply_shortcuts(this.options.menu.items);
				var checkboxKey = Frames.Config.getaction_name('MASTER_CHECKBOX_CLICK').accesskey;
				this.options.menu.checkboxShortcut = Frames.humanize_shortcut(checkboxKey);
			}

			var hotkey = Frames.Config.get('WORKSPACE_ACTIONS').get('TOGGLE_VIEW');
			if (hotkey)
			{
				_$.each(this.options.toggleIcons, function(i, item)
				{
					item.shortcut = hotkey;
				});

				Frames.Config.regaccesskey(hotkey);
				$(document).off('keyup', this._toggleViewFn.bind(this));
				$(document).on('keyup', hotkey, this._toggleViewFn.bind(this));
			}

			var tmplOptions = _$.extend({}, { items: this.options.items, rtl: this._isRTL, toggle: this.options.toggle, toggleIcons: this.options.toggleIcons, hasMenu: this.options.hasMenu, menu: this.options.menu, hasCheckbox: true });
			var html = this.templates.main(tmplOptions);
			this.element.children('.ui-collapsiblepanel-title, .ui-accordion-title').before(html);
		}
	},

	_toggleViewFn: function(ev)
	{
		this._toggleView();
	}
});

var PanelToolbar =
{
	isExtendable: function(item)
	{
		if (Frames.inDesignMode)
		{
			return false;
		}

		if (Frames.isUndef(item) || !Frames.isFunction(item.widgetcls))
		{
			return false;
		}

		var wname = item.widgetcls();
		return (wname == 'accordion' || wname == 'collapsiblepanel');
	},

	isMultiRecord: function(item)
	{
		if (Frames.inDesignMode)
		{
			return false;
		}

		var wname = item.bindable().widgetcls();
		return (wname == 'datagrid' || wname == 'repeater');
	},

	_add_notinitialized: function(id)
	{
		if (Frames.isUndef(PanelToolbar._NOINIT_))
		{
			PanelToolbar._NOINIT_ = [];
		}
		PanelToolbar._NOINIT_.push(id);
	},

	getfirstwidget: function($el)
	{
		return $el.parent().children('.ui-accordion-content,.ui-collapsiblepanel-content')
			//.find('[data-widget=datagrid],[data-widget=repeater]')
			.find('[data-widget][data-block]').not('[data-widget$=panel]').not('[data-widget=button]')
			.first();
	},

	getmultirecordwidget: function($el)
	{
		return $el.parent().children('.ui-accordion-content,.ui-collapsiblepanel-content').find('[data-widget=datagrid],[data-widget=repeater]').first();
	},

	getupawidget: function($el)
	{
		return $el.parent().children('.ui-accordion-content,.ui-collapsiblepanel-content').find('[data-widget=datagrid],[data-widget=repeater],[data-widget=pager]').first();
	},

	hasCheckedCheckbox: function()
	{
		return $('.toolbar-checkbox-checked:not(.ui-state-disabled)').length > 0;
	},

	getMenuCheckbox: function()
	{
		return $('.toolbar-checkbox:not(.ui-state-disabled):visible');
	},

	isOptionEnabled: function(action)
	{
		return $('.toolbar-menu-button:not(.ui-state-disabled)~.toolbar-menu, body>.toolbar-menu')
			.find('.toolbar-menu-option[data-action=' + action + ']:not(.ui-state-disabled)').length > 0;
	},

	isRestoreSettingsEnabled: function(action)
	{
		var restoreSettingsOption = $('#menu-tools').find('[data-action="RESTORE_GLOBAL_SETTINGS"]')
		return $('#menu-tools').find('[data-action="RESTORE_GLOBAL_SETTINGS"]').is(":visible");
	},

	register: function(item)
	{
		var that = this;

		// support for not initialized elements
		if (!Frames.isUndef(PanelToolbar._NOINIT_) && !Frames.isUndef(item.elem))
		{
			var iid = item.elem.data('notid');
			var idx = $.inArray(iid, PanelToolbar._NOINIT_);
			if (idx != -1)
			{
				// check if item is inside a accordion or collapsible panel and if so return it
				var $panel = item.elem.closest('[data-widget=\'accordion\'],[data-widget=\'collapsiblepanel\']');
				if ($panel.length > 0)
				{
					var it = $panel.data('frames');
					if (!Frames.isUndef(it))
					{
						item.elem.data('notid', null);
						item = it;
						delete item._wait_toolbar;
					}
				}

				PanelToolbar._NOINIT_.splice(idx, 1);
			}
		}

		if (PanelToolbar.isExtendable(item))
		{
			$.each(item.headers(), function(i, header)
			{
				var $el = $(header);
				var toggle = false;
				var hasMenu = false;

				var $widget = PanelToolbar.getmultirecordwidget($el);
				var isMultiRecord = $widget.data('widget') == 'datagrid' || $widget.data('widget') == 'repeater';

				var bindable = $widget.data('frames');

				// item was initialized
				if (bindable && bindable.block)
				{
					// add support for toggle button in datagrids
					var paneUrl = bindable.props('editpanel');
					if (!Frames.isEmpty(paneUrl))
					{
						toggle = true;
						bindable.extensions('EP', 2);
						bindable.extensions('EP_URL', paneUrl);
					}
				}

				// item wasn't initialized so check for supported widgets
				else if (isMultiRecord)
				{
					var nid = 'notinit_' + Frames.uuid();
					$widget.data('notid', nid);

					that._add_notinitialized(nid);

					item._wait_toolbar = true;

					// HACK: store frames when it's still initializing...
					if (Frames.isUndef(item.elem.data('frames')))
					{
						item.elem.data('frames', item);
					}

					return true; // don't initialize yet
				}

				if (PanelToolbar.getupawidget($el).length > 0)
				{
					hasMenu = true;
				}

				// initialize paneltoolbar
				$el.paneltoolbar({
					toggle: toggle,
					bindable: bindable,
					panelItem: item,
					hasMenu: hasMenu,
					callback: function()
					{
						// bind toolbar menu and button together so that menu can be moved to <body> when it's active
						var $settingsBtn = $el.parent().find('.toolbar-menu-button');
						if ($settingsBtn.length > 0)
						{
							var $menu = $settingsBtn.next();
							$settingsBtn.data('menu', $menu);
							$menu.data('btn', $settingsBtn);
						}
					}
				});

				// make sure that we already have a pager, which may happen when you bind more than once (ELLBHR-40146)
				$el.parent().find('.filterForm').remove();

				// initialize filter panel
				var filter = $('<div class="filterForm"></div>');
				$el.next().prepend(filter);
				filter.filterpanel(
					{
						sort: false,
						bindable: bindable
					});
			});

			// wait for initialization or don't duplicate trigger
			if (!Frames.isUndef(item._wait_toolbar) || !Frames.isUndef(item._toolbar_fn))
			{
				return;
			}

			item._toolbar_fn = PanelToolbar._toolbar_fn(item);
			Frames.Application.on('toolbarrefresh', item._toolbar_fn);

			// hide toolbar menu on cancelpopups
			$(document).on('mousedown', function(evt) {
				var menu = $('body > .toolbar-menu');
				if (menu.length > 0)
				{
					var btn = menu.data('btn');
					if (evt.target != menu && 
						evt.target != btn &&
						menu.has(evt.target).length == 0 &&
						btn.has(evt.target).length == 0)
					{
						that.hideToolbarMenu(menu);
					}
				}
			});

			var container = Frames.Application.getContainer(item.elem);
			container.on('resize scroll', function() {
				var $menu = $('body > .toolbar-menu');
				PanelToolbar.hideToolbarMenu($menu);
			});

			$(window).on('toolbarrefresh', function() {
				var $menu = $('body > .toolbar-menu');
				PanelToolbar.hideToolbarMenu($menu);
			});

			Frames.Application.on('columndragstart', function() {
				var $menu = $('body > .toolbar-menu');
				PanelToolbar.hideToolbarMenu($menu);
			});
		}
	},

	_toolbar_fn: function(item)
	{
		var that = this;

		return function(obj, rules)
		{
			var elem = item.elem;

			try
			{
				var initialized = Frames.isTrue(elem.data('sde'));
				var $el = item.headers().parent();

				that.disableElement($el.find('.ui-panel-toolbar .toolbar-button'));

				if (!initialized)
				{
					$el.find('.ui-panel-toolbar .ui-info').hide();
				}

				var it = Frames.Application.current();
				if (it)
				{
					var bindable = it.bindable();
					var block = bindable.block;

					var container = bindable.elem.parentsUntil('.ui-accordion, .ui-collapsiblepanel').last();
					var parent = container.parent();

					if ((parent.is('.ui-accordion') && parent.parent().get(0) == elem.get(0))
					|| (parent.is('.ui-collapsiblepanel') && parent.get(0) == elem.get(0)))
					{
						var moderead = block.props('blockMode') == 'READ' || block.extensions('DISABLE_ACTIONS') == 'Y';
						var header = container.prev();

						that.manageSettings(header, true);

						if (rules)
						{

							if (rules.canAdd && !moderead)
							{
								that.enableElement(header.find('.toolbar-button').has('.ba-add'));
							}

							if (rules.canDelete && !moderead)
							{
								that.enableElement(header.find('.toolbar-button').has('.ba-delete'));
							}

							if (rules.canCopy && !moderead)
							{
								that.enableElement(header.find('.toolbar-button').has('.ba-copy'));
							}

							var sde = block.extensions('SDE');
							if (sde == '1' || sde == '2')
							{
								if (block.props('blockMode') !== 'SEARCH')
								{
									that.enableElement(header.find('.ui-info'));

								}

								var emptyClass = 'ba-more-empty';
								var filledClass = 'ba-more-filled';

								var newClass = sde == '1' ? emptyClass : filledClass;

								header.find('.ui-info').show();
								header.find('.toolbar-button.ui-info i')
										.removeClass(emptyClass).removeClass(filledClass)
										.addClass(newClass);
							}
							elem.data('sde', true);


							if ((that.isMultiRecord(it) || it.elem.hasClass('ui-editpanel-widget')) && (block.props('blockMode') !== 'SEARCH'))
							{
								that.enableElement(header.find('.toolbar-toggle'));
							}

							// filter button
							if (rules.canFilter)
							{
								that.enableElement(header.find('.toolbar-button').has('.ba-filter'));
							}

							var searchSingleRecord = it === bindable && !PanelToolbar.getfirstwidget(container).is('[data-widget=repeater], [data-widget=datagrid]');

							if (that.isMultiRecord(it) || searchSingleRecord)
							{
								var filter = header.parent().find('.filterForm');
								filter.filterpanel('bindable', bindable);
							}
						}

						var actions = block.extensions('ACTIONS');

						if (!Frames.isUndef(actions))
						{
							if (typeof(actions) == 'string') 
							{ 
								actions = JSON.parse(actions); 
							}

							var appsroot = Frames.Config.get('APPS_ROOT', '.');
							Frames.Template.get(appsroot + $.workspace.paneltoolbar.prototype.options.template, function(template)
							{
								//remove custom panelTollbar if already exist
								if (parent.find('.ui-custom-panel-toolbar').length > 0)
								{
									parent.find('.ui-custom-panel-toolbar').remove();
								}

								var isRtl = parent.children().css('direction') === 'rtl'
								var tmplOptions = _$.extend({}, { items: actions, rtl: isRtl});
								var html = template(tmplOptions);
								var toolbar = parent.find('.ui-panel-toolbar');
								var width = $(toolbar).css('width');

								toolbar.after(html);
								parent.find('.ui-panel-toolbar').last().addClass('ui-custom-panel-toolbar');
								var customToolbar = parent.find('.ui-custom-panel-toolbar');

								//TODO: Change template to allow to customize enabled/disabled
								var custumActions = customToolbar.find ('li > a ');
								for (var i = 0; i < custumActions.length; i++)
								{
									var action = actions[i];
									if (action.visible === false)
									{
										continue;
									}
									var custumAction = $(custumActions[i]);
									that.enableElement(custumAction);
								}

								$.workspace.paneltoolbar.prototype._initializeClick('.ui-custom-panel-toolbar', parent);
							});
						}
					}
					else if (elem.is(':visible'))
					{
						var header = elem.find('.ui-accordion-header, .ui-collapsiblepanel-header');
						that.manageSettings(header, false);
					}
				}
			}
			catch (ex)
			{
				console.log(ex);
			}
		};
	},

	disableElement: function($el)
	{
		if ($el)
		{
			$el.addClass('ui-state-disabled').attr('tabindex',-1).attr('aria-disabled', 'true');
		}
	},

	enableElement: function($el)
	{
		if ($el)
		{
			$el.show().removeClass('ui-state-disabled').removeAttr('tabindex',-1).attr('aria-disabled', null);
		}
	},

	unregister: function(item)
	{
		if (PanelToolbar.isExtendable(item))
		{
			Frames.Application.off('toolbarrefresh', item._toolbar_fn);

			$.each(item.headers().parent(), function(i, header)
			{
				$(header).find('.ui-panel-toolbar').remove();
			});
		}
	},

	hasColumnSettings: function()
	{
		var bindable = Frames.Application.current().bindable();
		var block = bindable.block;
		return this.hasDatagrid();
	},

	hasDatagrid: function()
	{
		var bindable = Frames.Application.current().bindable();
		return bindable.widgetcls() == 'datagrid';
	},

	hasPaginationSettings: function()
	{
		var bindable = Frames.Application.current().bindable();
		var block = bindable.block;
		return !Frames.isUndef(block.paging) && Frames.isTrue(block.paging.multiple);
	},

	hasFilterSettings: function()
	{
		var bindable = Frames.Application.current().bindable();
		var block = bindable.block;
		return block.isFilterEnabled();
	},

	isMaster: function()
	{
		var task = Frames.Application.task;
		return task.isMaster();
	},

	manageSettings: function(header, isCurrentBlock)
	{
		var task = Frames.Application.task;

		var $widget = this.getupawidget(header);
		var hasUpaWidget = $widget.length > 0;

		/*var isMultiRecord;
		if (isCurrentBlock)
		{
			var bindable = Frames.Application.current().bindable();
			var block = bindable.block;
			isMultiRecord = block.isMultiRecord();
		}*/

		// show Settings button if block is multirecord
		var settingsBtn = header.find('.toolbar-button').has('.fa-cog');
		var masterBtn = header.find('.toolbar-button.toolbar-checkbox');
		var separator = settingsBtn.parent().nextAll('li.toolbar-separator').eq(0);

		if (task.isUpaInstitution() && task.hasPageSettings() && hasUpaWidget)
		{
			separator.show();

			settingsBtn.show()
			if (isCurrentBlock)
			{
				this.enableElement(settingsBtn);
			}
			else
			{
				this.disableElement(settingsBtn);
			}

			if (this.isMaster())
			{
				masterBtn.show()
				if (isCurrentBlock)
				{
					this.enableElement(masterBtn);
				}
				else
				{
					this.disableElement(masterBtn);
				}
			}
			else
			{
				masterBtn.hide();
			}

			var settingsMenu = settingsBtn.data('menu');

			if (isCurrentBlock && !Frames.isUndef(settingsMenu))
			{
				var hasSettings = false; // checks if there is any kind of settings enabled

				// show Column options if panel contains a datagrid
				var saveColumnBtn = settingsMenu.find('#save-grid-bt');
				var restoreColumnBtn = settingsMenu.find('#restore-grid-bt');

				if (this.hasColumnSettings())
				{
					hasSettings = true;
					this.enableElement(saveColumnBtn);
					this.enableElement(restoreColumnBtn);
				}
				else if (!this.hasDatagrid())
				{
					saveColumnBtn.hide();
					restoreColumnBtn.hide();
				}

				var saveFilterBtn = settingsMenu.find('#save-filter-bt');
				var restoreFilterBtn = settingsMenu.find('#restore-filter-bt');

				if (this.hasFilterSettings())
				{
					hasSettings = true;
					this.enableElement(saveFilterBtn);
					this.enableElement(restoreFilterBtn);
				}
				else
				{
					this.disableElement(saveFilterBtn);
					this.disableElement(restoreFilterBtn);
				}

				var savePaginationBtn = settingsMenu.find('#save-pagination-bt');
				var restorePaginationBtn = settingsMenu.find('#restore-pagination-bt');

				if (this.hasPaginationSettings())
				{
					hasSettings = true;
					this.enableElement(savePaginationBtn);
					this.enableElement(restorePaginationBtn);
				}
				else
				{
					this.disableElement(savePaginationBtn);
					this.disableElement(restorePaginationBtn);
				}

				var saveAllBtn = settingsMenu.find('#save-all-bt');
				var restoreAllBtn = settingsMenu.find('#restore-all-bt');

				if (hasSettings)
				{
					this.enableElement(saveAllBtn);
					this.enableElement(restoreAllBtn);
				}
				else
				{
					this.disableElement(saveAllBtn);
					this.disableElement(restoreAllBtn);
				}
			}
		}
		else
		{
			settingsBtn.hide();
			masterBtn.hide();
			separator.hide();
		}
	},

	toggleToolbarMenu: function($el)
	{
		var $menu = $el.data('menu');

		if ($menu.hasClass('toolbar-menu-open'))
		{
			this.hideToolbarMenu($menu);
		}
		else
		{
			this.showToolbarMenu($menu);
		}
	},

	showToolbarMenu: function($menu)
	{
		var $btn = $menu.data('btn');
		var $ref = $btn.parent();
		var $dropdown = $menu.children('ul.dropdown-menu');
		var $wrkspContainer = $('.workspace-container');

		$menu.show();
		$menu.addClass('toolbar-menu-open');

		$menu.css({'left': ''});
		$dropdown.css({'left': '', 'right': ''});

		var container = $('.workspace-container')[0];
		var containerPos = container.getBoundingClientRect();
		var dropdownPos = $dropdown[0].getBoundingClientRect();
		var isRtl = Frames.Locale.formats.IS_RTL;
		if (dropdownPos.right > containerPos.right || (isRtl && dropdownPos.left > containerPos.left))
		{
			$menu.css('left', $ref.offset().left + $ref.width());
			$dropdown.css('right', 0);
		}
		else
		{
			$menu.css('left', $ref.offset().left);
			$dropdown.css('left', 0);
		}

		$menu.css('top', $ref.offset().top + $ref.height());
		$menu.css('margin-top', '4px');

		if ($wrkspContainer.offset().top + $wrkspContainer.height() < $menu.offset().top + $dropdown.outerHeight() &&
			$wrkspContainer.offset().top < $ref.offset().top - $dropdown.outerHeight())
		{
			$menu.css('top', $ref.offset().top - $dropdown.outerHeight());
			$menu.css('margin-top', '-4px');
		}

		$('body').append($menu);
	},

	hideToolbarMenu: function($menu)
	{
		if ($menu.length > 0)
		{
			var $btn = $menu.data('btn');

			$menu.hide();
			$menu.removeClass('toolbar-menu-open')
			$btn.after($menu);
		}
	}
};

var createSaveParam = function(model, name)
{
	var jsonParam = Frames.Model.encode(JSON.stringify(model).replace(/"/g, '\''));
	return {
		name: name,
		type: 'string',
		value: jsonParam
	};
};

var createEmptyParam = function(name)
{
	return {
		name: name,
		type: 'string',
		value: ''
	};
};

var isEqualModel = function(model1, model2)
{
	return JSON.stringify(model1) == JSON.stringify(model2);
}

Frames.regplug('panel.toolbar', PanelToolbar, Frames.PLUGIN_WIDGET);

Frames.Application.registerActionHandler('SaveSettingsAction', function(action)
{
	// prevent activating options with keyboard shortcut when they're not available in the options menu
	if (!PanelToolbar.isOptionEnabled(action.name))
	{
		return;
	}

	var paramsArr = [];
	var model, name;
	var bindable = Frames.Application.current().bindable();
	var currentBlock = bindable.block;

	var isSaveGrid = action.name == 'SAVE_GRID_SETTINGS';
	var isSaveFilter = action.name == 'SAVE_FILTER_SETTINGS';
	var isSaveAll = action.name == 'SAVE_ALL_SETTINGS';

	if (isSaveAll || isSaveGrid)
	{
		var sendEmptyParam = true;
		name = 'grid';

		if (PanelToolbar.hasColumnSettings())
		{
			model = currentBlock.props_model();
			var initialModel = currentBlock.getInitialPropsModel();
			if (!isEqualModel(model, initialModel))
			{
				sendEmptyParam = false;
				paramsArr.push(createSaveParam(model, name));
				currentBlock.setInitialPropsModel(model);
			}
			else if (isSaveGrid)
			{
				Frames.Workspace.closeAlert();
				Frames.Workspace.showMessage(_('PUP_NO_GRID_CHANGES'));
				return;
			}
		}

		if (isSaveAll && sendEmptyParam)
		{
			paramsArr.push(createEmptyParam(name));
		}
	}

	if (PanelToolbar.hasPaginationSettings() && (isSaveAll || action.name == 'SAVE_PAGINATION_SETTINGS'))
	{
		model = currentBlock.pagination_model();
		name = 'page';
		paramsArr.push(createSaveParam(model, name));
	}
	else if (isSaveAll)
	{
		name = 'page';
		paramsArr.push(createEmptyParam(name));
	}

	if (isSaveAll || isSaveFilter)
	{
		var sendEmptyParam = true;
		name = 'filter';

		if (PanelToolbar.hasFilterSettings())
		{
			model = currentBlock.filter_model();
			var initialModel = currentBlock.getInitialFilterModel();
		
			if (!isEqualModel(model, initialModel))
			{
				sendEmptyParam = false;
				paramsArr.push(createSaveParam(model, name));
				currentBlock.setInitialFilterModel(model);
			}
			else if (isSaveFilter)
			{
				Frames.Workspace.closeAlert();
				Frames.Workspace.showMessage(_('PUP_NO_FILTER_CHANGES'));
				return;
			}
		}

		if (isSaveAll && sendEmptyParam)
		{
			paramsArr.push(createEmptyParam(name));
		}
	}

	if (paramsArr.length > 0)
	{
		// if there is an active master checkbox, and it is checked, save settings as master user
		paramsArr.unshift({name: 'master', type: 'boolean', value: PanelToolbar.hasCheckedCheckbox()});

		Frames.Application.execute({
			name: action.name,
			params: paramsArr
		});
	}
});

Frames.Application.registerActionHandler('RestoreSettingsAction', function(action)
{
	// prevent activating options with keyboard shortcut when they're not available in the options menu
	if (action.name != 'RESTORE_GLOBAL_SETTINGS' && !PanelToolbar.isOptionEnabled(action.name))
	{
		return;
	}
	else if (action.name == 'RESTORE_GLOBAL_SETTINGS' && !PanelToolbar.isRestoreSettingsEnabled())
	{
		return;
	}

	var name;
	switch (action.name)
	{
	case 'RESTORE_GRID_SETTINGS':
		name = 'grid';
		break;
	case 'RESTORE_PAGINATION_SETTINGS':
		name = 'page';
		break;
	case 'RESTORE_FILTER_SETTINGS':
		name = 'filter';
		break;
	case 'RESTORE_ALL_SETTINGS':
		name = 'all';
		break;
	case 'RESTORE_GLOBAL_SETTINGS':
		name = 'global';
		break;
	default:
		return;
	}

	var paramsArr = [];
	paramsArr.push({name: 'master', type: 'boolean', value: PanelToolbar.hasCheckedCheckbox()});
	paramsArr.push({name: name, type: 'string', value: ''});

	Frames.Application.execute({
		name: action.name,
		params: paramsArr
	});
});

Frames.Application.registerActionHandler('MasterCheckboxAction', function(action)
{
	if (action.name == 'MASTER_CHECKBOX_CLICK' && PanelToolbar.isMaster())
	{
		PanelToolbar.getMenuCheckbox().trigger('click');
	}
});

Frames.ready(function()
{
	// register UPA actions if they aren't defined in config.xml file
	var upaActionList = [
		{name: 'SAVE_GRID_SETTINGS', accesskey: 'ALT+SHIFT+1', type: 'SaveSettingsAction'},
		{name: 'SAVE_PAGINATION_SETTINGS', accesskey: 'ALT+SHIFT+2', type: 'SaveSettingsAction'},
		{name: 'SAVE_FILTER_SETTINGS', accesskey: 'ALT+SHIFT+3', type: 'SaveSettingsAction'},
		{name: 'SAVE_ALL_SETTINGS', accesskey: 'ALT+SHIFT+4', type: 'SaveSettingsAction'},
		{name: 'RESTORE_GRID_SETTINGS', accesskey: 'ALT+SHIFT+5', type: 'RestoreSettingsAction'},
		{name: 'RESTORE_PAGINATION_SETTINGS', accesskey: 'ALT+SHIFT+6', type: 'RestoreSettingsAction'},
		{name: 'RESTORE_FILTER_SETTINGS', accesskey: 'ALT+SHIFT+7', type: 'RestoreSettingsAction'},
		{name: 'RESTORE_ALL_SETTINGS', accesskey: 'ALT+SHIFT+8', type: 'RestoreSettingsAction'},
		{name: 'MASTER_CHECKBOX_CLICK', accesskey: 'CTRL+SHIFT+M', type: 'MasterCheckboxAction'},
		{name: 'DISABLE_SETTINGS', accesskey: 'CTRL+ALT+0', type: 'DisableSettingsAction'},
		{name: 'RESTORE_GLOBAL_SETTINGS', accesskey: 'CTRL+SHIFT+Z', type: 'RestoreSettingsAction'}
	];

	for (var idx in upaActionList)
	{
		var actionToRegister = upaActionList[idx];
		var action = Frames.Config.getaction_name(actionToRegister.name);
		if (Frames.isUndef(action))
		{
			Frames.Config.regaction(actionToRegister);
		}
	}
});

//# sourceURL=app/flat/widgets/paneltoolbar/js/panel.toolbar.js
