function initExperienceIntegration()
{
    // add all experience functionality here...
	initExperienceProps();
	handleExperienceTheme();
	handlePageTitle();
    handleToolsMenu();
	handleToolbar();
	handleNotifications();
	handleClose();
	handleDirtyStateMessage();
	handleHelp();
	sendIframeHeightMessage();
	handleOpenExternalPage();
	handleUrlChange();

    M.start(experienceMessageHandler);
	sendSetupCloseMessage();
}

function initExperienceProps()
{
	Frames.Workspace._EXPERIENCE_ = {};
}

function getExperienceProp(key)
{
	return Frames.Workspace._EXPERIENCE_[key];
}

function setExperienceProp(key, value)
{
	Frames.Workspace._EXPERIENCE_[key] = value;
}

function handleExperienceTheme()
{
	//add experience theme option
	var appConfig = Frames.Config.get('APP_CONFIG');
	if (!Frames.isUndef(appConfig) && !Frames.isUndef(appConfig.themes))
	{
		appConfig.themes.experience = {label: 'EXPERIENCE'};
	}

	// force Experience theme
	// feature check for jQuery.cookie version
	if (typeof Cookies == 'undefined')
	{
		$.cookie('themeswitcher:theme', 'experience');
	}
	else
	{
		Cookies.set('themeswitcher:theme', 'experience');
	}

	// add Experience class to apply header CSS
	// (this isn't in the theme otherwise the header would be hidden outside of Experience for this theme)
	_$('body').addClass('experience');

	Frames.ready(loadExperienceTheme);
}

function loadExperienceTheme()
{
	// check if cookie was applied and there is an Experience theme CSS loaded
	var experienceCSS = _$('link[rel=stylesheet][href*=experience]');
	if (experienceCSS.length > 0)
	{
		// theme was loaded successfully
		return;
	}

	// click Experience Theme tools menu option to load theme
	var experienceMenuOpt = _$('#menu-tools').find('li[data-theme=experience] > a');
	if (experienceMenuOpt.length > 0)
	{
		experienceMenuOpt.trigger('click');
		return;
	}

	// get default theme and replace it by Experience theme
	var appConfig = Frames.Config.get('APP_CONFIG');
	if (!Frames.isUndef(appConfig))
	{
		var themes = appConfig.themes;
		for (var themeName in themes)
		{
			var theme = themes[themeName];
			if (theme.default)
			{
				var defaultThemeCss = _$(`link[rel=stylesheet][href*=${themeName}]`);
				var themeUrl = defaultThemeCss.attr('href');
				themeUrl = themeUrl.replace(themeName, 'experience');
				defaultThemeCss.attr('href', themeUrl);
				break;
			}
		}
	}
}

function handleUrlChange()
{
	Frames.Application.on('urlchange', function(ev, params)
    {
        sendPathNameMessage(params.url);
    });
}

function handleOpenExternalPage()
{
    Frames.Application.on('openExternalPage', function(ev, params)
    {
        openExternalPage(params);
    });
}

function openExternalPage(params)
{
	sendOpenExternalPageMessage(params);
}


function handlePageTitle()
{
    Frames.Application.on('titlechanged', function()
    {
        updateTitle();
    });
}

function updateTitle()
{
    var title = Frames.Application.task.view.title();
    if (!Frames.isEmpty(title) && title != getExperienceProp('title'))
    {
        sendTitleMessage(title);
		setExperienceProp('title', title);
    }
}

function handleToolsMenu()
{
	// disable tools menu inside iframe
	Frames.Config.get('WORKSPACE_ACTIONS').remove('MENU_TOOLS');

    Frames.Application.on('verticalMenuRefresh', function(evt, vm)
    {
        if (_$('#menu-tools').is(vm.element))
        {
            var menuItems = vm.options.items;
            var menu = createToolsMenu(menuItems);
            sendMenuMessage(menu);
			setExperienceProp('toolsmenu', menu);
        }
    });
}

function createToolsMenu(items)
{
	// manual changes to the menu

	// move "Count Matched Documents" to "Actions" section
	var actionSection = items.find((item) => item.id == 'toolbar');
	var bdmSection = items.find((item) => item.id == 'tb-doc-man');
	if (!Frames.isUndef(actionSection) && 
		!Frames.isUndef(bdmSection) && 
		!Frames.isUndef(actionSection.items) && 
		!Frames.isUndef(bdmSection.items))
	{
		var countItem = bdmSection.items.find((item) => item.id == 'tb-count');
		if (!Frames.isUndef(countItem))
		{
			actionSection.items.push(countItem);
			bdmSection.items = bdmSection.items.filter(item => item != countItem);
		}
	}

	return buildToolsMenu(items);
}

function buildToolsMenu(items)
{
    var menu = [];
    for (var item of items)
    {
		// Skip blacklisted items/menus
		if (isToolsItemBlacklisted(item))
		{
			continue;
		}

        // this is a section, get submenu and add section
        if (Frames.isArray(item.items))
        {
            var submenu = buildToolsMenu(item.items);
            if (!Frames.isEmpty(submenu))
            {
                var sectionObj =
                {
					id: item.id,
                    variant: 'Header',
                    label: item.label
                };
                menu.push(sectionObj);
                menu.push(...submenu);
            }
        }
        else if (!Frames.isUndef(item.id) && item.enabled !== false)
        {
            var entryObj =
            {
                id: item.id,
                label: item.label,
                hintText: item.shortcut
            };
            menu.push(entryObj);
        }
    }
    return menu;
}

function isToolsItemBlacklisted(item)
{
	var blacklist = [
		'tb-about-banner',
		'tb-doc-man',
		'tb-retrieve',
		'tb-add-new',
		'theme'
	];
	return blacklist.indexOf(item.id) != -1;
}

function handleToolbar() {

	var toolbarTemplate = [
		{
			id: 'page-search',
			icon: 'search',
			label: _('SEARCH') + handleToolbarActionsShortcut('APPNAV_SEARCH'),
			ref: 'search'
		},
		{
			id: 'close-button',
			icon: 'arrow-left',
			label: _('BACK') + handleToolbarActionsShortcut('EXIT'),
			ref: 'close'
		},
		{
			id: 'mep-change',
			icon: 'institution',
			label: _('CHANGE_MEP') + handleToolbarActionsShortcut('VPDI_COMPONENT'),
			ref: 'change'
		},
		{
			id: 'bdm-add',
			icon: 'file-plus',
			label: _('ADD_BDM') + handleToolbarActionsShortcut('BDM_IMPORT_FILE'),
			ref: 'add'
		},
		{
			id: 'bdm-display',
			icon: 'file-import',
			label: _('DISPLAY_BDM') + handleToolbarActionsShortcut('BDM_RETRIEVE'),
			ref: 'display'
		},
		{
			id: 'related-toggle',
			icon: 'sitemap',
			label: _('RELATED') + handleToolbarWorkspaceShortcuts('MENU_RELATED'),
			ref: 'related'
		},
		{
			id: 'page-help',
			icon: 'help',
			label: _('PAGE_HELP') + handleToolbarActionsShortcut('APPNAV_HELP'),
			ref: 'help'
		}
	];

	setExperienceProp('toolbar', []);

    Frames.Application.on('headerButtonsRefresh', function(evt, data)
    {
		var toolbar = [];
		if (!Frames.isUndef(data)) {
			
			// when toolbar is active, these buttons are always visible
			data.close = true;
			data.help = true;
			data.search = true;

			for (var item of toolbarTemplate)
			{
				if (data[item.ref])
				{
					toolbar.push(item);
				}
			}
		}

		sendToolbarMessage(toolbar);
		setExperienceProp('toolbar', toolbar);
    });
}

function handleToolbarActionsShortcut(action) {
	var act = Frames.Config.getaction_name(action);
	if (!act)
	{
		return '';
	}

	var shortcut = act.accesskey;
	return ' (' + Frames.humanize_shortcut(shortcut) + ')';
}

function handleToolbarWorkspaceShortcuts(action) {
	var wrkspActions =  Frames.Config.get('WORKSPACE_ACTIONS');
	if (!wrkspActions)
	{
		return '';
	}

	var shortcut = wrkspActions.get(action);
	if (!shortcut)
	{
		return '';
	}

	return ' ('  + Frames.humanize_shortcut(shortcut) + ')'
}

function handleNotifications()
{
	var notificationButton = {
		id: 'notifications',
		icon: 'warning',
		label: 'Notifications',
		ref: 'notifications'
	};
	
	Frames.Application.on('notificationupdate', function(evt, data)
	{
		var toolbar = getExperienceProp('toolbar');
		var [last] = toolbar.slice(-1);

		// clean all notifications
		if (data.empty)
		{
			sendNotificationMessage([]);

			if (notificationButton == last)
			{
				toolbar.pop();
				sendToolbarMessage(toolbar);
				setExperienceProp('toolbar', toolbar);
			}
		}
		// showing alerts
		else if (!Frames.isEmpty(data.alerts))
		{
			var alerts = [];
			for (var alert of data.alerts)
			{
				var btns = [];
				for (var btn of alert.buttons)
				{
					var btnObj = {
						id: btn.id,
						label: btn.label
					};
					btns.push(btnObj);
				}

				// BART-1779 - reverse HTML encoding done in showAlert as we don't need it for Experience
				var message = _$.decodeHtml(alert.message.replace(/<br>/g, '\n'));
				var obj = {
					type: getMessageType(alert.type),
					message: message,
					prompts: btns,
					flash: false
				}
				alerts.push(obj);
				_$('#notifications').find(`li[data-uuid='${alert.id}']`).hide();
			}
			sendNotificationMessage(alerts);
			setExperienceProp('alerts', alerts);
		}
		// showing messages
		else if (notificationButton != last)
		{
			toolbar.push(notificationButton);
			sendToolbarMessage(toolbar);
			setExperienceProp('toolbar', toolbar);
		}
	});

	Frames.Application.on('notificationsInitComplete', function(evt, data) {
		_$('body').append(data.element);
	});
}

function handleClose()
{
	Frames.Application.on('taskclose', function(evt)
	{
		//if just one task is open, when clicking on the back button it should return to the dashboard page
		var tasks = _$.map(Frames.Application._TASKS_, function(o, k) { return k; });
		if (tasks.length == 1)
		{
			//wait for server response due to globals
			Frames.Application.one('viewready', function() {
				Frames.Application.exit();
				sendStatusMessage('dirty:false');
				sendDashboardMessage();
			});
		}
	});
}

function handleDirtyStateMessage()
{
	Frames.Application.on('viewready', function()
	{
		Frames.Application._hasDirtyTasks = false;
		_$.each(Frames.Application._TASKS_, function(k, task)
		{
			var hasChanges = Frames.isTrue(Frames.Model.attr(task.control, 'isChanged'));
			if (hasChanges)
			{
				sendStatusMessage('dirty:true');
				Frames.Application._hasDirtyTasks = true;
				return false;
			}
		});

		if (!Frames.Application._hasDirtyTasks)
		{
			sendStatusMessage('dirty:false');
		}
	});
}

function handleHelp() {

	M._PAGES_ = new Frames.HashMap();

	Frames.Application.on('viewready', function(ev, data)
	{
		// update current page
		var task = data.task;
		if (!Frames.isUndef(task) && task !== Frames.Application.getMainTask())
		{
			var name = task.name;

			if (Frames.isUndef(name))
			{
				_$.each(M._PAGES_.values(), function(i, v)
				{
					if (v.id === task.id)
					{
						name = v.name;
						return false;
					}
				});
			}

			if (!Frames.isUndef(name))
			{
				var p = M._PAGES_.get(name);

				if (Frames.isUndef(p))
				{
					M._PAGES_.put(name, {id: task.id, name: name});
				}

				// equivalent to window._appnav_page in AppNav
				setExperienceProp('currentHelpPage', name);
			}
		}
	});

}

function getMessageType(type)
{
	if (type == 'danger')
	{
		return 'error';
	}
	else
	{
		return type;
	}
}

function customMessage(type, value) {
	var messageObject = 
	{
		type : type,
		value : value
	};
	return utf8Encode(JSON.stringify(messageObject));
}

function sendStatusMessage(value) {
	M.send({
		type : 'status',
		status : value
	})
}

function sendMenuMessage(menu) {
	M.send(customMessage("toolsMenu", menu));
}

function sendToolbarMessage(toolbar) {
	M.send(customMessage("toolbar", toolbar));
}

function sendTitleMessage(title) {
	M.send(customMessage("title", title));
}

function sendNotificationMessage(notification) {
	M.send(customMessage("notification", notification));
}

function sendIframeHeightMessage() {
	M.send(customMessage("iframeHeight", '100%'));
}

function sendPageCloseCleanupCompleteMessage() {
	M.send(customMessage("pageCloseCleanupComplete"));
}

function sendSetupCloseMessage() {
	M.send(customMessage("setupClose"));
}

function sendHelpMessage(url) {
	M.send(customMessage("help", url));
}

function sendOpenExternalPageMessage(params) {
	M.send(customMessage("openExternalPage", params));
}

function sendPathNameMessage(path) {
	M.send(customMessage("pathName", {
		href: path,
		app: 'BannerAdmin'
	}));
}

function experienceMessageHandler(message)
{
	console.log(message);

    // Process Actions
    if (message.type == 'request' && message.request == 'action')
	{
		// Process Tools Menu Actions
		if (message.action == 'executeOptionMenuItem')
		{
			_$('#menu-tools').find(`a[data-uuid='${message.value.id}']`).trigger('click');
		}

		// Process Toolbar Actions
		if (message.action == 'clickToolbarButton')
		{
			var btnId = message.value.id;
			if (btnId == 'page-help')
			{
				showHelpPage();
			}
			else
			{
				_$(`#${btnId} > a`).trigger('click');
			}
		}

		if (message.action == 'executeNotificationPromptAction')
		{
			var alert = message.value.notification;
			var optLabel = message.value.label;
			for (var btn of alert.prompts)
			{
				if (btn.label == optLabel)
				{
					_$(`#${btn.id}`).trigger('click');
					sendNotificationMessage([]);
					break;
				}
			}
		}

		if (message.action == 'globalVariables')
		{
			var values = message.value.globals;
			if(!Frames.isEmpty(values))
			{
				var sync = {
					name: 'SYNC_GLOBALS',
					params: [
					{
						name: 'LIST_GLOBALS',
						value: Frames.Model.encode(values, true),
						type: 'String'
					}]
				};

				Frames.Application.execute(sync, undefined, undefined, undefined, undefined, false);
			}
			else
			{
				Frames.Application.execute('UNLOCK_GLOBALS');
			}
		}

		if (message.action == 'pageCloseCleanup')
		{
			Frames.Application.exit();
			var logoutUrl = Frames.Config.get('SESSION_LOCAL_LOGOUT_URL');
			if (!Frames.isEmpty(logoutUrl))
			{
				$.ajax({
					type: 'GET',
					url: logoutUrl
				});
			}
			sendPageCloseCleanupCompleteMessage();
		}
	}
	else if (message.type == 'keepAlive')
	{
		if (message.keepAlive === true)
		{
			handleKeepAlive();
		}
	}
	// Process Navigation Messages from Experience
	else if (message.type == 'navigate')
	{
		// Handle navigation item under message.appContext
		handleExperienceNavigation(message.appContext);
	}
    // Change focus from Experience to Admin
    else if (message.type == 'focus')
    {
        Frames.focus();
    }
}

// Handle navigation messages
function handleExperienceNavigation(navItem)
{
	// Pass navItem to the server and determine which page to load dynamically.
	// The navItem.page property contains the page name to match.
	var json = {
		type: 'navigate',
		page: navItem.page,
		values: '{}',
		parameters: '{}'
	};
	Frames.Workspace.handleEvent('navigate', M.json.stringify(json), json);
}

// same encoding function as used in SSB: https://jirateams.ellucian.com/browse/NP-320
function utf8Encode(inputString) {
	inputString = inputString.replace(/\r\n/g, "\n");
	var utftext = "";

	for (var n = 0; n < inputString.length; n++) {

		var c = inputString.charCodeAt(n);

		if (c < 128) {
			utftext += String.fromCharCode(c);
		} else if ((c > 127) && (c < 2048)) {
			utftext += String.fromCharCode((c >> 6) | 192);
			utftext += String.fromCharCode((c & 63) | 128);
		} else {
			utftext += String.fromCharCode((c >> 12) | 224);
			utftext += String.fromCharCode(((c >> 6) & 63) | 128);
			utftext += String.fromCharCode((c & 63) | 128);
		}
	}
	return utftext;
}

//# sourceURL=app/flat/js/experience.js