{
var appsroot = Frames.Config.get('APPS_ROOT', '.');

var VIEWS_MAP = {
	'morphis/frames/workspace/ViewWorkspaceWindow': true,
	'morphis/frames/workspace/ViewLoginSimple': true,
	'morphis/frames/workspace/EditDialog': true,
	'morphis/frames/workspace/EditorDialog': true,
	'morphis/frames/workspace/LOVDialog': true,
	'morphis/frames/workspace/LOVDropdown': true
};

var _mapView = Frames.View.mapView;
Frames.View.mapView = function(viewId)
{
	var id = Frames.View.getViewId ? Frames.View.getViewId(viewId) : viewId;
	return (VIEWS_MAP[id]) ? appsroot + '/base/views/' + Frames.View.mapViewId(viewId) : _mapView.apply(Frames.View, [viewId]);
};

Frames.Dialog.show = function(title, message, icon, btns)
{
	Frames.Workspace.showMessage(message, icon == 'MESSAGE' ? 'success': icon);
};

var _message = Frames.StatusBar.message;
Frames.StatusBar.message = function(msg)
{
	if (!Frames.isEmpty(msg) && Frames.isFunction(Frames.Workspace.closeMessage))
	{
		Frames.Workspace.closeMessage();
	}
	_message.apply(Frames.StatusBar, [msg]);
};

var _viewPreReady = Frames.Application._viewPreReady;
Frames.Application._viewPreReady = function()
{
	if (Frames.Workspace._disableViewPreReady)
	{
		return;
	}
	_viewPreReady.apply(Frames.Application, arguments);
};

};

//# sourceURL=app/base/js/app.js
