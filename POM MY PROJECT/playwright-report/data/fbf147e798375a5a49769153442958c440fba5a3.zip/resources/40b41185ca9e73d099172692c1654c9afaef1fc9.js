
_$.extend(Frames.Workspace,
{
	_OBJS_: {},

	VALID_ICONS: ['information', 'success', 'normal', 'warning', 'error'],

	CONFIG: {},

	HEADER_CONFIG: {
		close: {
			icon: 'ba ba-close'
		},
		items: {
			left: null,
			right: [
				{id: 'workflowbar', class: 'workflowbar-item'},
				{id: 'mep-change', action: 'VPDI_COMPONENT', visible: false,
					icon: 'ba ba-mep-change', label: _('CHANGE'), tooltip: _('CHANGE_MEP')},
				{id: 'bdm-add', action: 'BDM_IMPORT_FILE', icon: 'ba ba-bdm-add', label: _('ADD'), tooltip: _('ADD_BDM')},
				{id: 'bdm-display', action: 'BDM_RETRIEVE', icon: 'ba ba-bdm-display', label: _('DISPLAY'), tooltip: _('DISPLAY_BDM')},
				{id: 'related-toggle', target: 'menu-related', icon: 'ba ba-related', label: _('RELATED')},
				{id: 'related-tools', target: 'menu-tools', icon: 'ba ba-tools', label: _('TOOLS')},
				{id: 'notifications', class: 'notification-item'}
			]
		}
	},

	FOOTER_CONFIG: {
		toolbar: true,
		items: {
			left: [
				{id: 'prev-record-bt', class: 'button-action', action: 'PREVIOUS_BLOCK', icon: 'ba ba-prev-section', tooltip: _('GO_TO_PREVIOUS_SECTION'), hidden: true},
				{id: 'next-record-bt', class: 'button-action', action: 'NEXT_BLOCK', icon: 'ba ba-next-section', tooltip: _('GO_TO_NEXT_SECTION'), hidden: true},
				{id: 'activity'},
			],
			right: [
				{id: 'cancel-bt', class: 'button-action', action: 'EXIT', label: _('CANCEL'), hidden: true},
				{id: 'select-bt', class: 'button-action', action: 'WHEN-MOUSE-DOUBLECLICK', label: _('SELECT'), hidden: true},
				{id: 'save-bt', class: 'button-action', action: 'SAVE', label: _('SAVE'), tooltip: _('GO_TO_SAVE'), hidden: true}
			],
			bottom: [
			    {class: 'col-md-3 ui-statusbar', label: _('COPYRIGHT')}
			]

		}
	},

	DEFAULT_TOOLS: [
		{ id: 'toolbar', type: 'section', label: _('ACTIONS'), items: [
			{ id: 'tb-rollback', action: 'CLEAR-FORM', label: _('REFRESH')},
			{ id: 'tb-export', action: 'EXPORT', label: _('EXPORT')},
			{ id: 'tb-screenshot', action: 'SCREENSHOT', label: _('SCREENSHOT')},
			{ id: 'tb-record-clear', action: 'CLEAR_RECORD', label: _('CLEAR_RECORD') },
			{ id: 'tb-block-clear', action: 'CLEAR_BLOCK', label: _('CLEAR_BLOCK') },
			{ id: 'tb-item-props', action: 'ITEM_PROPERTIES', label: _('ITEM_PROPERTIES') },
			{ id: 'tb-user-id', action: 'DISPLAY_ID_IMAGE', label: _('DISPLAY_ID_IMAGE') },
			{ id: 'tb-exit-qflow', action: 'EXIT_QUICKFLOW', label: _('EXIT_QUICKFLOW') },
			{ id: 'tb-about-banner', action: 'ABOUT_BANNER', label: _('ABOUT_BANNER') },
		]},

		{ id: 'options', type: 'section', label: _('OPTIONS'), items: []},

		{ id: 'tb-doc-man', type: 'section', label: _('BANNER_DOC_MAN'), items: [
			{ id: 'tb-retrieve', action: 'BDM_RETRIEVE', label: _('RETRIEVE_DOCUMENTS') },
			{ id: 'tb-count', action: 'BDM_COUNT', label: _('COUNT_MATCHED_DOCUMENTS') },
			{ id: 'tb-add-new', label: _('ADD_NEW_DOC_PAGE'), items: [
				{ id: 'tb-scan', action: 'BDM_SCAN', label: _('SCAN') },
				{ id: 'tb-b-paste', action: 'BDM_PASTE', label: _('CLIPBOARD_PASTE') },
				{ id: 'tb-cb-paste-special', action: 'BDM_PASTE_SPECIAL', label: _('CLIPBOARD_PASTE_SPECIAL') },
				{ id: 'tb-insert-objs', action: 'BDM_INSERT_OBJS', label: _('INSERT_OBJECTS') },
				{ id: 'tb-import-file', action: 'BDM_IMPORT_FILE', label: _('IMPORT_FILE') },
				{ id: 'tb-faxin', action: 'BDM_FAXIN', label: _('FAXIN_QUEUE') }
			]}
		]},
		{ id: 'theme', type: 'section', label: _('THEME_SWITCHER'), items: [
			{ widget: 'themeswitcher'}
		]},
		{ id: 'page-settings', type: 'section', label: _('PAGE_SETTINGS'), items: [
			{ id: 'tb-disable-settings', action: 'DISABLE_SETTINGS', label: _('DISABLE_SETTINGS') },
			{ id: 'tb-restore-settings', action: 'RESTORE_GLOBAL_SETTINGS', label: _('RESTORE_DEFAULT_SETTINGS') }
		]},
		{ id: 'tb-doc-banner1', type: 'section', label: _('IMAGE_INTEGRATION'), items: [
			{ id: 'tb-doc-banner2', action: 'IMAGE_INTEGRATION', label: _('IMAGE_INTEGRATION') }
		]}
	],

	initialize: function()
	{
		var that = this;
		Frames.Application.registerActionHandler('AppNavAction', Frames.Workspace.handleAction);

		if (typeof M !== 'undefined' && !Frames.isUndef(M) && M._DEBUG_)
		{
			Frames.Workspace.CONFIG.welcome = true;
			if (!Frames.Config.getbool('DISABLE_FORMS_MENU', false))
			{
				Frames.Workspace.HEADER_CONFIG.items.left = [
					{id: 'menu-toggle', class: 'workspace-menu-toggle', target: 'menu', shortcut: 'alt+ctrl+m', icon: 'fa fa-bars'}
				];
			}
		}

		var imageEnabled = Frames.Config.getbool('IMAGE_ENABLED', false);
		if (!imageEnabled )
		{
			Frames.Workspace.DEFAULT_TOOLS = Frames.Workspace.DEFAULT_TOOLS.filter(item => item.id != 'tb-doc-banner1');
		}

		var themeEnabled = Frames.Config.getbool('THEME_ENABLED', true);
		if (!themeEnabled)
		{
			Frames.Workspace.DEFAULT_TOOLS = Frames.Workspace.DEFAULT_TOOLS.filter(item => item.id != 'theme');
		}

		var wrksp_actions = Frames.Config.get('WORKSPACE_ACTIONS');
		if (!Frames.isUndef(wrksp_actions))
		{
			Frames.Workspace.HEADER_CONFIG.items.right.filter(opt => opt.id == 'related-toggle')[0].shortcut = wrksp_actions.get('MENU_RELATED');
			Frames.Workspace.HEADER_CONFIG.items.right.filter(opt => opt.id == 'related-tools')[0].shortcut = wrksp_actions.get('MENU_TOOLS');
		}

		Frames.Workspace.HEADER_CONFIG.items.right[0].content = '' +
			'<button id="wfReleaseBtn" class="btn" data-action="WF_RELEASE" title="' + _('RELEASE') + '">' + _('RELEASE') + '</button>' +
			'<button id="wfSubmitBtn" class="btn" data-action="WF_SUBMIT" title="' + _('SUBMIT') + '">' + _('SUBMIT') + '</button>';

		Frames.Workspace.FOOTER_CONFIG.items.left[2].content = '' +
			'<div id="activitydate" data-widget="footerlabel" data-type="Date" data-format="' + Frames.Locale.formats.DATE_FORMAT + ' ' + Frames.Locale.formats.TIME_FORMAT + '" data-block="BANNER_FOOTER_DATA" data-member="ACTIVITY_DATE">' +
			'<label>' + _('ACTIVITY_DATE') + '</label><span></span></div>' +
			'<div id="activityuser" data-widget="footerlabel" data-block="BANNER_FOOTER_DATA" data-member="USER_ID"><label>' + _('ACTIVITY_USER') + '</label><span></span></div>';

		Frames.Application.on('viewready', function(ev, result)
		{
			var view = result.view;
			if (view && view.id.indexOf('Workspace') != -1)
			{
				if (!Frames.Workspace._initialized)
				{
					// Register workflow events
					_$('#workflowbar button[data-action]').on('click', function()
					{
						var el = _$(this);
						var action = el.data('action');
						Frames.Application.valexec(action);
					});

					// initialize activity widgets in the footer
					Frames.Application.mainTask.blocks({
						BANNER_FOOTER_DATA: {}
					});
					Frames.get('activitydate');
					Frames.get('activityuser');
					Frames.get('wfReleaseBtn');
					Frames.get('wfSubmitBtn');

					Frames.MenuItem.create('select-bt', 'MENU_CONTROL', 'SELECT_BT').visible(false);
					Frames.MenuItem.create('cancel-bt', 'MENU_CONTROL', 'CANCEL_BT').visible(false);
					Frames.MenuItem.create('save-bt', 'MENU_CONTROL', 'SAVE_BT').visible(false);

					Frames.Workspace._parseUrl();
					Frames.Workspace._initialized = true;

					var $header = _$('.workspace-header');

					_$('#menu-related').verticalmenu('enabled', false);
					_$('#menu-tools').verticalmenu('enabled', false);

					_$.workspace.verticalmenu.itemenabled(_$('#bdm-add', $header), false);
					_$.workspace.verticalmenu.itemenabled(_$('#bdm-display', $header), false);
					_$.workspace.verticalmenu.itemvisible(_$('#mep-change', $header), false);

					Frames.Application.trigger('headerButtonsRefresh');

					return;
				}
				else
				{
					// hide footer buttons
					_$('.workspace-footer .navbar-buttons [data-widget]').each(function()
					{
						var item = Frames.get(_$(this)[0].id);
						if (!Frames.isUndef(item))
						{
							item.props('Visible', false);
						}
					});
				}
			}

			that.initPageSettingsOptions();
		});

		Frames.Application.on('taskclose', function(ev, result)
		{
			var tasks = _$.map(Frames.Application._TASKS_, function(o, k) { return k; });
			if (tasks.length == 1)
			{
				_$('#menu-related').verticalmenu('enabled', false);
				_$('#menu-tools').verticalmenu('enabled', false);
				var $header = _$('.workspace-header');
				_$.workspace.verticalmenu.itemenabled(_$('#bdm-add', $header), false);
				_$.workspace.verticalmenu.itemenabled(_$('#bdm-display', $header), false);
				_$.workspace.verticalmenu.itemvisible(_$('#mep-change', $header), false);

				Frames.Application.trigger('headerButtonsRefresh');
			}
		});

		var roles = Frames.Config.get('ROLES_MAP');
		if (!Frames.isUndef(roles) && Frames.isTrue(roles.get('APPLICATION')))
		{
			_$('body').attr('role', 'application');
		}

		var mepCode = Frames.Workspace._getUrlVars().vpdi_code;
		mepCode && Frames.Workspace.changeMep( mepCode );
	},

	_getUrlVars: function(url)
	{
		return Frames.getqs(url);
	},

	_parseUrl: function(url)
	{
		var QS = Frames.Workspace._getUrlVars(url);
		if (QS.form)
		{
			var params = [];
			_$.each(QS, function(k, v)
			{
				if (k != 'debug' && k != 'form')
				{
					params.push({ name: k, value: v	});
				}
			});
			Frames.Workspace.callformByName(QS.form, params);
		}
		else if (QS.wfargs || QS.wf_args)
		{
			// don't escape all chars for now
			/*
			this needs a new version of Frames so comment out and wait for next release
			var args = $.escapeHtml(QS.wfargs || QS.wf_args, {
				"&": "&amp;",
				"<": "<",
				">": ">",
				'"': '"',
				"'": "'",
				"/": '/'
			});*/
			var args = (QS.wfargs || QS.wf_args).replace('&', '&amp');
			Frames.Workspace.processWorkflow(args);
		}
	},


	changeMep: function(mepValue)
	{
		var newMepCode = mepValue;
		var lastMepCode = Frames.Config.get('MEP_CODE');
		var ext_css = Frames.Config.get('APP_CSS_URL');

		if (newMepCode != lastMepCode && !Frames.isUndef(ext_css))
		{
			var lastMepUrl = ext_css.replace('$mepcode', lastMepCode);

			Frames.Config.set('MEP_CODE', newMepCode);
			ext_css = ext_css.replace('$mepcode', newMepCode);

			var url = ext_css;
			if(!Frames.isUndef(lastMepCode))
			{
				_$('link[href="' + lastMepUrl + '"]', _$('head')).attr('href', url);
			}
			else
			{
				Frames.loadcss(ext_css);
			}
		}
	},

	get: function(key)
	{
		var el = Frames.Workspace._OBJS_[key];
		return el ? el : _$();
	},

	handleEvent: function(type, jsonString, json)
	{
		if (jsonString)
		{
			jsonString = Frames.Model.encode(jsonString, true);
		}
		Frames.Application.execute({
			name: 'FORM_EVENT',
			params: [
				{name: 'name', value: type, type: 'String'},
				{name: 'value', value: jsonString, type: 'String'}
			]
		});
	},

	processWorkflow: function(args)
	{
		if (Frames.isUndef(args))
		{
			args = '';
		}

		Frames.Application.execute({
			name: 'EXEC_WORKFLOW',
			params: [
				{name: 'args', value: args, type: 'string'}
			]
		},
		undefined, undefined, undefined, undefined, false);
	},

	handleAction: function(action)
	{
		switch (action.name)
		{
			case 'APPNAV_MENU':
				sendMainMenuMessage();
				break;
			case 'APPNAV_ITEMS':
				sendItemsMenuMessage();
				break;
			case 'APPNAV_SEARCH':
				sendSearchMessage();
				break;
			case 'APPNAV_HELP':
				showHelpPage();
				break;
			case 'APPNAV_SIGNOUT':
				sendSignoutMessage();
				break;
			case 'APPNAV_DASHBOARD':
				sendDashboardMessage();
				break;
			default:
				break;
		}
	},

	handleCommand: function(task, name, data)
	{
		switch (name)
		{
	 		case 'TERMS_NOT_ACCEPTED':
            createLastPageClosedMessage();
            break;
		
			case 'XE':
				try
				{
					var command = Frames.Model.value(data.param[0]);
					/* jshint evil:true */
					eval(command);
					/* jshint evil:false */
				}
				catch (e)
				{}
				break;

			case 'SEND_GLOBALS':
				var text = Frames.Model.value(data.param[0]);
				if (text.indexOf('\n') > -1)
				{
					text = text.replace('\n','\\n');
				}
				sendGlobals(JSON.parse(text));
				break;

			case 'WORKFLOW' :
				var show = Frames.findTxt(data, 'param', 'show');
				var wfId = Frames.findTxt(data, 'param', 'id');
				var reuse = Frames.findTxt(data, 'param', 'reuse');

				if (Frames.isTrue(show))
				{
					Frames.Workspace.showWorkflow(wfId);
				}
				else if (!Frames.isUndef(reuse))
				{
					if (Frames.isTrue(reuse))
					{
						Frames.Workspace.waitForWorkflow();
					}
					else
					{
						Frames.Workspace.stopWaitForWorkflow();
					}
				}
				else
				{
					Frames.Workspace.closeWorkflow();
				}
				break;

			case 'MENU_BIND':
				var menu = Frames.findTxt(data, 'param', 'MENU');
				var block = Frames.findTxt(data, 'param', 'BLOCK');
				var member = Frames.findTxt(data, 'param', 'MEMBER');
				var taskId = Frames.findTxt(data, 'param', 'task');

				if (Frames.Application.task.id !== taskId)
				{
					break;
				}

				var body = task.data;

				var bdata = Frames.find(body, 'block', block);

				var related = [];
				var options = [];
				var tools = Frames.Workspace.DEFAULT_TOOLS.slice(0);

				if (bdata && bdata[0].record)
				{
					var xml = Frames.find(bdata[0].record[0], 'item', member);

					if (xml && xml[0].menu && xml[0].menu[0].entry)
					{

						_$.each(xml[0].menu[0].entry, function(k, v)
						{
							var label = Frames.Model.attr(v, 'label');
							var action =  Frames.Model.attr(v, 'action') || '';
							var id =  Frames.Model.attr(v, 'id');

							var type = Frames.find(v, 'parameter', 'GUROPTM_TYPE_IND');
							if (type)
							{
								type =  Frames.Model.attr(type[0],'value');
							}

							var enabled =  Frames.Model.attr(v, 'enabled');
							enabled = enabled === undefined ? true : Frames.isTrue(enabled);

							var visible =  Frames.Model.attr(v, 'visible');
							visible = visible === undefined ? true : Frames.isTrue(visible);

							if (visible)
							{
								var item = {
									id: id,
									label: label,
									enabled: enabled,
									name: menu,
									item: member,
									action: action,
									option: true
								};

								if (type == 'L' || type == 'F')
								{
									related.push(item);
								}
								else
								{
									options.push(item);
								}
							}
						});
					}

					tools[1].items = options;
				}

				var ext = {add: false, display: false, change: false};
				Frames.Workspace._applyControlInfo(tools, ext);

				ext.related = (related.length > 0);

				var $related = _$('#menu-related');
				$related.verticalmenu('option', 'items', related);
				$related.verticalmenu('option', 'click', Frames.Workspace._handleMenuClick);
				$related.verticalmenu('enabled', ext.related);

				var $tools = _$('#menu-tools');
				$tools.verticalmenu('option', 'items', tools);
				$tools.verticalmenu('enabled', true);
				this.initPageSettingsOptions();

				var $header = _$('.workspace-header');
				_$.workspace.verticalmenu.itemenabled(_$('#bdm-add', $header), ext.add);
				_$.workspace.verticalmenu.itemenabled(_$('#bdm-display', $header), ext.display);
				_$.workspace.verticalmenu.itemvisible(_$('#mep-change',$header), ext.change);

				Frames.Application.trigger('headerButtonsRefresh', ext);

				Frames.Application.one('opentask', function(ev)
				{
					//Set MENU_CONTROL EnabledActions and CheckedActions properties to the default value when opening a task
					var block = Frames.Application.mainTask.get('MENU_CONTROL');
					if (!Frames.isUndef(block))
					{
						block.props('EnabledActions', '');
						block.props('CheckedActions', '');
						//This property is not being used
						//block.props('VisibleActions', '');
					}
				});

				break;

			case 'SESSION_END':
				break;

			case 'DEFERRED_POPUP':
				Frames.Application.execute('DEFERRED_POPUP_OPEN');
				break;
			case 'MEP_CHANGE':
				var mepValue = Frames.Model.value(data.param[0]);
				Frames.Workspace.changeMep(mepValue);
				break;
			case 'PRINT':
				// make sure the menu doesn't show on preview
				_$('.workspace-menu').verticalmenu('close');
				window.print();
				break;
			case 'ACCESSIBILITY':
				var value = Frames.findTxt(data, 'param', 'value');
				if (Frames.isTrue(value))
				{
					Frames.Navigation.mode('all');
				}
				else
				{
					Frames.Navigation.mode('default');
				}
				break;
			case 'GLOBALS':
				if (M._DEBUG_)
				{
					Frames.Application.execute('UNLOCK_GLOBALS');
				}
				else
				{
					if (integrationMode == 'EXPERIENCE')
					{
						M.send(customMessage('globals'));
					}
					else
					{
						M.send(M.createRequestMessage('globalVariables'));
						M._unlockGlobals = setTimeout(function ()
						{
							Frames.Application.execute('UNLOCK_GLOBALS');
						}, M._globalsTimeout);
					}
				}
				break;
			case 'AJAX':
				var url = Frames.findTxt(data, 'param', 'URL');
				var content = Frames.findTxt(data, 'param', 'DATA') || '{}';

			  	//This converts the key value=pair separated by & to json objects
				var output = content.split('&').reduce(function(o,pair)
				{
					pair = pair.split('=');
					return o[pair[0]] = pair[1], o;
				}, {});

				//This creates the form and posts the parameters to url.
				content = output;
				var form = document.createElement("form");
				form.setAttribute("method", "post");
				form.setAttribute("action", url);
				form.setAttribute("target", "_blank");

				for (var i in content)
				{
					if (content.hasOwnProperty(i))
					{
						var input = document.createElement('input');
						input.type = 'hidden';
						input.name = i;
						input.value = content[i];
						form.appendChild(input);
					}
				}

				document.body.appendChild(form);
				form.submit();
				document.body.removeChild(form);

				break;
				
			case 'SYNC_EXPORT':
				if (!Frames.LongExport)
				{
					Frames.LongExport = { continue:true };
				}
				if(!Frames.waitBackup)
				{
					Frames.waitBackup = Frames.wait;
					Frames.wait = _$.noop;
				}
				if (Frames.isTrue(Frames.LongExport.continue))
				{
					Frames.Application.execute('SYNC_EXPORT_RESPONSE');
				}
				else
				{
					Frames.wait = Frames.waitBackup;
					Frames.waitBackup = null;
					Frames.Application.execute('SYNC_CANCEL_EXPORT_RESPONSE');
					Frames.LongExport.continue = true;
				}
				break;
			case 'END_EXPORT':
				if(Frames.waitBackup != null) 
				{
					Frames.wait = Frames.waitBackup;
					Frames.waitBackup = null;
					Frames.LongExport.continue = true;
				}
				Frames.Application.execute('SYNC_EXPORT_RESPONSE');
				break;
			case 'OPEN_EXTERNAL_PAGE':
				var appCodeParam = Frames.findTxt(data, 'param', 'appCode');
				var dataParam = Frames.findTxt(data, 'param', 'data');
				var titleParam = Frames.findTxt(data, 'param', 'title');
				Frames.Application.trigger('openExternalPage', {appCode: appCodeParam, title: titleParam, data: dataParam});
				break;
			case 'TOGGLE_VIEW':
				var block = Frames.Application.task._BLOCKS_.get(Frames.findTxt(data, 'param', 'BLOCK')) || Frames.Application.task.block;
				var bindable = block.item.bindable();
				if (bindable)
				{
					var colapse = bindable.elem.parentsUntil('.ui-accordion, .ui-collapsiblepanel').last();
					if (colapse)
					{
						var $toolbar = colapse.prev();
						var toolbar = $toolbar.data('workspace-paneltoolbar');
						if (toolbar)
						{
							toolbar._openEditPanel(true);
						}
					}
				}
				break;
			case 'INIT_INITIUM':
				if (!Frames.isInitiumInitialized)
				{
					var appId = Frames.findTxt(data, 'param', 'appId');
					if (appId)
					{
						var url = "https://ia.initiumsoftware.com/app/" + appId + ".js";
						$.getScript(url)
						.done(function( script, textStatus ) {
							Frames.isInitiumInitialized = true;
							if (DEVMODE)
							{
								console.log("instant address has been loaded");
							}
						  })
						  .fail(function( jqxhr, settings, exception ) {
							if (DEVMODE)
							{
								console.log("instant address failed to load");
							}
						});
					}
				}
				break;
			default:
				break;
		}
	},

	initPageSettingsOptions: function()
	{
		var disableSettingsOption = _$('#menu-tools').find('[data-action="DISABLE_SETTINGS"]')
		if (disableSettingsOption.length > 0)
		{
			if (Frames.Application.task.isUpaInstitution() && Frames.Application.task.isMaster())
			{
				disableSettingsOption.show();
				disableSettingsOption.addClass('ui-tb-option-selectable');
				if (Frames.Application.task.hasPageSettings())
				{
					disableSettingsOption.removeClass('tb-active-option');
				}
				else
				{
					disableSettingsOption.addClass('tb-active-option');
				}
			}
			else
			{
				disableSettingsOption.hide();
			}
		}

		var restoreSettingsOption = _$('#menu-tools').find('[data-action="RESTORE_GLOBAL_SETTINGS"]')
		if (restoreSettingsOption.length > 0)
		{
			if (Frames.Application.task.isUpaInstitution() && Frames.Application.task.hasPageSettings())
			{
				restoreSettingsOption.show();
			}
			else
			{
				restoreSettingsOption.hide();
			}
		}

		var pageSettingsSeparator = restoreSettingsOption.parent().prevAll('li[role="separator"]').eq(0);
		if (disableSettingsOption.is(':visible') || restoreSettingsOption.is(':visible'))
		{
			pageSettingsSeparator.show();
		}
		else
		{
			pageSettingsSeparator.hide();
		}
	},

	fireTimerExpired: function(timerName)
	{
		var payload = {
			name: 'CLIENT-TIMER-EXPIRED',
			params: [
			{
				name: 'timerName',
				value: timerName,
				type: 'String'
			}]
		};
		if (Frames.Application.executing())
		{
			Frames.Application.one('viewready', function(ev, result)
			{
				Frames.Application.execute(payload, null, null, null, null, false);
			});
		}
		else
		{
			Frames.Application.execute(payload, null, null, null, null, false);
		}

	},

	_applyControlInfo: function(tools, ext)
	{
		var block = Frames.Application.mainTask.get('MENU_CONTROL');
		var enabled = (block.props('EnabledActions') || '').split(',');
		var selected = (block.props('CheckedActions') || '').split(',');

		_$.each(enabled, function(i, action)
		{
			// HACK for BDM ADD and BDM DISPLAY icons
			if (action == 'BDM_RETRIEVE')
			{
				ext.display = true;
			}
			else if (
				action == 'BDM_SCAN' || action == 'BDM_PASTE' || action == 'BDM_PASTE_SPECIAL' ||
				action == 'BDM_INSERT_OBJS' || action == 'BDM_IMPORT_FILE' || action == 'BDM_FAXIN')
			{
				if (ext.add !== true)
				{
					ext.add = true;
				}
			}
			else if (action == 'ICONS.VPDI_EXISTS')
			{
				ext.change = true;
			}
		});

		Frames.Workspace._applyControlInfoMenu(tools[2].items, enabled, selected);
	},

	_applyControlInfoMenu: function(arr, enabled, selected)
	{
		_$.each(arr, function(i, o)
		{
			if (Frames.isArray(o.items))
			{
				Frames.Workspace._applyControlInfoMenu(o.items, enabled, selected);
			}
			else
			{
				if (o.enabled === undefined || o.enabled === false)
				{
					o.enabled = _$.inArray(o.action, enabled) !== -1;
				}
				o.seleced = _$.inArray(o.action, selected) !== -1;
			}
		});
	},

	logoff: function()
	{
		// TODO: implement logout
	},

	// *** Utility methods ***
	getEnvironmentTask: function()
	{
		var taskId;
		if (window.sessionStorage)
		{
			try
			{
				taskId = window.sessionStorage.getItem('FRAMES_TASK_ID');
			}
			catch (e)
			{}

			if (Frames.isUndef(taskId) && !Frames.isUndef(Frames.Application.task))
			{
				taskId = Frames.Application.task.id;
			}
		}
		return taskId;
	},

	// *** Workflow methods ***

	showWorkflow: function(id)
	{
		_$('.workspace-header').addClass('workflow-mode');
		// TODO: set the worflow id
	},

	closeWorkflow: function()
	{
		_$('.workspace-header').removeClass('workflow-mode');
	},

	waitForWorkflow: function()
	{
		this.startPolling(null, function() { Frames.Workspace.processWorkflow(); });
	},

	stopWaitForWorkflow: function()
	{
		this.stopPolling();
	},

	startPolling: function(data, callback)
	{
		var that = this;

		if (data !== null && typeof(data) == 'object')
		{
			if (data.stop)
			{
				return;
			}

			if (data.response)
			{
				callback();
				return;
			}
		}

		var surl = Frames.Service.SERVICE_URL;
		var parts = surl.substring(0, surl.length - 1).split('/');
		parts.pop(); parts.pop();
		surl = parts.join('/');

		var taskId = Frames.Workspace.getEnvironmentTask();
		var wfCheckUrl = surl + '/workflow/check?taskId=' + taskId + "&t=" + (new Date()).getTime()

		_$.ajax ({
			url: wfCheckUrl,
			method: 'GET',
			success: function(dt) {
				that.startPolling(dt, callback);
			}
		});
	},

	stopPolling: function() {

		var surl = Frames.Service.SERVICE_URL;
		var taskId = Frames.Workspace.getEnvironmentTask();
		var wfCheckUrl = surl.substring(0, surl.indexOf('/services')) + '/workflow/stop?taskId=' + taskId;

		_$.ajax ({
			url: wfCheckUrl,
			method: 'GET'
		});
	}

});

Frames.Application.registerActionHandler('CustomAction', function(action)
{
	if (action.name == 'PRINT')
	{
		Frames.Workspace.print();
	}
	else if (action.name == 'SCREENSHOT')
	{
		Frames.Workspace.printScreenShot();
	}
	else if (action.name == 'SCALE')
	{
		Frames.Workspace.printScale();
	}
	else if (action.name == 'FAVORITES')
	{
		M.send(M.createActionMessage('favorites'));
	}
});

Frames.Application.registerActionHandler('DisableSettingsAction', function(action)
{
	Frames.Application.execute({
		name: action.name,
		params: [
			{name: 'master', type: 'boolean', value: true},
			{name: 'disable', type: 'boolean', value: Frames.Application.task.hasPageSettings()}
		]
	});
});

//# sourceURL=app/flat/js/workspace.js
