{
	// the widget definition, where 'workspace' is the namespace,
	// 'verticalmenu' the widget name
	_$.widget('workspace.verticalmenu',
	{

		// default options
		options: {
			type: 'vertical', // vertical | horizontal
			template_main: '/base/widgets/verticalmenu/html/verticalmenu.tmpl.html',
			template_item: '/base/widgets/verticalmenu/html/verticalmenu.tmpl.html',
			container: document.body,
			items: []
		},

		// the constructor
		_create: function()
		{
			var that = this;

			this._isRTL = this.element.css('direction') === 'rtl';

			var appsroot = Frames.Config.get('APPS_ROOT', '.');
			this.templates = {};
			Frames.Template.get(appsroot + this.options.template_main + '#' + this.options.type + 'menu-template', function(result)
			{
				that.templates.main = result;
				if (!Frames.isUndef(that.templates.item))
				{
					that._afterTemplate();
				}
			});
			Frames.Template.get(appsroot + this.options.template_item + '#' + this.options.type + 'menu-item-template', function(result)
			{
				that.templates.item = result;
				if (!Frames.isUndef(that.templates.main))
				{
					that._afterTemplate();
				}
			});
		},

		_afterTemplate: function()
		{
			var that = this;

			var id = this.element.attr('id');
			if (id)
			{
				this.$toggle = _$('[data-target="#' + id + '"]');

				this.$toggle.on('click.menu', function()
				{
					that.toogle();
					return false;
				});

				var hotkey = this.$toggle.data('shortcut');
				if (hotkey)
				{
					Frames.Config.regaccesskey(hotkey);
					_$(document).bind('keyup', this._convertkey(hotkey), function()
					{
						that.toogle();
					});
				}
			}

			_$(this.options.container).addClass('workspace-' + this.options.type + '-menu');

			_$.workspace.verticalmenu._instances.push(this);
			this._uuid = _$.workspace.verticalmenu._instances.length;

			this._refresh();

			this._closehandler = function()
			{
				_$('.open', that.element).removeClass('open');
			};
			Frames.Application.on('cancelpopups.verticalmenu', this._closehandler);

			if (Frames.isFunction(this.options.onready))
			{
				this.options.onready();
			}
		},

		_convertkey: function(accesskey)
		{
			accesskey = accesskey.toLowerCase();
			var parts = accesskey.split('+');

			var _mods = [];
			var _keys = [];

			_$.each(['alt', 'ctrl', 'shift'], function(i, key)
			{
				if (accesskey.indexOf(key) != -1)
				{
					_mods.push(key);
				}
			});

			_$.each(parts, function(i, p)
			{
				var ismod = false;
				if (_$.inArray(p, ['alt', 'ctrl', 'shift']) == -1)
				{
					_keys.push(p);
				}
			});

			return _mods.join('+') + (_mods.length > 0 && _keys.length > 0 ? '+'  : '') + _keys.join('+');
		},

		// events bound via _on are removed automatically
		// revert other modifications here
		_destroy: function()
		{
			// TODO:
			// - remove menu from instances
			// - destroy what's needed
			Frames.Application.off('cancelpopups.verticalmenu', this._closehandler);
		},

		// _setOption is called for each individual option that is changing
		// any validation should be done here
		_setOption: function(key, value)
		{
			// prevent invalid values
			/*
			if ( ... ) {
				return;
			}
			*/

			_$.Widget.prototype._setOption.apply(this, arguments);
			// this._super(key, value);

			if (key == 'items')
			{
				this._refresh();
			}
		},

		_drawTree: function(items)
		{
			var html = '';
			for (var i = 0; i < items.length; i++)
			{
				var it = _$.extend({}, items[i], { rtl: this._isRTL });

				if (it.items)
				{
					it.content = this._drawTree(it.items);
					if (it.content === '')
					{
						delete it.content;
					}
				}

				html += this.templates.item(it);
			}
			return html;
		},

		_apply_shortcuts: function(arr)
		{
			var that = this;

			_$.each(arr, function(i, item)
			{
				if (Frames.isArray(item.items))
				{
					that._apply_shortcuts(item.items);
				}
				else if (item.action && Frames.isUndef(item.shortcut))
				{
					var cfg = Frames.Config.getaction_name(item.action);
					if (!Frames.isUndef(cfg) && !Frames.isUndef(cfg.accesskey))
					{
						item.shortcut = Frames.humanize_shortcut(cfg.accesskey);
					}
				}
				else if (!Frames.isUndef(item.shortcut))
				{
					item.shortcut = Frames.humanize_shortcut(item.shortcut);
				}
			});
		},

		// called when created, and later when changing options
		// and menu methods
		_refresh: function()
		{
			if (!this.templates.main)
			{
				return;
			}

			this.element.empty();

			this._apply_shortcuts(this.options.items);

			var html = this.templates.main({
				id: this._uuid,
				content: this._drawTree(this.options.items),
				rtl: this._isRTL
			});
			this.element.html(html);

			this._initializeKeyboard();
			this._initializeClick();
			this._initializeSearch();
			this._initializeToggles();

			Frames.Application.trigger('verticalMenuRefresh', this);
		},

		_initializeSearch: function()
		{
			var that = this;

			this.$search = _$('.menu-search input', this.element);
			this.$search.attr('maxlength', 100);
			this.$search.on('keyup', function(e)
			{
				clearTimeout(that._searchtimeout);
				that._searchtimeout = setTimeout(function()
				{
					that.filter(that.$search.val());
					if (e.keyCode == _$.ui.keyCode.ENTER && !Frames.Config.getbool('DISABLE_MENU_ENTER', false))
					{
						Frames.Workspace.callformByName(that.$search.val());
					}
				}, 500);
			});
		},

		filter: function(keyword)
		{
			if (keyword && keyword.trim())
			{
				keyword = keyword.trim();
				_$('> ul > li.menu-filter-item', this.element).remove();

				_$('.menu-submenu', this.element).hide();
				_$('> ul > li', this.element).not('.menu-search').hide();

				this._item_filter(this.options.items, keyword);

				this._initializeClick(true);
			}
			else
			{
				_$('> ul > li.menu-filter-item', this.element).remove();

				_$('.menu-submenu', this.element).css({display: ''});
				_$('> ul > li', this.element).not('.menu-search').show();
			}
		},

		_parent_labels: function(it)
		{
			var s = '';
			if (it._parent !== undefined)
			{
				s += this._parent_labels(it._parent) + ' &gt; ';
			}
			s += it.label;
			return s;
		},

		_item_filter: function(items, keyword, parent)
		{
			var that = this;
			var lparent;

			_$.each(items, function(i, it)
			{
				if (Frames.isArray(it.items))
				{
					it = _$.extend({}, it, {_parent: parent, _level: parent ? parent._level + 1 : 0});
					that._item_filter(it.items, keyword, it);
				}
				else
				{
					if (it.label && it.label.toLowerCase().indexOf(keyword.toLowerCase()) != -1)
					{
						if (parent && lparent != parent)
						{
							var $el1 = _$(that.templates.item({type: 'section', label: that._parent_labels(parent), content: '', rtl: this._isRTL }));
							$el1.addClass('menu-filter-item');
							_$('> ul', that.element).append($el1);

							lparent = parent;
						}

						var tmplOptions = _$.extend({}, it, { rtl: this._isRTL });
						var $el = $(that.templates.item(tmplOptions));
						$el.addClass('menu-filter-item');
						_$('> ul', that.element).append($el);
					}
				}
			});
		},

		_findObjectByProperty: function(properties, value, arr) {
			var that = this;

			arr = arr || that.options.items;

			if (!Frames.isArray(properties))
			{
				properties = [properties];
			}

			var obj;
			_$.each(arr, function(i, o)
			{

				// find valid properties
				_$.each(properties, function(j, property) {
					if (o.hasOwnProperty(property))
					{
						if (o[property] == value)
						{
							obj = o;
							return false;
						}
					}
				});

				if (obj === undefined && Frames.isArray(o.items) && o.items.length > 0)
				{
					obj = that._findObjectByProperty(properties, value, o.items);
				}

				if (obj !== undefined)
				{
					return false; // break loop;
				}
			});

			return obj;
		},

		findItem: function(id)
		{
			return this._findObjectByProperty('id', id);
		},

		_initializeKeyboard: function()
		{
			var that = this;

			var $el = _$('> ul', this.element);
			$el.off('keydown').on('keydown', function(ev)
			{
				if (ev.keyCode == _$.ui.keyCode.ESCAPE)
				{
					that.close();
					return false;
				}

				if (ev.keyCode == _$.ui.keyCode.DOWN)
				{
					that._nextItemFocus(1);
					return false;
				}

				if (ev.keyCode == _$.ui.keyCode.UP)
				{
					that._nextItemFocus(-1);
					return false;
				}

				if (ev.keyCode == _$.ui.keyCode.ENTER && Frames.Config.getbool('DISABLE_MENU_ENTER', false))
				{
					if (_$(ev.target) && _$(ev.target).data('action'))
					{
						ev.preventDefault();
						return false;
					}
				}
			});
		},

		_nextItemFocus: function(dir)
		{
			var $ul = _$('ul:visible', this.element).last();
			var $list;

			if (Frames.Navigation.mode() === 'all')
			{
				$list = $ul.find('> li > *:tabbable');
			}
			else
			{
				$list = $ul.find('> li > *:tabbable:not(.ui-state-disabled)');
			}

			var pos = $list.index($list.filter(':focus'));

			pos = pos + dir;

			if (pos < 0)
			{
				pos = -1;
			}

			if (pos >= $list.length)
			{
				pos = $list.length - 1;
			}

			if (pos == -1)
			{
				this.$search.focus().select();
			}
			else
			{
				$list.eq(pos).trigger('focus');
			}
		},

		_initializeClick: function(search)
		{
			var that = this;

			_$(search ? '> ul > li.menu-filter-item > .menu-label' : '.menu-label', this.element).on('click', function()
			{
				var $el = _$(this);

				if (Frames.isFunction(that.options.click) && (!$el.hasClass('disabled') && $el.attr('aria-disabled') != 'true'))
				{
					var id = $el.data('uuid');
					if (id)
					{
						var it = that.findItem(id);
						that.options.click(it);

						var index = that.getMenuIndex(this);
						var menuid = that.element.attr("id");
						Frames.Application.trigger('handlemenuitem', {target: menuid, value: index, task: it.itid && it.action ? it.itid : undefined});

						if (that.options.layout == 'horizontal')
						{
							that.element.find('[data-toggle=dropdown][aria-expanded=true]').dropdown('toggle');
						}
					}
				}

				if (that.options.type == 'horizontal' && $el.attr('aria-haspopup') != 'true')
				{
					return false;
				}
			});
		},

		getMenuIndex: function (menuitem)
        {
        	var ind;
        	this.element.find('a').each( function(index, el)
            {
        	    if (el == menuitem)
        	    {
        	    	ind = index;
        	    	return;
        	    }
        	});
        	return ind;
        },

		_initializeToggles: function()
		{
			var that = this;

			_$('.menu-node > a.menu-label', this.element).on('click', function()
			{
				var $li = _$(this).closest('li');
				var $ul = $li.closest('ul');
				var $menu = $li.children('.menu-submenu');
				// $ul.children('li').not('.menu-search').css('display', 'none');
				// $li.css('display', '');

				$ul.parent().addClass('submenu-open');

				$menu.addClass('menu-open');
				that.$search.focus().select();

				return false;
			});
			_$('.menu-submenu-close', this.element).on('click', function()
			{
				var $li = _$(this).closest('li');
				var $menu = $li.closest('.menu-submenu');
				var $ul = $menu.closest('ul');
				$ul.children('li').not('.menu-search').css('display', '');

				$ul.parent().removeClass('submenu-open');

				$menu.removeClass('menu-open');
				that.$search.focus().select();

				return false;
			});

			// initialize widgets
			_$('[data-widget].menu-widget', this.element).each(function()
			{
				var $el = _$(this);
				var widget = $el.data('widget');
				if (widget)
				{
					$el[widget]();
				}
			});
		},

		_closeAll: function(unblock)
		{
			// close all menus
			_$('.workspace-menu').each(function()
			{
				_$(this).verticalmenu('close', unblock);
			});
		},

		_blockContainer: function()
		{
			var that = this;

			if (!_$(this.options.container).data('blockUI.isBlocked'))
			{
				Frames.Workspace.blockUI(_$(this.options.container), {
					overlayCSS: Frames.Loader.OVERLAY,
					css: _$.extend({}, Frames.Loader.BOX, {color: '#fff'}),
					message: null,
					fullHeight: true
				});
				_$('.blockOverlay').on('click', function()
				{
					_$.workspace.verticalmenu.closeAll();
				});
			}
		},

		_unblockContainer: function()
		{
			_$(this.options.container).unblock();
		},

		toogle: function()
		{
			if (!this.enabled())
			{
				return;
			}

			if (this.element.hasClass('menu-open'))
			{
				this.close();
			}
			else
			{
				this.open();
			}

			if (this.$toggle)
			{
				Frames.Application.trigger('handleshortcut', {target: this.element.attr('id'), value: this.$toggle.data('shortcut')});
			}
		},

		open: function()
		{
			var that = this;

			this._closeAll(false);

			// TODO Esta validação deveria estar no Workspace uma vez que
			// o notification center não pertence ao menu vertical.
			if (_$('.notification-item.show').hasClass('open'))
			{
				_$('.notification-item.show.open').removeClass('open');
			}

			this.element.addClass('menu-open');
			this.element.children().attr('aria-hidden','false');
			if (this.$toggle)
			{
				this.$toggle.addClass('menu-active');
			}

			this.$search.focus().select();

			this._blockContainer();
		},

		close: function(unblock)
		{
			this.element.removeClass('menu-open');
			this.element.children().attr('aria-hidden','true')
			if (!Frames.inDocumentationMode)
			{
				this.element.removeClass('submenu-open');
				this.element.find('.menu-submenu').removeClass('menu-open');
			}

			if (this.$toggle)
			{
				this.$toggle.removeClass('menu-active');
			}

			if (unblock || unblock === undefined)
			{
				this._unblockContainer();
			}
		},

		enabled: function(flag)
		{
			var $el = this.element;
			if (this.$toggle)
			{
				if (this.$toggle.parent().is('li'))
				{
					$el = this.$toggle.parent();
				}
				else
				{
					$el = this.$toggle;
				}
			}

			if (arguments.length > 0)
			{
				if (!flag)
				{
					$el.addClass('disabled');
					$el.attr('aria-disabled', 'true');
					$el.attr('disabled', 'disabled');
				}
				else
				{
					$el.removeClass('disabled');
					$el.removeAttr('aria-disabled');
					$el.removeAttr('disabled');
				}
			}
			else
			{
				return !$el.hasClass('disabled');
			}
		}
	});

	_$.workspace.verticalmenu.itemenabled = function($el, flag)
	{
		if (arguments.length > 0)
		{
			if (!flag)
			{
				$el.addClass('disabled');
				$el.attr('aria-disabled', 'true');
				$el.attr('disabled', 'disabled');
			}
			else
			{
				$el.removeClass('disabled');
				$el.removeAttr('aria-disabled');
				$el.removeAttr('disabled');
			}
		}
		else
		{
			return !$el.hasClass('disabled');
		}
	};

	_$.workspace.verticalmenu.itemvisible = function($el, flag)
	{
		if (arguments.length > 0)
		{
			if (!flag)
			{
				$el.addClass('hidden');
				$el.attr('aria-hidden', 'true');
				$el.hide();
			}
			else
			{
				$el.removeClass('hidden');
				$el.removeAttr('aria-hidden');
				$el.show();
			}
		}
		else
		{
			return !$el.hasClass('hidden');
		}
	};

	_$.workspace.verticalmenu._instances = [];

	_$.workspace.verticalmenu.closeAll = function()
	{
		_$.each(_$.workspace.verticalmenu._instances, function(i, m)
		{
			m.close(true);
		});
	};

	Frames.Application.on('execute', _$.workspace.verticalmenu.closeAll);

	// change it back to $ instead of _$ because hotkeys were not loaded yet when utils is loaded 
	if ($.hotkeys)
	{
		$.hotkeys.options.filterInputAcceptingElements = false;
		$.hotkeys.options.filterTextInputs = false;
	}

	// define verticalmenu defaults here, this allows easy client overrides by the same method
	var _vDefaults = _$.workspace.verticalmenu.prototype.options;
	_$.workspace.verticalmenu.setup = function(options)
	{
		var opts = _$.extend(true,{}, _vDefaults, options);
		_$.workspace.verticalmenu.prototype.options = opts;
		return opts;
	};
};

//# sourceURL=app/base/widgets/verticalmenu/js/verticalmenu.js
