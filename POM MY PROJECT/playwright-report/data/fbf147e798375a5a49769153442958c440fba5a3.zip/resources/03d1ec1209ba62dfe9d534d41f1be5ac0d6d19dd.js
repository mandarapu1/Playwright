{

var enabled = Frames.Config.get('ERROR_TIP_ENABLED', true);
if (!Frames.isTrue(enabled))
{
	var _browser = _$.browsercss();

	var validation = {
		show: Frames.Validation.showError,
		hide: Frames.Validation.hideError,
		isIE: (_browser[1] == 'ie10' || _browser[1] == 'ie9')
	};

	var _update = Frames.DataGrid.TextCellEditor.prototype.update;
	Frames.DataGrid.TextCellEditor.prototype.update = function()
	{
		_update.apply(this, arguments);
		var valid = Frames.isTrue(this.props('Valid'));
		if (!valid)
		{
			Frames.Item.prototype.props.apply(this, ['Valid', false]);
		}
	};

	var _itemControlInfo = Frames.Item.prototype.itemControlInfo;
	var _props = Frames.Item.prototype.props;

	_$.extend(Frames.Item.prototype,
	{
		itemControlInfo: function(data, rowid)
		{
			// reset title
			var $input = this.validable();
			if ($input)
			{
				var t = $input.data('title');

				$input.data('title', '');
//				$input.attr('title', t || '');
				$input.data('error', '');
			}

			_itemControlInfo.apply(this, arguments);
		},

		props: function()
		{
			var ret = _props.apply(this, arguments);

			if (arguments.length == 2)
			{
				var p = arguments[0].replace('@', '');
				var v = arguments[1];

				if (p == 'Valid')
				{
					v = Frames.isTrue(v);

					var $el = Frames.isFunction(this.resolve) ? this.resolve().elem : this.elem;

					if ($el !== undefined)
					{
						var bnd = this.bindable();

						// HACK: do not add error classes to not selected row in repeater
						if (Frames.isFunction(this.inSelectedRow) && !this.inSelectedRow())
						{
							return;
						}

						if (this.args && this.args.container)
						{
							$el = this.args.container;
						}
						else if ($el.parent().find('label,div').index($el) === 1 && $el.parent().hasClass('ui-component'))
						{
							if (v)
							{
								$el.parent().removeClass('ui-error');
							}
							else
							{
								$el.parent().addClass('ui-error');
							}
						}

						if (v)
						{
							$el.removeClass('ui-error');
						}
						else
						{
							$el.addClass('ui-error');
						}
					}
				}
			}

			return ret;
		}
	});

	_$.extend(Frames.Validation,
	{
		showError: function(item, error)
		{
			validation.show.apply(Frames.Validation, arguments);

			if (item)
			{
				var msg = error && error.text ? error.text() : error;

				// data grid editor
				if (item.elem !== undefined && item.args !== undefined)
				{
					var $el = item.elem.parent();
					if ($el.length > 0)
					{
						$el.addClass('ui-error');
					}
				}

				var $input = item.input();
				if ($input)
				{
					var isRTL = '\u202E';
					$input.data('title', $input.attr('title'));
					$input.data('error', msg);
					if (Frames.Locale.formats.IS_RTL && $input.css('direction') === 'ltr')
					{
						$input.attr('title', isRTL + msg);
					}
					else
					{
						$input.attr('title', msg);
					}

					var bindable = item.bindable ? item.bindable() : undefined;
					if (bindable.widgetcls() == 'datagrid')
					{
						// Fix stupit IE bug when there's an error
						if (validation.isIE)
						{
							var pl = $input.css('paddingLeft');
							var pr = $input.css('paddingRight');

							$input.css('paddingLeft', $input.width() + 4);
							$input.css('paddingRight', $input.width() + 4);

							setTimeout(function() {
								$input.css('paddingLeft', pl);
								$input.css('paddingRight', pr);
							}, 10);
						}
					}
				}

				var inSearchMode =  item && item.mode && item.mode.name == 'SEARCH';
				var noNotifications = Frames.isFunction(Frames.Workspace.hasNotifications) && !Frames.Workspace.hasNotifications();

				if (Frames.Workspace && ((item.elem !== undefined && item._error !== msg) || inSearchMode || noNotifications))
				{
					var noAlerts = Frames.isFunction(Frames.Workspace.hasAlerts) && !Frames.Workspace.hasAlerts();

					// prevent errors clearing alerts
					if (noAlerts || item.hasChanges()) 
					{
						var lbl = item.elem.index() === 0 && item.elem.parent().hasClass('ui-component') ? item.elem.parent().find('> label').text() : item.label();
						var id = item.bindable().id;
						if (noAlerts)
						{
							Frames.Workspace.closeMessage();
						}
						Frames.Workspace.showMessage(_('ERROR_MSG_INVALID_VALUE',lbl) + _$.escapeHtml(msg), 'error', function()

						{
							Frames.focus(Frames.get(id));
						});

						item._error = msg;
						$input.select();
					}
				}
			}
		},

		hideError: function(item)
		{
			validation.hide.apply(Frames.Validation, arguments);

			if (item)
			{
				delete item._error;

				// data grid editor
				if (item.elem !== undefined && item.args !== undefined)
				{
					var $el = item.elem.parent();
					if ($el.length > 0)
					{
						$el.removeClass('ui-error');
					}
				}

				var $input = item.input();
				if ($input)
				{
					var error = $input.data('error');
					if (error)
					{
						var t = $input.data('title');
						$input.data('title', '');

						$input.attr('title', t || '');
						$input.data('error', '');
					}
				}
			}

			if (Frames.Workspace)
			{
				// prevent errors clearing alerts
				if (Frames.isFunction(Frames.Workspace.hasAlerts) && !Frames.Workspace.hasAlerts())
				{
					Frames.Workspace.closeAlert(false);
				}

				Frames.Workspace.arianotify();
			}
		}
	});

	//
	// Hide error when item has changed
	//
	Frames.Application.on('itemchanged', function(ev, item)
	{
		if (item)
		{
			var noAlerts = Frames.isFunction(Frames.Workspace.hasAlerts) && !Frames.Workspace.hasAlerts();
			if (noAlerts)
			{
				$('#notifications').notificationsmenu('hide');
			}
		}
	});
}

}

//# sourceURL=app/base/js/errors.js
