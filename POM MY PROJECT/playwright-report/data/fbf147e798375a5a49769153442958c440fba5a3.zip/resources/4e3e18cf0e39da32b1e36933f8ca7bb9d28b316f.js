{

var Workspace = {};

Workspace.execute = function(action, item, menu, block, member)
{
	if (Frames.Workspace._menuwidget)
	{
		Frames.Workspace._menuwidget.hide('west');
	}

	if (action == 'CALL_FORM')
	{
		Frames.Workspace.callform(item, menu, menu ? 'Context' : undefined, block, member);
	}
	else if (menu)
	{
		// menu actions
		var model = Frames.Application.task.model();
		var callform = Frames.Model.create('menu');
		Frames.Model.attr(callform, 'kind', '');
		Frames.Model.attr(callform, 'name', menu);
		Frames.Model.attr(callform, 'item', item);
		Frames.Model.append(model, callform);

		if (!action)
        {
            action = '';
        }

		Frames.Application.execute(action, Frames.Application.mainTask, model, undefined, undefined, undefined, 'Menu', 0);
	}
	else
	{
		Frames.Application.valexec(action);
	}
};

//
// Workspace Menu Widget Wrapper
//
Workspace.Menu = _$.inherit(
	Frames.Item,
{
	init: function(view)
	{
		this.$menu = this.elem;

		Frames.Item.prototype.init.apply(this, [view]);
		if (this.block)
		{
			this.block.bindable(this);
		}
	},

	destroy: function()
	{
		this.autounregister();
		delete this.view;
		delete this.elem;
	},

	rules: function()
	{
		return null;
	},

	findMenuById: function(id)
	{
		if (!Frames.isUndef(this._items))
		{
			return this._findMenuById(this._items, id);
		}
	},

	_findMenuById: function(arr, id)
	{
		var that = this;
		var ret;

		if (!Frames.isUndef(arr))
		{
			_$.each(arr, function()
			{
				var it = this;

				if (it.itid == id)
				{
					ret = it;
					return false;
				}

				if (Frames.isArray(it.items))
				{
					var o = that._findMenuById(it.items, id);
					if (!Frames.isUndef(o))
					{
						ret = o;
						return false;
					}
				}
			});
		}

		return ret;
	},

	_itemInstanceControlInfo: function(itemData, props, rowid)
	{
		if (!itemData.instance)
		{
			return;
		}

		var that = this;
		var changed = false;

		_$.each(itemData.instance, function()
		{
			var instanceData = this;
			var rowid = instanceData.attr('row');

			if (instanceData && instanceData.properties)
			{
				var propData = instanceData.properties[0];
				var p;
				for (p in propData)
				{
					// check if property is attribute
					if (typeof(p) === 'string' && p.lastIndexOf('@', 0) === -1)
					{
						continue;
					}

					var it;
					if (p == '@Enabled')
					{
						it = that.findMenuById(rowid);
						if (!Frames.isUndef(it))
						{
							it.enabled = Frames.isTrue(propData[p]);
							changed = true;
						}
					}

					if (p == '@Visible')
					{
						it = it || that.findMenuById(rowid);
						if (!Frames.isUndef(it))
						{
							it.visible = Frames.isTrue(propData[p]);
							changed = true;
						}
					}
				}
			}
		});

		if (changed)
		{
			this.$menu.verticalmenu('option', 'items', this._items);
		}
	},

	model: function()
	{
		if (!Frames.Config.getbool('DISABLE_FORMS_MENU', false))
		{
			// getter
			if (arguments.length === 0)
			{
				return null;
			}

			// setter
			else
			{
				var data = arguments[0];
				if (data)
				{
					var records = data.record;
					if (records)
					{
						var items = [];
						this._item_id = 1;

						// check data (.NEt version)
						var node = Frames.find(records[0], 'data', this.member);

						// check item (Java version)
						if (!node)
						{
							node = Frames.find(records[0], 'item', this.member);
						}

						if (node && node[0].menu)
						{
							data = node[0].menu[0];

							var entries = data.entry;

							// TODO: removing first node when it's only one
							if (!Frames.Config.getbool('SHOW_MENU_ROOT', false) && entries.length == 1 && Frames.isArray(entries[0].entry))
							{
								entries = entries[0].entry;
							}

							var i;
							for (i = 0; i < entries.length; i++)
							{
								this._append_entry(items, entries[i], true);
							}
						}

						this._items = items;
						var that = this;

						$menu = this.$menu;
						$menu.verticalmenu('option', 'items', items);
						$menu.verticalmenu('option', 'click', function(it)
						{
							if (it && !Frames.isArray(it.items))
							{
								Workspace.execute(it.action, it.itid, it.menu, that.block.name, that.member);
								$menu.verticalmenu('close');
							}
						});
					}
				}
			}
		}
	},

	_append_entry: function(items, entry, root)
	{
		var it = {
			id: 'item-' + this._item_id++,
			itid: Frames.Model.attr(entry,'id'),
			label: Frames.Model.attr(entry,'label'),
			icon: Frames.Model.attr(entry,'icon'),
			action: Frames.Model.attr(entry,'action'),
			menu: Frames.Model.attr(entry, 'menu'),
			root: root !== undefined ? root : false,
			visible: Frames.isTrue(Frames.Model.attr(entry,'visible') || true),
			enabled: Frames.isTrue(Frames.Model.attr(entry,'enabled') || true)
		};

		if (Frames.isArray(entry.entry))
		{
			var i;
			var subitems = [];
			for (i = 0; i < entry.entry.length; i++)
			{
				this._append_entry(subitems, entry.entry[i]);
			}
			it.items = subitems;
		}

		items.push(it);
	}
});

Frames.regtype('workspacemenu', Workspace.Menu);

};

//# sourceURL=app/base/js/workspace.menu.js
