
Frames.DataGrid.ROW_HEIGHT = 24;
Frames.Repeater.PAGES = [1, 2, 3, 5, 10];

Frames.Application.WORKSPACE_VIEWS = {
	"morphis/frames/workspace/ViewWorkspaceWindow": true,
	"morphis/frames/workspace/ViewLoginSimple": true,
	"net/hedtech/banner/general/common/BannerMain/views/ViewMainTofuWindow": true,
	"net/hedtech/banner/general/common/BannerMain/views/ViewMainWindow": true
};

if (!Frames.isUndef(_$.ui))
{
	// override Frame's accordion defaults
	_$.extend(_$.ui.accordion.prototype.options, {
		heightStyle: 'content'
	});

	// override Frames's tabpanel defaults
	_$.extend(_$.ui.tabpanel.prototype.options, {
		icons: {
			prev: "ui-icon-triangle-1-w",
			next: "ui-icon-triangle-1-e"
		}
	});

	_$.ui.editinput.prototype.options.icon = 'ui-icon-pencil';

	_$.ui.combobox.prototype.inputWidth = function(container, size)
	{
		return container.outerWidth() + size;
	};

	_$.ui.combobox.prototype._escapeSpace = function(text)
	{
		return _$.encode(text);
	};

	_$.ui.checkbox.prototype.getDefaultValue = function()
	{
		return '';
	};

	_$.ui.tree.prototype.parseIcon = function(icon)
	{
		var imgURL = Frames.Config.get('IMAGES_URL', 'img');
		var imgExtension = Frames.Config.get('IMAGES_EXTENSION', 'png');
		return Frames.isUndef(icon) ? '' : imgURL + '/' + icon + '.' + imgExtension;
	}
}

var itemProps = Frames.Item.prototype.props;
Frames.Item.prototype.props = function()
{
	if (arguments.length === 1 && arguments[0] == "keyactions")
	{
		// always return NEXT_ITEM/PREV_ITEM keyactions
		var keyactions = itemProps.apply(this, arguments);
		keyactions = keyactions ? keyactions.split(",") : [];

		if (keyactions.indexOf("NEXT_ITEM") === -1)
		{
			keyactions.push("NEXT_ITEM");
		}

		if (keyactions.indexOf("PREV_ITEM") === -1)
		{
			keyactions.push("PREV_ITEM");
		}

		return keyactions.join(",");
	}

	return itemProps.apply(this, arguments);
};

var isInvalidAction = function(key, block) {
	if(block === undefined)
	{
		block = Frames.Application.task.block;
	}
	// prevent invalid actions while filter is opened  (record navigation and pagination actions)
	if(block && block.props("blockMode") == "SEARCH")
	{
		var action = Frames.Config.getaction(key);
		var invalidActionsInSearchMode = ['NEXT_BLOCK', 'PREVIOUS_BLOCK', 'NEXT_RECORD', 'PREVIOUS_RECORD', 'NEXT_ITEM', 'PREVIOUS_ITEM',
		                                  'NEXT_PAGE', 'PREVIOUS_PAGE', 'FIRST_PAGE', 'LAST_PAGE',
										  'CREATE_RECORD', 'DELETE_RECORD', 'DUPLICATE_RECORD', 'CLEAR_RECORD',
										  'LIST_VALUES'];
		var filterActions = ['EXECUTE_QUERY', 'SEARCH', 'CLEAR-FORM',
							 'SAVE_GRID_SETTINGS', 'SAVE_PAGINATION_SETTINGS', 'SAVE_FILTER_SETTINGS', 'SAVE_ALL_SETTINGS',
							 'RESTORE_GRID_SETTINGS', 'RESTORE_PAGINATION_SETTINGS', 'RESTORE_FILTER_SETTINGS', 'RESTORE_ALL_SETTINGS',
							 'MASTER_CHECKBOX_CLICK', 'DISABLE_SETTINGS', 'RESTORE_GLOBAL_SETTINGS'];

		var filterVersion = !Frames.isUndef(block._exts.FilterVersion) ? block._exts.FilterVersion : Frames.Config.get('FILTER_VERSION', '1');
		var ListValues = invalidActionsInSearchMode.indexOf('LIST_VALUES');
		if (filterVersion === '2')
		{
			if (!Frames.isItem() && action && filterActions.indexOf(action.name) == -1)
			{
				return true;
			}
			if (ListValues != -1)
			{
				invalidActionsInSearchMode.splice(ListValues, 1);
			}
		}

		if (action)
		{
			return invalidActionsInSearchMode.indexOf(action.name) != -1;
		}
	}
	// prevent record navigation when a multi-line field is focused
	if (document.activeElement && document.activeElement.tagName == 'TEXTAREA')
	{
		return (key == 'DOWN' || key == 'UP');
	}
	return false;
};

var blockProcessKey = Frames.Block.prototype.processKey;
Frames.Block.prototype.processKey = function(item, key)
{
	if(isInvalidAction(key, this))
	{
		if(window.event && window.event.stopImmediatePropagation)  // IE9 seems to be unaware that the stopImmediatePropagation is actually supported in IE9 :)
		{
			window.event.stopImmediatePropagation();
		}
		return false;
	}
	return blockProcessKey.apply(this, arguments);
};

Frames.Block.prototype.getFilterPanel = function()
{
	var result = _$('.ui-filterpanel:visible');
	if (result.length == 0)
	{
		var that = this;

		_$('.ui-filterpanel').each(function(idx, el)
		{
			var filter = _$(el).data('ui-filterpanel');
			var filterBlock = filter.getBlock();
			if (!Frames.isUndef(filterBlock) && filterBlock.name == that.name)
			{
				result = _$(el);
				return false;
			}
		});
	}

	return result;
};

Frames.Block.prototype.filter_model = function()
{
	var ttidx;
	if (Frames.isDebugMode())
	{
		ttidx = Frames.Application.logger.time('GET_FILTER_MODEL_BLOCK', true, undefined, this.name);
	}

	var blockObj = { name: this.name, filterItems: [] };

	var filterPanel = this.getFilterPanel();

	var filterMode = '';
	if (filterPanel.hasClass('ui-basic-filter-mode'))
	{
		filterMode = 'basic';
	}
	else if (filterPanel.hasClass('ui-advanced-filter-mode'))
	{
		filterMode = 'advanced';
	}
	blockObj.filterMode = filterMode;

	var item, itemProps, itemObj;

	// return data from each filter item
	this._FILTER_.reset();
	while (this._FILTER_.hasNext())
	{
		item = this._FILTER_.next();
		itemProps = {};
		var format = item.props('format');
		var type = item.props('type') || 'String';


		if (item.widgetcls() == 'checkbox' || item.widgetcls() == 'radiogroup')
		{
			itemProps.value = item.value();
		}
		else if (filterMode == 'advanced')
		{
			itemProps.value = Frames.FilterPanel.getBasicFilterValue(item.elem.parent());
		}
		else
		{
			itemProps.value = item.elem.find('input').val();
		}

		//Format value due to multilanguage support
		var v;
		var ast = Frames.Query.parse(itemProps.value);
		if (ast.criteria)
		{
			var vals = _$.map(ast.values, function(vv)
			{
				return Frames.Format.formatToCanonical(vv, format, type);
			});
			if (ast.criteria == 'LIKE')  // if the search operator is LIKE, we can't formatToCanonical, because the % can be placed anywhere (eg: %123%56%)
			{
				vals = ast.values;
			}
			v = Frames.Query.build(ast.criteria, ast.modifier, vals, type);
		}
		else
		{
			v = Frames.Format.formatToCanonical(itemProps.value, format, type);
		}

		var restrictCase = item.props('InputTransform');
		if (restrictCase == 'upper')
		{
			v = v.toUpperCase();
		}
		else if (restrictCase == 'lower')
		{
			v = v.toLowerCase();
		}

		itemProps.value = _$.escapeHtml(v);

		itemObj = { name: item.member, customChanges: itemProps};
		blockObj.filterItems.push(itemObj);
	}

	if (Frames.isDebugMode())
	{
		Frames.Application.logger.timeEnd('GET_FILTER_MODEL_BLOCK', ttidx);
	}

	return blockObj;
};

Frames.Block.prototype.setInitialFilterModel = function(model)
{
	this.initialFilterModel = model || this.filter_model();
};

Frames.Block.prototype.getInitialFilterModel = function()
{
	return this.initialFilterModel;
};

var getUpaInfo = function(itemName)
{
	var data = Frames.Application.task.data;
	if (Frames.isUndef(data))
	{
		return null;
	}

	var block = Frames.Model.findSingle(data, 'block', 'BANNER_FOOTER_DATA');
	if (Frames.isUndef(block))
	{
		return null;
	}

	var record = Frames.Model.findSingle(block, 'record');
	if (Frames.isUndef(record))
	{
		return null;
	}

	var item = Frames.Model.findSingle(record, 'item', itemName);
	if (Frames.isUndef(item))
	{
		return null;
	}

	return Frames.Model.text(item);
}

Frames.Task.prototype.isMaster = function()
{
	return Frames.isTrue(getUpaInfo('MASTER'));
};

Frames.Task.prototype.hasPageSettings = function()
{
	return Frames.isTrue(getUpaInfo('UPA_PAGE_ENABLED'));
};

Frames.Task.prototype.isUpaInstitution = function()
{
	return Frames.isTrue(getUpaInfo('UPA_INSTITUTION_ENABLED'));
};

Frames._preventBrowserShortcuts = function(ev) {

	var key = Frames.Keys.string(ev);

	if (Frames.inDocumentationMode)
	{
		return;
	}

	if (Frames.Config.haskeys(ev) && !isInvalidAction(key))
	{
		// guarantee that pager select events go through on IE
		if ((Frames.browser && Frames.browser.name != 'ie') || !_$(ev.target).hasClass('ui-select-paging'))
		{
			ev.preventDefault();
		}
		Frames._preventBrowserSpecialShortcuts(ev, true);
	}
	else
	{
		Frames._preventBrowserSpecialShortcuts(ev, false);
	}
};

var _context = Frames.StatusBar.context;
/*jshint eqnull:true */
Frames.StatusBar.context = function(txt)
{
	if (Frames.Locale.formats.IS_RTL && txt != null && txt !== '')
	{
		txt = '<span dir="ltr">' + txt + '</span>';
	}

	_context.call(Frames.StatusBar, txt);
};

var _info = Frames.StatusBar.info;
/*jshint eqnull:true */
Frames.StatusBar.info = function(txt)
{
	if (Frames.Locale.formats.IS_RTL && txt != null && txt !== '')
	{
		txt = '<span dir="ltr">' + txt + '</span>';
	}

	_info.call(Frames.StatusBar, txt);
};

App = {
	_ltrCharacters: "0-9\u0041-\u005A\u0061-\u007A\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02B8\u0300-\u0590\u0800-\u1FFF\u200E\u202A\u202D\u2C00-\uFB1C\uFDFE-\uFE6F\uFEFD-\uFFFF\u002D\u003A\u002E",

	/**
	 * server doesn't send ltr/rtl language direction information
	 * in rtl, try to catch some use cases that we know are fixed to ltr and have problems with weak characters, and inject control entities
	 * eg: [FORMNAME], (INSTID)
	 */
	processTitleString: function(s)
	{
		if (Frames.Locale.formats.IS_RTL)
		{

			var matches = s.match(new RegExp("\\([" + App._ltrCharacters + "]+\\)|\[[" + App._ltrCharacters + "]+\]", "g"));
			if (matches)
			{
				for (var i = matches.length - 1; i >= 0; i--) {
					var match = matches[i];

					s = s.replace(match, "\u202A" + match + "\u202C");
				}
			}
		}

		return s;
	}
};

var _ariaNotify = Frames.Workspace.arianotify;
Frames.Workspace.arianotify = function(msg, role, priority, type)
{
	var self = this;
	if (Frames.isUndef(Frames.browser) || Frames.browser.mobile)
	{
		setTimeout(function() {
			_ariaNotify.apply(self, arguments);
		}, 0);
	}
	else
	{
		_ariaNotify.apply(this, arguments);
	}
};

var _viewTitle = Frames.View.prototype.title;

Frames.View.prototype.title = function()
{
	// getter
	if (arguments.length === 0)
	{
		return _viewTitle.apply(this, arguments);
	}

	// setter
	else
	{
		var title = arguments[0];

		title = App.processTitleString(title);

		 _viewTitle.call(this, title);
	}
};

//
// RESPONSIVE KEYBLOCK
//
var readKeyblockGetStarted = true;
Frames.Application.on('viewready', function(ev, result)
{
	if (Frames.isReact)
	{
		result = ev.detail.data;
	}

	var task = result.task;
	if (task)
	{
		var $win = result.task._container || result.view.window();
		var $btn = _$('.keyblock-button-container button[data-action=CLEAR-FORM]', $win);
		if ($btn.length > 0)
		{
			var $kb = _$('.keyblock', $win);

			if ($btn.is(':visible'))
			{
				$kb.addClass('ui-mode-readonly');
			}
			else if ($kb.hasClass('ui-mode-readonly'))
			{
				$kb.removeClass('ui-mode-readonly');
				Frames.Application.trigger('startover');
			}
		}
	}

	var welcomeCanvas = _$('#G_WELCOME_CANVAS');
	if (welcomeCanvas.is(':visible'))
	{
		if (readKeyblockGetStarted)
		{
			Frames.arianotify(welcomeCanvas.text().trim());
			readKeyblockGetStarted = false;
		}
	}
	else
	{
		readKeyblockGetStarted = true;
	}
});

Frames.Application.on('dialogopen beforedialogclose', function(ev, result)
{
	if (!Frames.browser.mobile)
	{
		return
	}

	var cnt = Frames.Dialog.container();
	var wC = cnt.find('.ui-window-container')
	if (wC.length > 0)
	{
		if (ev.type == 'dialogopen')
		{
			wC.attr('aria-hidden', 'true');
		}
		else
		{
			wC.removeAttr('aria-hidden');
		}
	}
});

//url for print
Frames.Application.on('opentask closetask', function(ev, result)
{
	var task = result.task;
	if (task)
	{
		var param;
		var apps_root = Frames.Config.get('APPS_URL', '.');
		var url;

		if (Frames.isDebugMode())
		{
			param =  document.location.search;
			if (param.indexOf('&form=') >= 0 || param.indexOf('?form=') >= 0)
			{
				param = param.replace(/(\?|&)form=[aA-zZ0-9]*/g, '');

				if (param.indexOf('&') == 0)
				{
					param = param.replace(/^&/, '?');
				}
			}
		}

		if (task == Frames.Application.mainTask)
		{
			url = Frames.isEmpty(param) ? apps_root : apps_root + param;
			window.history.pushState(undefined, undefined, url);
		}
		else
		{
			url = Frames.isEmpty(param) ? apps_root + '?form=' + task.name : apps_root + param + '&form=' + task.name;
			window.history.pushState(undefined, undefined, url);
		}
		Frames.Application.trigger('urlchange', { url: window.location.href });
	}
});

//
// Paint cell of active item
//
var $last_active_cell;

Frames.Application.on('itemactivated', function(ev, item)
{
	// Avoid paint virtual items like datagrid or repeater
	var isContext = !Frames.isUndef(item.isContext) && Frames.isTrue(item.isContext());
	if (item && item.elem && !isContext)
	{
		var container = item.elem.parent();
		var $el;
		if (container.hasClass('ui-layout-cell'))
		{
			$el = container;
		}
		else if (container.parent().hasClass('ui-layout-cell'))
		{
			$el = container.parent();
		}
		else
		{
			var cnt = container.closest('.ui-layout-gridflow');
			if (cnt.length > 0)
			{
				if (cnt.parent().hasClass('ui-table-matrix'))
				{
					if (container.hasClass('ui-component'))
					{
						container = container.parent();
					}

					$el = container;
				}
			}
		}

		if ($el !== undefined)
		{
			if ($last_active_cell !== undefined)
			{
				$last_active_cell.removeClass('ui-layout-cell-active');
			}

			$el.addClass('ui-layout-cell-active');
			$last_active_cell = $el;
		}
	}
});

//
// Date Formatting per Locale
//
var _forceLocale = Frames.isTrue(Frames.Config.get('DATE_FORCE_LOCALE', true));
if (_forceLocale)
{
	var _defs = {
		init: Frames.Item.prototype.init,
		props: Frames.Item.prototype.props,
		set_prop: Frames.Item.prototype._set_prop,

		localizeDate: function(format)
		{
			var dateFormat = Frames.Locale.formats.DATE_FORMAT;
			var formatter = Frames.Format._getFormatter('Date');
			format = formatter.convertFormat(format);

			// day
			if (!/dd/i.test(format))
			{
				dateFormat = dateFormat.replace(/\W?d\w*/i, '');
			}
			// month
			if (!/m{1,5}/i.test(format))
			{
				dateFormat = dateFormat.replace(/\W?m\w*/i, '');
			}
			// year
			var year = /y{2,4}/i.exec(format);
			if (year == null)
			{
				dateFormat = dateFormat.replace(/\W?y\w*/i, '');
			}
			else
			{
				var formatYear = /y\w*/i.exec(dateFormat);
				dateFormat = dateFormat.replace(formatYear[0], formatYear[0].substr(0, year[0].length));
			}
			// trim remaining separators
			return dateFormat.replace(/^\W+/, '');
		},

		localizeTime: function(format, datetime)
		{
			var is24h = /hh24/i.test(format);

			var timeFormat = Frames.Locale.formats.TIME_FORMAT;
			var formatter = Frames.Format._getFormatter('Time');
			format = formatter.convertFormat(format);

			// hour
			if (!/hh/i.test(format))
			{
				timeFormat = timeFormat.replace(/\W?h\w*/i, '');
			}
			else if (is24h)
			{
				timeFormat = timeFormat.replace(/\W?h\w*/i, 'HH24');
			}

			// minute
			if (!/mm|00/i.test(format))
			{
				timeFormat = timeFormat.replace(/\W?m\w*/i, '');
			}
			// second
			if (!/ss/i.test(format))
			{
				timeFormat = timeFormat.replace(/\W?s\w*/i, '');
			}
			// am/pm indicator
			if (!datetime)
			{
				timeFormat = timeFormat.replace(/\W?a\w*/i, '');
			}
			// trim remaining separators
			return timeFormat.replace(/^\W+/, '');
		},

		hasTime: function(format)
		{
			if (Frames.isUndef(format))
			{
				return false;
			}

			return format.toLowerCase().indexOf('hh') !== -1;
		},

		isDate: function(item)
		{
			if (!item._isdate)
			{
				var $el = item.elem || _$();
				var widget = item._props ? item._props.widget : $el.data('widget');
				var type = item._props ? item._props.type : $el.data('type');

				item._isdate = (type == 'Date' || widget == 'datefield');
			}
			return item._isdate;
		},

		isTime: function(item)
		{
			if (!item._istime)
			{
				var $el = item.elem || _$();
				var type = item._props ? item._props.type : $el.data('type');

				item._istime = (type == 'Time');
			}
			return item._istime;
		},

		parseColumn: Frames.DataGrid.prototype._parseColumn,
		commands_pre_viewopen: Frames.Application._commands_pre_viewopen
	};

	_$.extend(Frames.DataGrid.prototype,
	{
		_parseColumn: function(index, _prop)
		{
			if (_prop.type == 'Date')
			{
				if (_defs.hasTime(_prop.format))
				{
					_prop.format = _defs.localizeDate(_prop.format) + ' ' + _defs.localizeTime(_prop.format, true);
				}
				else
				{
					_prop.format = _defs.localizeDate(_prop.format);
				}
			}
			else if (_prop.type == 'Time')
			{
				_prop.format = _defs.localizeTime(_prop.format, false);
			}

			var col = _defs.parseColumn.apply(this, arguments);

			if (_prop['data-add-aria-describedby'])
			{
				col.describedBy = _prop['data-add-aria-describedby'];
			}

			//added a fixed with on calendars in RTL languageS to fit the date value
			var w;

			if (!Frames.isUndef(_prop.width) && _prop.type == 'Date' && Frames.Locale.formats.IS_RTL)
			{
				w = parseInt(_prop.width, 10);
				if (!isNaN(w))
				{
					var hasCustomWidth = false;
					if (!Frames.isUndef(this.settings))
					{
						var customItems = this.settings.customItems;
						for (var idx in customItems) {
							var customItem = customItems[idx];
							if (customItem.name == col.field
							 && !Frames.isUndef(customItem.customChanges)
							 && !Frames.isUndef(customItem.customChanges.width))
							{
								hasCustomWidth = true;
								break;
							}
						}
					}

					if (!hasCustomWidth)
					{
						col.width = 200;
					}
				}
			}
			return col;
		}
	});

	var _parseFormatMask = function(item, frm)
	{
		if (!Frames.isUndef(frm))
		{
			if (_defs.isDate(item))
			{
				if (_defs.hasTime(frm))
				{
					frm = _defs.localizeDate(frm) + ' ' + _defs.localizeTime(frm, true);
				}
				else
				{
					frm = _defs.localizeDate(frm);
				}
				return frm;
			}
			else if (_defs.isTime(item))
			{
				return _defs.localizeTime(frm, false);
			}
		}
	};

	_$.extend(Frames.Item.prototype,
	{
		init: function()
		{
			var frm = _parseFormatMask(this, this.elem.data('format'));
			if (!Frames.isUndef(frm))
			{
				this.elem.attr('data-format', frm);
				this.elem.data('format', frm);
				this._props.format = frm;
			}

			_defs.init.apply(this, arguments);

			this.replaceDecimalSeparator();
		},

		replaceDecimalSeparator: function()
		{
			//Decimal separator like comma - Make numpad decimal key type comma instead
			var self = this;
			var inp = this.input();
			_$(inp).on('keydown', function(ev)
			{
				if (ev.keyCode ===  110 && self.props('type') == 'Number' && Frames.Locale.formats.DECIMAL_SEPARATOR == ',')
				{

					var value = this.value;
					var v1 = value.substr(0, _$(this).prop('selectionStart'));
					var v2 = value.substr(_$(this).prop('selectionStart'));

					this.value = v1 +  ',' + v2;

					var pos = v1.length + 1;
					_$(this)[0].setSelectionRange(pos, pos);
					ev.preventDefault();
				}
			});
		},

		props: function()
		{
			if (arguments.length > 1 && (arguments[0] === "@FormatMask" || arguments[0] === "format"))
			{
				var frm = _parseFormatMask(this, arguments[1]);
				if (!Frames.isUndef(frm))
				{
					_defs.props.apply(this, [arguments[0], frm]);
					return;
				}
			}

			return _defs.props.apply(this, arguments);
		},

		_set_prop: function(p, v)
		{
			if (_defs.isDate(this) && p == 'format')
			{
				var frm = _parseFormatMask(this, arguments[1]);
				if (!Frames.isUndef(frm))
				{
					v = frm;
				}
			}
			_defs.set_prop.apply(this, arguments);
		}
	});

	Frames.Dialog.LOV._getMinWidth = Frames.Dialog.LOV.getMinWidth;
	Frames.Dialog.LOV.getMinWidth = function(options)
	{
		return Math.max(options.width, 425) + 30;
	};

	Frames.Dialog.LOVBlock.prototype._model = Frames.Dialog.LOVBlock.prototype.model;
	Frames.Dialog.LOVBlock.prototype.model = function()
	{
		// getter
		if (arguments.length === 0)
		{
			return this._model();
		}
		// setter
		else {
			this._model(arguments[0]);

			// if we're in RTL, activity_dates should be forced into dir=rtl
			var grid = Frames.get("grdLov", null, Frames.Dialog.LOV.view);
			if(Frames.Locale.formats.IS_RTL)
			{
				for(var idx in grid._columns)
				{
					if(grid._columns[idx].field.indexOf("ACTIVITY_DATE") != -1 ||
				     grid._columns[idx].field.indexOf("ACT_DATE") != -1)
					{
						grid._columns[idx].props.direction = 'rtl';
					}
				}
			}

			var isResizable = Frames.Config.get('POPUP_RESIZE', 'NONE');
			if (isResizable == 'NONE')
			{
				return;
			}

			if (grid._pager.paginationHasChanged)
			{
				var cnt = Frames.Dialog.container();
				var $dlg = grid.elem.parents('.ui-dialog');
				if ($dlg.height() > parseInt(_$('#grdLov .grid-canvas', $dlg).css('height')))
				{
					var nH = _$('#grdLov .grid-canvas', $dlg).children().length * grid._rowH;
					_$('#grdLov .grid-canvas', $dlg).css('height', nH);
				}

				var gridHeight = _$('#grdLov .grid-canvas', $dlg).height() + _$('.slick-pane-header', $dlg).height();
				var display = grid.elem.css('display');
				grid.elem.css('display', 'none');
				$dlg.find('.ui-dialog-content').css('height', 'auto');
				var dlgTitlebarHeight = parseInt($dlg.find('.ui-dialog-titlebar').css('height'));
				var dlgHeight = parseInt($dlg.find('.ui-dialog-content').css('height')) + dlgTitlebarHeight;
				grid.elem.css('display', display);

				var contentHeight = dlgHeight + gridHeight;

				if (contentHeight > _$(cnt).height())
				{
					$dlg.css('height', _$(cnt).height());
					grid.elem.css('height', _$(cnt).height() - dlgHeight)
				}
				else
				{
					$dlg.css('height', contentHeight);
					grid.elem.css('height', gridHeight);
				}
				grid._grid.resizeCanvas();
				$dlg.find('.ui-dialog-content').dialog('option', 'position', { my: 'center', at: 'center', of: cnt });
				grid._pager.paginationHasChanged = false;
			}
		}
	};

	// preserve default date format
	Frames.Application._commands_pre_viewopen = function()
	{
		var _tmp = Frames.Locale.formats.DATE_FORMAT;
		var ret = _defs.commands_pre_viewopen.apply(Frames.Application, arguments);
		Frames.Locale.formats.DATE_FORMAT = _tmp;
		return ret;
	};
}


var addDescribedByInGrids = function(item)
{
	/*if (item.args.column.describedBy)
	{
		var row = item.args.item.__idx__;
		var id = item.args.column.describedBy + '_' + row;
		item.elem.parent().attr('data-aria-describedby', id);
	}*/
	if (item.args.column.describedBy && Frames.Navigation.mode() == 'all')
	{
		var row = item.args.item.__idx__;
		var id = item.args.column.id;
		var describedBy = item.args.column.describedBy;
		var grid = item.args.grid._frames;
		var descColumn;
		var msg = '';

		item.input().attr('aria-describedby', id + '_' + row);

		//create dom invisible element to save aria describedby data
		var $el = _$('.input-grid-desc-screenreader');
		if ($el.length === 0)
		{
			$el = _$('<span class="input-grid-desc-screenreader"></span>');
			_$(document.body).append($el);
		}
		else
		{
			$el.text('');
		}

		$el.attr('id', id + '_' + row);

		if (describedBy)
		{
			//it might have more than one column associated
			describedBy.split(',').forEach(function(itemId) {
				itemId = itemId.replace(' ', '') + '_' + row;
				descColumn = _$('#'+ itemId + '_row');

				if (descColumn.length > 0)
				{
					//check if it has class ui-text, otherwise it might be a formatter like a checkbox for example
					if (descColumn.children().hasClass('ui-text'))
					{
						var descColumnMember = descColumn.children().data('member');
						if (descColumnMember)
						{
							var descColumnLabel = grid._CTX_.get(descColumnMember).label();
							var descColumnText = descColumn.text();
							if (descColumnText)
							{
								msg  = msg + ' ' + descColumnLabel + ' ' + descColumn.text() + '.';
							}
						}
					}
				}
			});

			if (!Frames.isEmpty(msg))
			{
				$el.text(msg);
			}
		}
	}	
};

// FRAMES-2744 - Manually control scroll in grid textareas

var _initTextCell = Frames.DataGrid.TextCellEditor.prototype.init;
Frames.DataGrid.TextCellEditor.prototype.init = function()
{
	_initTextCell.apply(this, arguments);
	if (this.$input.is('textarea'))
	{
		// save scroll position, cursor position and if scroll is enabled
		var scrollPos = this.$input.scrollTop();
		var cancelScroll = false;
		var selStart = this.$input.prop('selectionStart');
		var selEnd = this.$input.prop('selectionEnd');

		var lH = parseInt(this.$input.css('line-height'));

		this.$input.on('scroll', function(ev) {

			// use native scroll events if scroll is caused by a keyboard navigation in the textarea (selectionStart or selectionEnd will change)
			var newSelStart = _$(this).prop('selectionStart');
			var newSelEnd = _$(this).prop('selectionEnd');
			if (newSelStart != selStart || newSelEnd != selEnd)
			{
				selStart = newSelStart;
				selEnd = newSelEnd;
				scrollPos = _$(this).scrollTop();
				cancelScroll = false;
				return;
			}

			// if scroll is disabled, force the textarea to maintain the same scroll position
			if (cancelScroll) {
				_$(this).scrollTop(scrollPos);
				ev.preventDefault();
				ev.stopPropagation();
				return false;
			}
			
			// calculate new scroll position by adding/removing the size of a single line to the previous scroll position
			var currScroll = _$(this).scrollTop();
			if (currScroll > scrollPos) {
				_$(this).scrollTop(scrollPos + lH);
			}
			else if (currScroll < scrollPos)
			{
				_$(this).scrollTop(scrollPos - lH);  
			}
			scrollPos = _$(this).scrollTop();

			// disable scroll for the next 50ms to prevent multiple scroll events from firing on the same action (i.e. click on scrollbar button)
			cancelScroll = true;
			setTimeout(function() {
				cancelScroll = false;
			}, 50);
		});
	}

	this.context.replaceDecimalSeparator();
};

var _destroyTextcell = Frames.DataGrid.TextCellEditor.prototype.destroy;
Frames.DataGrid.TextCellEditor.prototype.destroy = function()
{
	if (this.$input.is('textarea'))
	{
		this.$input.off('scroll');
	}
	_destroyTextcell.apply(this, arguments);
};


var _textApplyFocus = Frames.DataGrid.TextCellEditor.prototype.applyFocus;
Frames.DataGrid.TextCellEditor.prototype.applyFocus = function()
{
	addDescribedByInGrids(this);
	_textApplyFocus.apply(this, arguments);
	
};

var _lovApplyFocus = Frames.DataGrid.LOVInputCellEditor.prototype.applyFocus;
Frames.DataGrid.LOVInputCellEditor.prototype.applyFocus = function()
{
	addDescribedByInGrids(this);
	_lovApplyFocus.apply(this, arguments);
};

//allow click on disabled columns
Frames.DataGrid.prototype._isColumnEnabled = function()
{
	return true;
};

//# sourceURL=app/flat/js/app.js
