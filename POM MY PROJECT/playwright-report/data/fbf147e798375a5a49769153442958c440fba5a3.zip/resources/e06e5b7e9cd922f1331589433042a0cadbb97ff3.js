{
	Frames.FooterLabel = _$.inherit(
		Frames.TextField,
	{
		__constructor: function(elem)
		{
			this.elem = elem;
			this._inp = $('span', elem);

			Frames.Item.prototype.__constructor.apply(this, arguments);

			this.visible(false);
		},

		_applyDirection: function($el)
		{
			if (Frames.isUndef($el))
			{
				$el = !Frames.isUndef(this.input()) ? this.input() : this.elem.children('input,select,button');
			}

			if (!Frames.isUndef($el) && $el.length > 0)
			{
				// reset direction attribute
				$el.removeAttr('dir');
				var dir = Frames.isFunction(this._getDataDirection) ? this._getDataDirection() : Frames.Item.prototype._getDataDirection.call(this);

				if (!Frames.isUndef(dir) && (this.props('type') != 'Date' || this.props('type') == 'Date' && !Frames.Locale.formats.DATE_IS_RTL))
				{
					$el.attr('dir', dir);
				}
			}
		},

		input: function()
		{
			return this._inp;
		},

		value: function()
		{
			// getter
			if (arguments.length === 0)
			{
				return this._inp.text();
			}

			// setter
			else
			{
				this._inp.text(arguments[0] || '');
			}
		},

		model: function()
		{
			// getter
			if (arguments.length === 0)
			{
				return null;
			}

			// setter
			else
			{
				Frames.Item.prototype.model.apply(this, arguments);

				var v = this.value();
				if (Frames.isEmpty(v))
				{
					this.visible(false);
				}
				else
				{
					this.visible(true);
				}
			}
		},

		//Prevent to add widget on designer menu
		addOnMenu: function()
		{
			return [];
		}

		// widgetcls: function() { return 'textfield'; }
	});

	Frames.regtype('footerlabel', Frames.FooterLabel);

};

//# sourceURL=app/flat/widgets/objects/js/footerlabel.js
