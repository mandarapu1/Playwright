/* English initialisation for the jQuery calendars extension: preventing 404 error */
