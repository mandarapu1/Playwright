
    // the widget definition, 'chatarea' the widget name
    _$.widget('ui.exportpanel',
        {
            // default options
            options: {
                main_template: '/flat/widgets/exportpanel/html/exportpanel.tmpl.html#exportpanel-template',
                	
            },

            // the constructor
            _create: function () {
                var that = this;

                var appsroot = Frames.Config.get('APPS_ROOT', '.');

                this.templates = {};
                Frames.Template.get(appsroot + this.options.main_template, function(result)
                {
                    that.templates.main = result;
                    that.element.empty();
                    var html = that.templates.main();
                    that.element.append(html);

                    that._cancelBtn = that.element.find('.ui-export-cancel');
                    that._cancelBtn.on('click', function () {
                         Frames.LongExport.continue = false;
                    });
                });
            },

            destroy: function()
            {
                $('#teste2').off('click', this.click);
            }
        });

    ExportPanel =  _$.inherit(
        Frames.Item,
        {
            __constructor: function(elem, options)
            {
                if (!Frames.isUndef(elem) && elem.jquery)
                {
                    this.elem = elem;
                    this.widget(options); // create widget
                    this.widget('wrapper', this);
                }
                this._props = null;
                this._exts = {};
            },

            isExtendable: function(item)
            {
                if (Frames.inDesignMode || Frames.isUndef(item.elem))
                {
                    return false;
                }
                var wname = item.widgetcls();
                return wname == 'exportpanel';
            },

            register: function(item)
            {
                if (this.isExtendable(item))
                {
                    item.elem.addClass('ui-widget ui-exportpanel');

                }
            },

            submitGo: function () {
                alert("teste");
            },

            unregister: function(item)
            {
                if (this.isExtendable(item))
                {
                }
            },

            widgetcls: function()
            {
                return 'exportpanel';
            }
           
        });

    Frames.regtype("exportpanel", ExportPanel);

//# sourceURL=app/flat/widgets/exportpanel/js/exportpanel.js
