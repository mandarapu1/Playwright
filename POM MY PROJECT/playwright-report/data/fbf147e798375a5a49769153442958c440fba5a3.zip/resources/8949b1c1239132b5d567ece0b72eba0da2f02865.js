/* en formats initialisation */
_$.extend(
	Frames.Locale.formats,
{
	INTEGER_FORMAT: "##########",
	DECIMAL_SEPARATOR: ".",
	GROUP_SEPARATOR: ",",
	NUMBER_FORMAT: "##########D###############",
	CURRENCY_SYMBOL: "$",
	CURRENCY_FORMAT: "L#G###G###G###D###############",
	DATE_FORMAT: "MM/DD/YYYY",
	TIME_FORMAT: 'hh:mm:ss a',
	DATE_PARTS: "D M Y H M S"
});
