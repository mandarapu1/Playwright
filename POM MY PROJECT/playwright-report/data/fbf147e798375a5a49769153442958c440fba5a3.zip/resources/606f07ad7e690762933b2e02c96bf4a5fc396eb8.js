var ViewContainerPanel =
{
	isExtendable: function(item)
	{
		if (Frames.inDesignMode)
		{
			return false;
		}

		var wname = item.widgetcls();
		return (wname == 'tabpanel' &&
			(item.elem.hasClass('ui-panel-view-container') || item.elem.hasClass('ui-panel-view-scroll'))
		);
	},

	register: function(item)
	{
		if (ViewContainerPanel.isExtendable(item))
		{
			item._resizefn = _$.proxy(ViewContainerPanel._resize, item.elem);
			
			if(!item.elem.hasClass('ui-panel-view-noscroll')) {
				$(item.elem).on('resize.' + item.id, {item: item}, item._resizefn);
				Frames.Application.on('viewready.' + item.id, {item: item}, item._resizefn);
				Frames.Application.on('themeswitch.'+ item.id, {item: item}, item._resizefn);
	
				item._scrollfn = function(ev)
				{
					$(window).triggerHandler('scroll', ev);
				};
				item.elem.find('.ui-tabs-panel').on('scroll', item._scrollfn);
	
				if (item.elem.hasClass('ui-notabs') && item.elem.parent().is('.ui-scrollable-tabs'))
				{
					// a specific css rule must check this to hide scrollable tabs helper
					item.elem.parent().addClass('ui-notabs');

					// remove tabpanel roles from notabs to avoid confusing the screen reader
					item.elem.children().removeAttr('role')
						.removeAttr('aria-labelledby');

					// redefine _initPanel to remove tabpanel roles on tabs created later

					var widget = Frames.get_widget(item);
					widget._initPanel_orig = widget._initPanel;
					widget._initPanel = function(panel, tab) {
						this._initPanel_orig.apply(this, arguments);
						$(panel).removeAttr('role').removeAttr('aria-labelledby');
					}
				}
			}
		}
	},

	_resize: function(e)
	{
		if (Frames.Application._performance && Frames.Application.executing())
		{
			return;
		}

		if (e.data)
		{
			var wct = $('body > .workspace-container');
			var view = e.data.item.view; // main window of the viewc-container

			// avoid grabing resizes of forms running in the background (when you open a second form,
			// the view of the first one is still in the DOM, it's just hidden)
			if (view !== Frames.Application.task.view && !view.window().is(':visible'))
			{
				// reset to remove overflow on the main container
				if (wct[0])
				{
					wct.css('overflow-y', '');
				}

				return;
			}

			var $cnt = e.data.item.elem;

			if ($cnt.is('[data-name]')) // are we dealing with a REAL tab canvas or just a container of tabs?
			{
				$cnt.children('.ui-tabs-panel').css('overflow-y', 'hidden');
			}
			else
			{
				// when using view-container the overflow should always be hidden
				// because the view-container will have scrolls
				if (wct[0])
				{
					wct.css('overflow-y', 'hidden');
				}

				var $win = $cnt.closest('.ui-view-window');
				var $wrk = $win.closest('.workspace-tabs');
				var $tabs = $cnt.children('.ui-tabs-panel');

				//$tabs.css('height', ''); // clear

				if ($wrk[0])
				{
					// FRAMES-1731 - class for pages with multiple fixed panels before viewcontainer panel
					var $fixedPanels = $win.find('.ui-fixed-panel');
					if ($fixedPanels.length == 0)
					{
						$fixedPanels = $win.find('.ui-panel').first();
					}
					var offsetPanels = 0;
					$fixedPanels.each(function(idx, el) {
						offsetPanels += el.offsetHeight;
					});

					var $ul = $cnt.children('ul');

					var vH = $wrk[0].offsetHeight;
					var offset = 1 + ($ul[0] ? $ul[0].offsetHeight : 0) + offsetPanels;

					var h = (vH - offset) + 'px';

					$tabs.css('height', h);
				}
			}
		}
	},

	unregister: function(item)
	{
		if (ViewContainerPanel.isExtendable(item))
		{
			$(item.elem).off('resize.' + item.id, item._resizefn);
			Frames.Application.off('viewready.' + item.id, item._resizefn);
			Frames.Application.off('themeswitch.'+ item.id, item._resizefn);
			delete item._resizefn;

			item.elem.off('scroll', item._scrollfn);
			delete item._scrollfn;

			// reset heights
			item.elem.find('.ui-tabs-panel').css({'overflow-y': '', height: ''});

			var wct = $('body > .workspace-container');
			if (wct[0])
			{
				wct.css('overflow-y', '');
			}
		}
	}
};

Frames.regplug('viewcontainer.panel', ViewContainerPanel, Frames.PLUGIN_WIDGET);


// check for support of custom view containers
if (!Frames.isUndef(Frames.Application.getViewContainer))
{
	var getPanelViewContainer = function(view)
	{
		if (view && !view._view_container)
		{
			view._view_container = view.window().find('.ui-panel-view-container');
		}
		return view && view._view_container.length > 0 ? view._view_container : undefined;
	};

	Frames.Application.getViewContainerIndex = function(task)
	{
		task = task || Frames.Application.task;
		var view = task.view;
		if (task && view)
		{
			var idx = Frames.Application._getTaskContainerIndex(view.container().parent(), view.task.id);
			if (!Frames.isNumeric(idx))
			{
				return undefined;
			}

			/*
			var $cnt = Frames.Application.getViewContainer(view);
			if (idx > 0 && $cnt.hasClass('ui-panel-view-container'))
			{
				idx--;
			}*/
			return idx;
		}
		return 0;
	};

	Frames.Application.getViewContainer = function(view)
	{
		var task = view ? view.task : Frames.Application.task;
		var tview = view || task.view;
		if (task && tview && task._VIEWS_)
		{
			view = task._VIEWS_.get(0);
			if (view && tview != view)
			{
				// already 'founded'
				if (task._view_container)
				{
					return task._view_container;
				}

				// check for panel view container
				var $el = getPanelViewContainer(view);
				if ($el)
				{
					task._view_container = $el;
					return $el;
				}
			}
		}

		return Frames.Application._container;
	};

	var _refs = {
		close: Frames.Task.prototype.close,
		closeView: Frames.Task.prototype.closeView,
		needsTaskContainer: Frames.View.prototype.needsTaskContainer,
		_hide: Frames.View.prototype._hide
	};

	Frames.View.prototype._hide = function()
	{
		var task = this.task;

		var tview = task ? task._VIEWS_.get(0) : null;
		var view = this;

		var $el = getPanelViewContainer(view);
		if (tview === view && $el && !this._closing)
		{
			if (Frames.isDebugMode())
			{
				this.logger.debug('prevented view \'%s\' from closing', view.id);
			}
		}

		else
		{
			_refs._hide.apply(this, arguments);

			if (task && task._VIEWS_.indexOf(task.view) === 0 && task._view_container)
			{
				task._view_container.tabs('option', 'active', 0);
			}
		}
	};

	Frames.View.prototype.isOverlayedWindow = function()
	{
		var $el = Frames.Application.getViewContainer(this);
		return ($el !== undefined);
	};

	Frames.View.prototype.needsTaskContainer = function()
	{
		var $el = Frames.Application.getViewContainer(this);
		if ($el && $el !== Frames.Application._container)
		{
			return true;
		}
		return _refs.needsTaskContainer.apply(this, arguments);
	};

	Frames.Task.prototype.close = function(view)
	{
		this._closing = true;
		_refs.close.apply(this, arguments);
	};

	Frames.Task.prototype.closeView = function(view)
	{
		var task = view.task;
		var tview = task ? task._VIEWS_.get(0) : null;

		var $el = getPanelViewContainer(view);
		if (tview === view && $el && !this._closing)
		{
			if (Frames.isDebugMode())
			{
				this.logger.debug('prevented view \'%s\' from closing', view.id);
			}
		}

		else
		{
			_refs.closeView.apply(this, arguments);

			if (task && task._VIEWS_.indexOf(task.view) === 0 && task._view_container)
			{
				task._view_container.tabs('option', 'active', 0);
			}
		}
	};
}
//# sourceURL=app/flat/widgets/viewcontainer/js/viewcontainer.panel.js
