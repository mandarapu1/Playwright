// Default regional settings - English/US - for the jQuery calculator extension
(function($) { // hide the namespace
	$.calculator.regionalOptions["en"] = {
		decimalChar: ",",
		buttonText: "...", buttonStatus: "Open the calculator",
		closeText: "Close", closeStatus: "Close the calculator",
		useText: "Use", useStatus: "Use the current value",
		eraseText: "Erase", eraseStatus: "Erase the value from the field",
		backspaceText: "BS", backspaceStatus: "Erase the last digit",
		clearErrorText: "CE", clearErrorStatus: "Erase the last number",
		clearText: "CA", clearStatus: "Reset the calculator",
		memClearText: "MC", memClearStatus: "Clear the memory",
		memRecallText: "MR", memRecallStatus: "Recall the value from memory",
		memStoreText: "MS", memStoreStatus: "Store the value in memory",
		memAddText: "M+", memAddStatus: "Add to memory",
		memSubtractText: "M-", memSubtractStatus: "Subtract from memory",
		base2Text: "Bin", base2Status: "Switch to binary",
		base8Text: "Oct", base8Status: "Switch to octal",
		base10Text: "Dec", base10Status: "Switch to decimal",
		base16Text: "Hex", base16Status: "Switch to hexadecimal",
		degreesText: "Deg", degreesStatus: "Switch to degrees",
		radiansText: "Rad", radiansStatus: "Switch to radians",
		isRTL: false};
	$.calculator.setDefaults($.calculator.regionalOptions["en"]);
})(jQuery);