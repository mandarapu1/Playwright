// Initialize communication channel and add the local message handler delegate
function initAppNavIntegration()
{
	// create bogus integration API for debugging
	if (typeof M === 'undefined')
	{
		M = {
			localActivity: false,
			json: JSON,
			start: function() { console.log('APPNAV:start()', arguments); },
			send: function() { console.log('APPNAV:send()', arguments); },
			createStatusMessage: function() { console.log('APPNAV:createStatusMessage()', arguments); return arguments; },
			createRequestMessage: function() { console.log('APPNAV:createRequestMessage()', arguments); return arguments; },
			createNameValuePairMessage: function() { console.log('APPNAV:createNameValuePairMessage()', arguments); return arguments; },
			createActionMessage: function() { console.log('APPNAV:createActionMessage()', arguments); return arguments; },
			createHelpMessageByURL: function() { console.log('APPNAV:createHelpMessageByURL()', arguments); return arguments; },
			initializePollActivity: function() { console.log('APPNAV:initializePollActivity()', arguments); return arguments; },
			createLastPageClosedMessage: function() { console.log('APPNAV:createLastPageClosedMessage()', arguments); return arguments; },
			createDataStateMessage: function() { console.log('APPNAV:createDataStateMessage()', arguments); return arguments; }
		};

		M._DEBUG_ = true;
	}

	M._PAGES_ = new Frames.HashMap();
	M._fulldirty = Frames.Config.getbool('APPNAV_FULL_DIRTY', false);
	M._globalsTimeout = Frames.Config.get('GLOBALS_TIMEOUT', 3000);

	var notifyItemDirtyState = function(item)
	{
		if (item)
		{
			var name = Frames.Application.task.name;
			var p = M._PAGES_.get(name);
			if (p && (!p.changed || p._forced))
			{
				p._forced = true;
				var state = item.hasChanges() || !item.valid();
				if (state !== p.changed)
				{
					notifyDirtyState(name, state);
				}
			}
		}
	};

	Frames.Application.on('viewready', function(ev, result)
	{
		var task = result.task;
		if (task && task !== Frames.Application.getMainTask())
		{
			var name = task.name;
			if (Frames.isUndef(name))
			{
				_$.each(M._PAGES_.values(), function(i, v)
				{
					if (v.id === task.id)
					{
						name = v.name;
						return false;
					}
				});
			}

			var changed = Frames.isTrue(Frames.Model.attr(task.control, 'isChanged'));

			var p = M._PAGES_.get(name);
			if (!Frames.isUndef(p))
			{
				p.changed = changed;
				// update navpage when we're merely navigating between forms (form A opens form B, form B closes and we need to update appnav_page)
				if (name != 'NOQMENU' && !Frames.isUndef(name))
				{
					window._appnav_page = name;
				}
			}
			else
			{
				// TODO: just an NOQMENU hack
				if (name != 'NOQMENU' && !Frames.isUndef(name))
				{
					M._PAGES_.put(name, {id: task.id, name: name, changed: changed});
					confirmPageOpen(name);
				}
			}

			if (M._fulldirty)
			{
				// notify dirty state
				if (!changed)
				{
					var item = Frames.Application.current();
					notifyItemDirtyState(item);
				}
				else
				{
					handleDataStateCheck(M._PAGES_.keys().join(','));
				}
			}
		}

		// Signal activity
		notifyActivity();
	});

	Frames.Application.on('beforetaskclose', function(ev, result)
	{
		// hack for IE
		M._closing = true;

		var task = result.task;
		var tasks = _$.map(Frames.Application._TASKS_, function(o, k) { return k; });

		if (task)
		{
			var name = task.name;
			if (!Frames.isUndef(name))
			{
				// TODO: just an NOQMENU hack
				if (name != 'NOQMENU' && !Frames.isUndef(name) && M._PAGES_.size() > 0)
				{
					M._PAGES_.remove(name);

					notifyPageClose(name);

					if (M._PAGES_.size() === 0 && tasks.length == 2)
					{
						createLastPageClosedMessage();
					}
				}
			}
		}

		delete M._closing;
	});

	//
	// on beforeunload the application exists
	// check if we are still closing task
	//
	var _close = Frames.Application.close;
	Frames.Application.close = function(task)
	{
		if (M._closing)
		{
			return;
		}

		_close();
	};

	if (M._fulldirty)
	{
		//
		// Check if active item has changes
		//
		Frames.Application.on('itemchanged', function(ev, item)
		{
			notifyItemDirtyState(item);
		});
	}

	M.start(localMessageHandler);

	M.heartbeat = 30; // seconds
	if (typeof(M.initializePollActivity) == 'function')
	{
		M.initializePollActivity();
	}
}

function localMessageHandler(message)
{
	// console.log(message);

	// Process Help Requests from applicationNavigator
	if (message.type == 'request' && message.request == 'help')
	{
		var url = Frames.Config.get('APPNAV_HELP_URL', 'about:blank?');
		url += window._appnav_page;

		// Send URL for page help to display
		M.send(M.createHelpMessageByURL(url));
	}

	// Process Navigation Messages from applicationNavigator
	else if (message.type == 'navigate')
	{
		// Handle navigation item under message.appContext
		handleNavigation(message.appContext);
	}

	// Process Data State Messages from applicationNavigator
	else if (message.type == 'request' && message.request == 'dataState')
	{
		if (message.pages !== null && message.pages.trim() !== '')
		{
			handleDataStateCheck(message.pages);
		}
	}

	// Process Global Variable Response from applicationNavigator
	else if (message.type == 'values')
	{
		console.log("BANNER ADMIN DEBUG: In global variable block with msg type values");
		// Store global variables from message.values
		var control = Frames.Application.task.control;
		var body = Frames.Application.task.data;
		
		var command = Frames.findExp(control, 'commands/command');
		if (command)
		{
			var downloads = [];
			var r;
			for (r = 0; r < command.length; r++)
			{
				var CommandName = Frames.Model.attr(command[r], 'name');
				console.log("BANNER ADMIN DEBUG: CommandName is: " + CommandName);

				switch (CommandName)
				{
					case 'GLOBALS':
						var values = JSON.stringify(message.values);
						if(values !== '{}')
						{
							console.log("BANNER ADMIN DEBUG: JSON msg values: " + values);
							var sync = {
								name: 'SYNC_GLOBALS',
								params: [
								{
									name: 'LIST_GLOBALS',
									value: Frames.Model.encode(values, true),
									type: 'String'
								}]
							};

							Frames.Application.execute(sync, undefined, undefined, undefined, undefined, false);
							console.log("BANNER ADMIN DEBUG: SYNC: " + JSON.stringify(sync));
						}
						else
						{
							Frames.Application.execute('UNLOCK_GLOBALS');
						}
						// ES-2959 - Finish globals processing as it is not necessary to execute an UNLOCK_GLOBALS action afterwards
						clearTimeout(M._unlockGlobals);
						break;
				}
			}
		}
	}

	else if (message.type == 'focus')
	{
		Frames.focus();
	}

	else if (message.type == 'keepAlive')
	{
		if (message.keepAlive === true)
		{
			handleKeepAlive();
		}
	}

	// Process workflow requests
	else if (message.type == 'workflow')
	{
		// Handle navigation item under message.appContext
		handleWorkflow(message.appContext);
	}

	// Process signout requests
	else if (message.type == 'signout' || message.type == 'request' && message.request == 'logout')
	{
		Frames.Application.exit();
	}

	// Ignore unexpected message
}

/**
 * Handle navigation messages
 */
/* REQUIRED */
function handleNavigation(navItem)
{
	// check current page for changes
	handleDataStateCheck(Frames.Application.task.name);
	
	// Pass navItem to the server and determine which page to load dynamically.
	// The navItem.page property contains the Oracle Form Name to match.

	var json = {
		type: 'navigate',
		page: navItem.page,
		values: '{}',
		parameters: '{}'
	};
	Frames.Workspace.handleEvent('navigate', M.json.stringify(json), json);
}

function handleWorkflow(navItem)
{
	// Pass navItem to the server to contnue a worflow activity.
	// The navItem.id contains the activity id
	var id = navItem.id;
	Frames.Workspace.processWorkflow(id);
}

function handleLogout()
{
	Frames.Workspace.handleEvent('logout');
}

/**
 * Send confirmation after page open
 * @param {String} page id from applicationNavigator
 */
/* REQUIRED */
function confirmPageOpen(page)
{
	window._appnav_page = page;

	// page == Oracle Form Name, e.g. PPAIDEN
	// console.log('confirmPageOpen: ', page);
	M.send(M.createStatusMessage('opened:' + page)); // Confirm page status first for Oracle form
	M.send(M.createRequestMessage('context')); // Requests context info for current page
	M.send(M.createRequestMessage('globalVariables')); // Requests global variables

	notifyActivity();
}

/**
 * Determines data state of the requested pages and send a message to applicationNavigator
 */
function handleDataStateCheck(openPages)
{
	var pageNamesArray = openPages.split(',');
	var dataStateArray = [];

	for (var i = 0; i < pageNamesArray.length; i++)
	{
		var name = pageNamesArray[i];
		var p = M._PAGES_.get(name);
		if (p)
		{
			// if server didn't report changes check the
			// current change off the page
			if (!p.changed)
            {
                var task = Frames.Application.getTask(p.id);
                var item = task.block && task.block.item ? task.block.item : undefined;
                var state = item ? (item.hasChanges() || !item.valid()) : false;
                if (state !== p.changed)
                {
                    p.changed = true;
                }
            }

			var dataStateItem = {
				page: p.name,
				state: p.changed ? 'dirty' : 'clean'
			};

			if (M._DEBUG_)
			{
				console.log(dataStateItem);
			}

			dataStateArray.push(dataStateItem);
		}
	}

	M.send(M.createDataStateMessage(dataStateArray));
}

function notifyDirtyState(name, state)
{
	var p = M._PAGES_.get(name);
	if (p)
	{
		p.changed = state;
		handleDataStateCheck(M._PAGES_.keys().join(','));
	}
}

/**
 * Send notification before page close
 * @param {String} page id from applicationNavigator
 */
function notifyPageClose(page)
{
	if (page == window._appnav_page)
 {
		delete window._appnav_page;
	}

	// console.log('notifyPageClose: ', page);
	M.send(M.createStatusMessage('closed:' + page));

	notifyActivity();
}

/**
 * Send notification before page close
 * @param {String} page id from applicationNavigator
 */
function notifyActivity()
{
	M.localActivity = true;
	if (Frames.isDebugMode())
	{
		console.log('APPNAV:localActivity: ', M.localActivity);
	}
}

/**
 * Used to notify application Navigator of last page closed activity
 */
function createLastPageClosedMessage()
{
	if (typeof(M.createLastPageClosedMessage) == 'function')
	{
		M.send(M.createLastPageClosedMessage('displayLandingPage'));
	}
}

/**
 * Based on keyboard shortcut or button trigger, send message to open the menu component in applicationNavigator
 */
function sendMainMenuMessage()
{
	M.send(M.createActionMessage('browsemenu'));
}

/**
 * Based on keyboard shortcut or button trigger, send message to open the recent items component in applicationNavigator
 */
function sendItemsMenuMessage()
{
	M.send(M.createActionMessage('openitemsmenu'));
}

/**
 * Based on keyboard shortcut or button trigger, send message to open the search component in applicationNavigator
 */
function sendSearchMessage()
{
	M.send(M.createActionMessage('searchinput'));
}

/**
 * Based on keyboard shortcut or button trigger, send message to show the dashboard in applicationNavigator
 */
function sendDashboardMessage() {
  M.send( M.createActionMessage( 'showDashboard' ) );
}

/**
 * Based on keyboard shortcut or button trigger, send message to log out from the applicationNavigator level
 */
function sendSignoutMessage()
{
	M.send(M.createActionMessage('signout'));
}

function sendAppnavHelpMessage(url)
{
	M.send(M.createHelpMessageByURL(url));
}

function startMagellan() {}
function messageFromMagellan(jsonMessage) {}

// function messageFromBannerOut(data) {}
// function messageFromBannerDirtyStatus(data) {}
function messageFromBannerBrowseMainMenu() { sendMainMenuMessage(); }
function messageFromBannerOpenedForm(data) {}
function messageFromBannerClosedForm(data) {}
// function messageFromBannerOpenAppMainMenu() {}
// function messageFromBannerSearchMainMenu() {}
function messageFromBannerSignOut() {}
function messageFromBannerHelpMainMenu() {}


//# sourceURL=app/flat/js/appnav.js
