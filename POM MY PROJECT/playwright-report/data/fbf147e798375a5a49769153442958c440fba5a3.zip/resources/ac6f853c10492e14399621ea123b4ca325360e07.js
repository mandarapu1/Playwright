{

var workspaceheaderExtensions = {
	_oldTitle: _$.workspace.workspaceheader.prototype.title,
	title: function(str)
	{
		str = App.processTitleString(str);
		this._oldTitle(str);
		Frames.Application.trigger('titlechanged');
	},
	_oldRefreshTitle: _$.workspace.workspaceheader.prototype.refreshTitle,
	refreshTitle: function(view)
	{
		var $viewContainer = Frames.Application.getViewContainer(view);
		if (!($viewContainer && $viewContainer.is(".ui-panel-view-container")))
		{
			this._oldRefreshTitle(view);
		}
		else
		{
			// restore main window title
			var vw = Frames.Application.task._VIEWS_.get(0);
			this._oldRefreshTitle(vw);
		}
	},

	_oldClearTitle: _$.workspace.workspaceheader.prototype.clearTitle,
	clearTitle: function(view)
	{
		var $viewContainer = Frames.Application.getViewContainer(view);
		if (!($viewContainer && $viewContainer.is(".ui-panel-view-container")))
		{
			this._oldClearTitle(view);
		}
	}
};

_$.extend(_$.workspace.workspaceheader.prototype, workspaceheaderExtensions);

var viewExtension = {
	_setTitle: _$.noop,

	_oldTitle: Frames.View.prototype.title,
	title: function()
	{
		// getter
		if (arguments.length === 0)
		{
			if (this._title)
			{
				return this._title;
			}

			return '';
		}

		// setter
		else
		{
			this._oldTitle(arguments[0]);
		}
	}
};
_$.extend(Frames.View.prototype, viewExtension);

};

//# sourceURL=app/flat/widgets/workspace/js/workspace.header.js
