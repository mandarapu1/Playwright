{
	// the widget definition, where 'workspace' is the namespace,
	// 'workspaceheader' the widget name
	_$.widget('workspace.workspaceheader',
	{

		// default options
		options: {
			template_main: '/base/widgets/workspace/html/workspace.tmpl.html#workspace-header-template',
			template_items: '/base/widgets/workspace/html/workspace.tmpl.html#workspace-items-template',
			template_keys: '/base/widgets/workspace/html/workspace.tmpl.html#workspace-keys-template',
			container: document.body,

			plugins: [],

			close: {
				visible: true,
				icon: 'fa fa-times',
				tooltip: _('GO_TO_CLOSE'),
				action: 'EXIT'
			},

			title: {
				visible: true
			},

			items: {
				left: [
					{id: 'menu-toggle', class: 'workspace-menu-toggle', target: 'menu', shortcut: 'alt+ctrl+m', icon: 'fa fa-bars'},
					{id: 'opened-toggle', class: 'workspace-task-toggle', target: 'menu-tasks', shortcut: 'alt+ctrl+o', icon: 'fa fa-folder-open'},
				],
				right: [
					{id: 'notifications', class: 'notification-item'},
					{id: 'related-tools', target: 'menu-tools', shortcut: 'alt+ctrl+t', icon: 'fa fa-cog', label: _('TOOLS')}
				]
			}
		},

		// the constructor
		_create: function()
		{
			var that = this;

			this._isRTL = this.element.css('direction') === 'rtl';

			var appsroot = Frames.Config.get('APPS_ROOT', '.');
			var url_main = Frames.parseUrl(appsroot + this.options.template_main);
			var url_items = Frames.parseUrl(appsroot + this.options.template_items);
			var url_keys = Frames.parseUrl(appsroot + this.options.template_keys);

			// create a recursive template {{##def.items:list: ... #}}

			this.templates = {};

			Frames.Template.gettext(url_items, function(_items_tpl) {
				var items_tpl = function(param) {
					return {
						arg: param,
						text: _items_tpl
					};
				};

				Frames.Template.get(url_main, { items: items_tpl('list'), items_: items_tpl('list_') }, function(result)
				{
					that.templates.main = result;
					that._afterTemplate();
				});
				Frames.Template.get(url_keys, function(result)
				{
					that.templates.keys = result;
				});
			});
		},

		_afterTemplate: function()
		{
			var that = this;

			this._refresh();

			_$('.workspace-close', this.element).on('click', function()
			{
				Frames.Application.valexec('EXIT');
				Frames.Application.trigger('handleclosetask');
				return false;
			});

			this.$tasks = _$('.workspace-task-toggle', this.element);
			if (this.$tasks.length > 0)
			{
				this.$tasks_menu = _$(this.$tasks.data('target'));
			}

			this.$title = _$('.workspace-title', this.element);
			this.$close = _$('.workspace-close', this.element).hide();

			Frames.Application.on('viewready taskopen', function(ev, result)
			{
				if (!Frames.Application.isWorkspaceView(result.view))
				{
					if (Frames.isUndef(result.view))
					{
						result.view = result.task.view;
					}

					if (!result.view.modal)
					{
						that.showclose(true);
					}

					that.refreshTitle(result.view);

					if (ev.type == 'viewready')
					{
						that._refresh_tasks();
					}
				}
				else
				{
					var tasks = _$.map(Frames.Application._TASKS_, function(o, k) { return k; });
					if (tasks.length === 1)
					{
						that.showclose(false);
						that.clearTitle(result.view);
					}
				}
			});

			Frames.Application.on('closetask opentask', function(ev, result)
			{
				that.taskCounter();
			});

			Frames.Application.on('viewclose', function(ev, result)
			{
				if (Frames.isUndef(result.view))
				{
					result.view = result.task.view;
				}

				var isInWorkspaceTask = Frames.Application.mainTask.id == Frames.Application.task.id;
				if (isInWorkspaceTask)
				{
					that.showclose(false);
					that.clearTitle(result.view);
				}
				else
				{
					if (Frames.Application.task._VIEWS_.length > 0)
					{
						that.refreshTitle(Frames.Application.task._VIEWS_.get(0));
					}
				}

				that._refresh_tasks();
			});
			this._initializeClick();

			_$(window).on('resize themeswitch', function()
			{
				that._update();
			});

			if (!Frames.isUndef(Frames.Workspace._workspaceReady))
			{
				Frames.Workspace._workspaceReady.header = true;
			}

			if (Frames.isFunction(this.options.onready))
			{
				this.options.onready();
			}
		},

		_initializeClick: function()
		{
			var that = this;

			_$('a[data-action]', this.element).on('click', function()
			{
				// close dropdown menu that is open if exists
				that.element.find('li.dropdown.open > a').dropdown('toggle');

				var $el = _$(this);

				that.element.find('li.dropdown.open > a').dropdown('toggle');

				Frames.Application.valexec($el.data('action'));
				return false;
			});
		},

		// events bound via _on are removed automatically
		// revert other modifications here
		_destroy: function()
		{
			// ...
		},

		_refresh_tasks: function()
		{
			var that = this;

			if (this.$tasks.length === 0)
			{
				return;
			}

			var items = [];
			_$.each(Frames.Application._TASKS_, function(k, task)
			{
				var view = task.getView(0);
				if (view && !Frames.Application.isWorkspaceView(view))
				{
					items.push({
						id: k,
						label: task.title || task.name
					});
				}
			});

			this.$tasks_menu.verticalmenu('option', 'click', function(it)
			{
				if (it.id)
				{
					var task = Frames.Application._TASKS_[it.id];
					if (task)
					{
						task.focus();
						// TODO: shouldn't this be on the focus method?
						Frames.Application._showTask(task.id);
					}
					that.$tasks_menu.verticalmenu('close', true);
				}
			});
			this.$tasks_menu.verticalmenu('option', 'items', items);
		},

		// called when created, and later when changing options
		// and menu methods
		_refresh: function()
		{
			var that = this;

			if (!this.templates.main)
			{
				return;
			}

			if (!this._initialized)
			{
				this._initialized = true;

				_$.workspace.verticalmenu.prototype._apply_shortcuts(this.options.items ? this.options.items.left : []);
				_$.workspace.verticalmenu.prototype._apply_shortcuts(this.options.items ? this.options.items.right : []);

				var arr = [this.options.close];
				_$.workspace.verticalmenu.prototype._apply_shortcuts(arr);
				this.options.close = arr[0];

				var tmplOptions = _$.extend({}, this.options.items, { rtl: this._isRTL, close: this.options.close, title: this.options.title});
				var html = this.templates.main(tmplOptions);
				this.element.html(html);

				this.$titlep = _$('<p class="print-title"></p>');
				this.element.after(this.$titlep);

				// call all plugins if exist
				_$.each(this.options.plugins, function()
				{
					var plug = this;

					if (_$.isFunction(plug))
					{
						plug(that);
					}
				});

				_$('[data-widget]', this.element).each(function()
				{
					var $el = _$(this);
					var widget = $el.data('widget');
					if (widget)
					{
						$el[widget]();
					}
				});
			}
		},

		showclose: function(flag)
		{
			if (!this.options.close.visible)
			{
				return false;
			}

			var $li = this.$close.closest('li');
			if (flag)
			{
				$li.show();
				this.$close.show();
			}
			else
			{
				this.$close.hide();
				$li.hide();
			}

			this._update();
		},

		_update: function()
		{
			var $li = this.$title.closest('li');
			if ($li.length === 0)
				return;

			var $menus = _$('.navbar-menus > .navbar-right', this.element);

			if (this._isRTL)
			{
				this.$title.css({
					left: $menus[0].offsetWidth,
					right: $li.offsetParent()[0].offsetWidth - Math.floor($li.position().left) - $li[0].offsetWidth
				});
			}
			else
			{
				this.$title.css({
					left: Math.floor($li.position().left),
					right: $menus[0].offsetWidth
				});
			}
		},

		title: function(str)
		{
			if (this._last !== str)
			{
				Frames.Workspace.arianotify(str);
				this.$title.html(str);
				this.$titlep.html(str);
			}
			this._last = str;
			this.$title.attr('title', str)
		},

		refreshTitle: function(view)
		{
			if (!view.modal)
			{
				this.title(view.title());
			}
		},

		taskCounter: function()
		{
			if (Frames.Application._TASKS_)
			{
				var nTasks = Object.keys(Frames.Application._TASKS_).length;
				nTasks = nTasks - 1; //remove main task
				var menuTask = _$('#opened-toggle > a');
				menuTask.attr('data-count', nTasks);

				if (nTasks > 0)
				{
					menuTask.addClass('count-badge');
				}
				else
				{
					menuTask.removeClass('count-badge');
				}
			}
		},

		clearTitle: function(view)
		{
			if (!(view.modal && view.task._VIEWS_.size() === 1))
			{
				this.title('');
			}
		},

		keysdialog: function()
		{
			if (this._keysdialog === undefined)
			{
				var tmplOptions = _.extend({}, this.options.items, { rtl: this._isRTL });
				var html = this.templates.keys(tmplOptions);
				_$(this.options.container).append(html);

				this._keysdialog = _$('#workspace-keys').modal({show: false});
			}

			this._keysdialog.modal('show');
		}
	});

	var _whDefaults = _$.workspace.workspaceheader.prototype.options;
	_$.workspace.workspaceheader.setup = function(options)
	{
		if (!options)
		{
			return;
		}

		var opts = _$.extend(true, {}, _whDefaults);

		if (options.items)
		{
			if (options.items.left !== undefined)
			{
				if (options.items.left === null)
				{
					opts.items.left = [];
				}
				else
				{
					opts.items.left = options.items.left;
				}
			}
			if (options.items.right !== undefined)
			{
				opts.items.right = options.items.right;
			}
		}

		if (options.template)
		{
			opts.template = options.template;
		}

		if (options.template_main)
		{
			opts.template_main = options.template_main;
		}

		if (options.template_keys)
		{
			opts.template_keys = options.template_keys;
		}

		if (options.template_items)
		{
			opts.template_items = options.template_items;
		}

		if (options.close)
		{
			_$.extend(opts.close, options.close);
		}

		if (options.title)
		{
			_$.extend(opts.title, options.title);
		}

		if (options.plugins)
		{
			opts.plugins = options.plugins;
		}

		_$.workspace.workspaceheader.prototype.options = opts;
		return opts;
	};

};

//# sourceURL=app/base/widgets/workspace/js/workspace.header.js
