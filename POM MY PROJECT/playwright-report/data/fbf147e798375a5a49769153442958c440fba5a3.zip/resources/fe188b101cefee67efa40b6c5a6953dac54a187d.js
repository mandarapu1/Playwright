// entrypoint for all integrations

var integrationMode = Frames.Config.get('INTEGRATION_MODE');
if (integrationMode == 'EXPERIENCE')
{
    // experience code

    var appsroot = Frames.Config.get('APPS_ROOT', '.');

    var mJsUrl = appsroot + '/flat/js/m.js';

    _$.ajax({
        url: mJsUrl,
        success: function(data, textStatus, jqXHR)
        {
            if (Frames.isDebugMode())
            {
                Frames.Log.debug('[EXPERIENCE] Success loading integration API.');
            }
            initExperienceIntegration();
        },
        error: function()
        {
            if (Frames.isDebugMode())
            {
                Frames.Log.error('EXPERIENCE] Error loading integration API.');
            }        
        }
    });

    /* Frames.loadjs(mJsUrl,
        // on success
        function()
        {
            if (Frames.isDebugMode())
            {
                Frames.Log.debug('[EXPERIENCE] Success loading integration API.');
            }
            initExperienceIntegration();
        },
        // on error
        function()
        {
            if (Frames.isDebugMode())
            {
                Frames.Log.error('EXPERIENCE] Error loading integration API.');
            }
        }
    );*/
}
else
{
    // default to AppNav integration

    // try to load automatcly appnav integration javascript
    if (window !== window.top && !Frames.isEmpty(document.referrer))
    {
        var referrer = document.referrer;

        // skip protocol
        var p1 = referrer.indexOf('/', 8);
        var p2 = referrer.indexOf('/', p1 + 1);
        if (p2 == -1)
        {
            p2 = referrer.length;
        }
        var appnavurl = Frames.Config.get('APPNAV_API_URL') ? Frames.Config.get('APPNAV_API_URL') : referrer.substring(0, p2) + '/static/dist/m.js';

        if (Frames.isDebugMode())
        {
            Frames.Log.debug('[APPNAV] IFRAME detected. Trying to load \'%s\'.', appnavurl);
        }

        Frames.loadjs(appnavurl,
            // on success
            function()
            {
                if (Frames.isDebugMode())
                {
                    Frames.Log.debug('[APPNAV] Success loading application navigator API.');
                }
                initAppNavIntegration();
            },
            // on error
            function()
            {
                if (Frames.isDebugMode())
                {
                    Frames.Log.error('[APPNAV] Error loading application navigator API.');
                }
                initAppNavIntegration();
            }
        );
    }
    else
    {
        if (Frames.isDebugMode())
        {
            Frames.Log.info('[APPNAV] No IFRAME detected. No application navigator API will be loaded.');
        }
        initAppNavIntegration();
    }

}

function sendGlobals(globals)
{
	if (integrationMode == 'EXPERIENCE')
	{
        M.send(customMessage('globals', globals));
	}
    else
    {
        M.send(M.createNameValuePairMessage(globals));
    }
}

function handleKeepAlive()
{
	var surl = Frames.Service.SERVICE_URL;
	// App domain. Get string until '/' ignoring the fisrt char
	var app =  surl.match(/.+?(=?\/)/);
	app = app ? app[0] : '/';
	var url = app + 'session/check';
	$.get(url, null, function(data, textStatus, jqXHR)
	{
		if (Frames.isDebugMode())
		{
			Frames.Log.info('Server ALIVE:', data);
		}
	}, 'text');
}

function showHelpPage() {
    var url = Frames.Config.get('APPNAV_HELP_URL', 'about:blank?');
    if (integrationMode == 'EXPERIENCE')
	{
        url += getExperienceProp('currentHelpPage');

        // Send URL for page help to display
        sendHelpMessage(url);
    }
    else
    {
        url +=  window._appnav_page;

		// Send URL for page help to display
        sendAppnavHelpMessage(url);
    }
}

//# sourceURL=app/flat/js/integration.js