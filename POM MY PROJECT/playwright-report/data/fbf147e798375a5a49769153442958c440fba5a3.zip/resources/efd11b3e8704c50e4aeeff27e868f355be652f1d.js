_$.widget('ui.datefield',
{
	version: '@VERSION',

	options:
	{
		button: true,
		grid: false,
		inline: false,
		onSelect: undefined
	},

	_create: function()
	{
		this.element.addClass('ui-datefield ui-widget ui-buttoninput');

		if (!this.options.inline)
		{
			this._lbl = $('label', this.element);
			this._inp = $('input', this.element); /*.remove().attr("type", "date").insertBefore(this._lbl);*/

			// datepicker needs diferent IDs
			this._inp.attr('id', this.element.attr('id') + new Date().getTime());
			this._lbl.attr('for', this._inp.attr('id'));

			if (Frames.isEmpty(this._lbl.attr('id')))
			{
				this._lbl.attr('id', 'l:' + this._inp.attr('id'));
			}
			this._inp.attr('aria-labelledby', this._lbl.attr('id'));

			this._inp.addClass('ui-widget-content');

			this._inp.attr('aria-owns', 'multiCalendarContainer');

			var that = this;
			this.element.on('keydown', function(e)
			{
				if ((e.which === $.ui.keyCode.DOWN || e.which === $.ui.keyCode.UP) && e.altKey)
				{
					that.button.triggerHandler('click');
				}

				if ($.multicalendar._isCalendarShown)
				{
					return false;
				}
			});

		}

		if (this.options.grid || this.options.inline)
		{
			this.initialize();
		}
	},

	initialize: function()
	{
		this.refresh();
	},

	_initialize: function()
	{
		if (this._initialized)
		{
			return;
		}

		var self = this;

		var frm = this.element.data('format');
		if (Frames.isUndef(frm) || !Frames.Format.isValidFormat(frm, 'Date') || frm === '')
		{
			frm = Frames.Locale.formats.DATE_FORMAT || 'dd/mm/yy';
		}

		var lang = Frames.Locale.lang;
		var formats = this._convertFormats(frm, lang);
		var dateformat = formats.dateFormat;
		var converters = this._getConverters(Frames.Locale, dateformat);

		var defaultFirstDayOfTheWeek = Frames.Locale.formats.FIRST_DAY_OF_THE_WEEK ? Frames.Locale.formats.FIRST_DAY_OF_THE_WEEK : 0;

		var onSelect = this.options.onSelect ?  $.proxy(this.options.onSelect, this) : $.proxy(this._onSelect, this);

		var ranges = {
			 'gregorian': 'c-100:c+100',
			 'islamic': 'c-100:c+100',
			 'jalali': 'c-100:c+100',
			 'Hebrew': 'c-100:c+100',
			 'ummalqura': 'c-50:c+50'
		};

		var options = {
			converters: converters,
			defaultDateFormat: dateformat,
			displayDateFormat: dateformat,
			onSelect: onSelect,
			yearRange: ranges[Frames.Locale.formats.DEFAULT_CALENDAR],
			firstDayOfTheWeek: defaultFirstDayOfTheWeek
		};

		if (formats.timeFormat)
		{
			options.timeFormat = formats.timeFormat;
			options.showTime = true;
		}

		if (this.options.inline)
		{	options.buttonClass =  '';
			options.showOn =  'focus';
			options.modal = true;
			options.autoSize = true;

			this.element.multiCalendarPicker(options);
		}
		else
		{
			this._inp.multiCalendarPicker(options);
			this.button = this.element.find('button');

			if (Frames.Locale.formats.IS_RTL && !Frames.Locale.formats.DATE_IS_RTL)
			{
				this._inp.attr('dir', 'ltr');
				this.button.attr('dir', 'ltr');
			}

			if (this.showButton())
			{
				this._inp.removeClass('ui-corner-all')
					.addClass('ui-corner-left');

				// add theme to button
				this.button
					.attr('tabIndex', -1)
					.button({
						icon: 'fa fa-calendar',
						text: false,
						classes: {
							'ui-button': 'ui-state-default'
						}
					})
					.attr('title', null)
					.attr('aria-label', _('CALENDAR'))
					.removeClass('ui-corner-all')
					.addClass('ui-corner-right ui-button-icon ui-button-icon-only');

				// Disable button double click to avoid the modal opening
				this.button.on('dblclick', function(e)
				{
					e.preventDefault();
					e.stopImmediatePropagation();
				});

				this.button.on('click', function()
				{
					var activeCalendar = $('#' + $.multicalendar.calendarIdPrefix + $.multicalendar.activeCalendar);
					var selectedDay = activeCalendar.find('a.' + $.calendarsPicker.themeRollerRenderer.selectedClass);
					// if no day is selected, selects today
					if (selectedDay.length == 0)
					{
						selectedDay = activeCalendar.find('a.' + $.calendarsPicker.themeRollerRenderer.todayClass);
					}
					selectedDay.addClass('ui-state-hover');
				});
			}
			else
			{
				this.button.hide();
			}
		}

		this._initialized = true;
	},

	_getConverters: function(locale, dateformat)
	{
		var lang = locale.lang;
		if (locale.formats.CALENDARS && locale.formats.CALENDARS.length > 1)
		{
			// TODO: make this generic, for now assume only possible calendars are gregorian and islamic
			return {
				gregorianToIslamic: {
					format: {
						url: 'dateConverter',
						nameOfDateParam: 'date',
						extraParams: {
							test: 'dummyString',
							fromDateFormat: dateformat,
							toDateFormat: dateformat,
							toULocale: lang + '@calendar=islamic',
							fromULocale: lang + '@calendar=gregorian'
						}
					}
				},

				islamicToGregorian: {
					format: {
						url: 'dateConverter',
						nameOfDateParam: 'date',
						extraParams: {
							test: 'dummyString',
							fromDateFormat: dateformat,
							toDateFormat: dateformat,
							toULocale: lang + '@calendar=gregorian',
							fromULocale: lang + '@calendar=islamic'
						}
					}
				},

				gregorianToUmmalqura: {
					format: {
						url: 'dateConverter',
						nameOfDateParam: 'date',
						extraParams: {
							test: 'dummyString',
							fromDateFormat: dateformat,
							toDateFormat: dateformat,
							toULocale: lang + '@calendar=ummalqura',
							fromULocale: lang + '@calendar=gregorian'
						}
					}
				},

				ummalquraToGregorian: {
					format: {
						url: 'dateConverter',
						nameOfDateParam: 'date',
						extraParams: {
							test: 'dummyString',
							fromDateFormat: dateformat,
							toDateFormat: dateformat,
							toULocale: lang + '@calendar=gregorian',
							fromULocale: lang + '@calendar=ummalqura'
						}
					}
				}
			};
		}

		return null;
	},

	showButton: function()
	{
		var btn = this.element.data('button');
		return this.options.button && (Frames.isUndef(btn) || btn != 'hide');
	},

	// fix input and button sizes
	refresh: function(force)
	{
		this._initialize();

		if (this.showButton())
		{
			if (force || (this._inp.is(':visible')/* && Frames.isUndef(this._size)*/))
			{
				var w = this._inp.outerWidth();
				var h = this._inp.outerHeight();

				if (Frames.isUndef(this._size))
				{
					this._size = this._inp.outerHeight();
					w = Frames.isTrue(this.options.grid) ? this._inp.outerWidth() - this._size : this._inp.outerWidth() //removed since some calendars are initialized later due to tabpanels visibility
					h = this._size;
				}

				var css =  {};
				if (this.options.grid)
				{
					css.right = 0; // -this._size;
				}
				else
				{
					css.left = '';
				}
				this.button.css({
					width: this._size,
					height: Frames.isTrue(this.options.grid) ? this.element.parent().outerHeight() - 2 : h
				});

				if (true /*this._lbl.index() >= 1*/ || Frames.isTrue(this.options.grid))
				{
					this.button.css(css);
				}
				this._inp.css('width', w);
			}
		}
	},
	destroy: function()
	{
		this._destroy();
	},
	_destroy: function()
	{
		if (this.showButton())
		{
			this._inp.removeClass('ui-corner-left').addClass('ui-corner-all');

			// restore original width to the input field
			if (this.button)
			{
				var targetWidth = this._inp.outerWidth() + this.button.outerWidth();
				var attemptedWidth = targetWidth;
				this.button.remove();
				this._inp.outerWidth(targetWidth);
	
				// HACK to deal with the fact that the first assignment didn't set the target value
				// (I believe it's due to the box-sizing model being set to border-box)
				while (this._inp.outerWidth() < targetWidth)
				{
					// prevent infinit loop and just test maximum 5 times
					if (attemptedWidth > targetWidth + 5)
					{
						break;
					}
					this._inp.outerWidth(attemptedWidth++);
				}
				delete this.button;
			}
		}

		this.element.removeClass('ui-calendar ui-datefield ui-widget hasMultiCalendarPicker ui-buttoninput ui-corner-left');
		// XXX: destroy multidatepicker! But how?
		Frames.MultiDateField.hideWidget();
		this._inp.removeClass('ui-widget-content ui-corner-left');
		this._inp.data('frames', null);
		if (this._inp.length > 0)
		{
			this._inp[0].isInstantiated = false;
		}
		this._inp = null;
		this._lbl = null;
		delete this._inp;
		delete this._lbl;
		delete this._initialized;
	},

	wrapper: function(obj)
	{
		// TODO: think a better way to link to the main object
		this._inp.data('frames', obj);
	},

	input: function()
	{
		return this._inp;
	},

	value: function()
	{
		return this._inp.val.apply(this._inp, arguments);
	},

	setDescriptionContext: $.ui.textinput.prototype.setDescriptionContext,

	label: function()
	{
		if (arguments.length > 0)
		{
			this._lbl.text(arguments[0]);
		}
		else
		{
			return this._lbl.text();
		}
	},

	labelObj: function()
	{
		return this._lbl;
	},

	buttonObj: function()
	{
		// jquery 1.10+ return widget object or initialize it
		return this.button ? this.button.button(): null;
	},

	focus: function()
	{
		// Don't focus the input if widget is open in a modal because it changes the widget position
		if (this.design() || Frames.MultiDateField.isModalOpen())
		{
			return;
		}

		if (document.activeElement != this._inp[0])
		{
			//this._inp.focus();
			this._inp.trigger('select');
		}
	},

	design: function()
	{
		var wrap = this._inp.data('frames');
		return wrap ? wrap.design() : Frames.inDesignMode;
	},

	format: function(frm)
	{
		var inst = this._inp[0];

		if (inst && inst.settings)
		{
			var lang = Frames.Locale.lang;
			var formats = this._convertFormats(frm, lang);
			var dateformat = formats.dateFormat;
			var converters = this._getConverters(Frames.Locale, dateformat);

			var options = _$.extend({}, inst.settings, {
				converters: converters,
				defaultDateFormat: dateformat,
				displayDateFormat: dateformat
			});

			if (formats.timeFormat)
			{
				options.timeFormat = formats.timeFormat;
				options.showTime = true;
			}
			else
			{
				options.showTime = false;
			}

			inst.settings = options;
		}
	},

	openDialog: function()
	{
		if (!this.isDialogOpened())
		{
			$.multicalendar._showCalendar(this._inp);
		}
	},

	closeDialog: function()
	{
		if (this.isDialogOpened())
		{
			$.multicalendar._hideCalendar(this._inp);
		}
	},

	isDialogOpened: function()
	{
		return $.multicalendar._isCalendarShown && this._inp && $.multicalendar._currentObj[0] === this._inp[0];
	},

	_convertFormats: function(frm, language)
	{
		return Frames.MultiDateField.convertToWidgetFormats(frm);
	},

	_onSelect: function(date, inst, cdate)
	{
		var grid = Frames.isTrue(this.options.grid);

		if (grid && !$.multicalendar._isCalendarShown)
		{
			return;
		}

		var f = new (Frames.Config.get('DATE_DEFAULT_FORMATTER', Frames.FormatDate, true))();

		// MCA: 2013/08/12 now for grid this._inp.data("frames") works.
		// var item = grid ? this._inp.parent().data("frames") : this._inp.data("frames");
		var item = this._inp.data('frames');

		if (Frames.isUndef(item) && grid)
		{
			item = this._inp.parent().data('frames');
		}

		if (Frames.isUndef(item))
		{
			return;
		}

		// get actual selected date and not the one present in the input because it can be masked (eg: by $.inputmask)
		var v = $.trim(date);

		// var format = item.props('format');
		// v  = f._format(v, informat, format);
		item.value(v);
		if (cdate)
		{
			var dt = cdate.toJSDate();
			var options = { allowedKeywords: Frames.Item.getAllowedKeywords(item) };
			v = Frames.Format.format(dt, item.props('format'), 'Date', options);
			item.value(v);
			item.ovalue(dt);
		}

		// reset format changed in jquery.multi.calendar.picker.js@_registerEvents()
		if (inst && inst.settings)
		{
			inst.settings.displayDateFormat = inst.settings.defaultDateFormat;
		}

		if (grid)
		{
			item.input().val(v);
		}

		// clear existing validation errors
		Frames.Validation.reset(item);

		this.focus();
		// TODO: this is a bit overkill, find a way to trigger if the value was actually changed
		item.input().trigger('change');

		this.button.attr('title', date);

		this.selectedHandler(date);
	},

	selectedHandler: function(date)
	{
		if (Frames.isDebugMode())
		{
			Frames.Log.debug('datefield:selectedHandler %s', date);
			Frames.Log.debug('datefield:selectedHandler _inp.val() =%s', this._inp.val());
		}

		Frames.Application.elemexec(this.element);
	}
});

Frames.MultiDateField = _$.inherit(
	Frames.DateField,
	{
		fixRtl: $.noop,
		updateshortcut: $.noop,

		init: function(view)
		{
			Frames.DateField.prototype.init.apply(this, arguments);

			this._call('initialize');

			Frames.DateField.prototype.fixRtl.apply(this, [view]);
			Frames.DateField.prototype.updateshortcut.apply(this);

			this.updateshortcut = Frames.DateField.prototype.updateshortcut.bind(this);
		},

		widgetcls: function()
		{
			return 'datefield';
		},
	},

	{
		convertToWidgetFormats: function(frm, flags)
		{
			if (Frames.isUndef(flags))
			{
				flags = {};
			}

			if (!Frames.isUndef(frm))
			{
				if ($.isPlainObject(frm))
				{
					if (!Frames.isUndef(frm.dateFormat) || !Frames.isUndef(frm.timeFormat))
					{
						return frm;
					}

					frm = (!Frames.isUndef(frm.dateFormat) ? frm.dateFormat : '') + (!Frames.isUndef(frm.timeFormat) ? (' ' + frm.timeFormat) : '');
				}

				frm = Frames.FormatMultiDate.prototype._separateFormat(frm.toUpperCase().replace(/\s+/g, ' '));
				var dateFormat = frm.dateValue;
				var timeFormat = frm.timeValue;

				if (dateFormat)
				{
					dateFormat = dateFormat.replace(/Y/g, 'y');
					dateFormat = dateFormat.replace(/R/g, 'y');
					dateFormat = dateFormat.replace(/D/g, 'd');

					dateFormat = dateFormat.replace(/([^D]|^)DY/gi, function(match, $1){
						return  $1 + 'D';
					});

					dateFormat = dateFormat.replace(/DAY/gi, 'DD');

					if (/M{3,5}/.test(dateFormat))
					{
						if (flags.localized)
						{
							dateFormat = dateFormat.replace('MMMMM', 'MMMM');
						}
						else
						{
							dateFormat = dateFormat.replace('MMMMM', 'MM');
							dateFormat = dateFormat.replace('MMMM', 'MM');
							dateFormat = dateFormat.replace('MMM', 'M');
						}
					}
					else if (/MON/.test(dateFormat))
					{
						if (flags.localized)
						{
							dateFormat = dateFormat.replace('MONTH', 'MMMM');
							dateFormat = dateFormat.replace('MON', 'MMM');
						}
						else
						{
							dateFormat = dateFormat.replace('MONTH', 'MM');
							dateFormat = dateFormat.replace('MON', 'M');
						}
					}
					else
					{
						dateFormat = dateFormat.replace(/M/gi, 'm');
					}
				}

				if (timeFormat)
				{
					timeFormat = timeFormat.replace(/H/g, 'h');
					timeFormat = timeFormat.replace(/hh24/gi, 'HH');
					timeFormat = timeFormat.replace(/hh12/gi, 'hh');
					timeFormat = timeFormat.replace(/J/g, 'h');
					timeFormat = timeFormat.replace(/N/g, 'm');
					timeFormat = timeFormat.replace('MI', 'mm');
					timeFormat = timeFormat.replace('MM', 'mm');
					timeFormat = timeFormat.replace(/S/g, 's');
					timeFormat = timeFormat.replace(/AM/gi, 'a');
					timeFormat = timeFormat.replace(/PM/gi, 'a');
					timeFormat = timeFormat.replace(/A/gi, 'a');
				}

				return {
					dateFormat: dateFormat,
					timeFormat: timeFormat
				};
			}

			return {};
		},

		hideWidget: function()
		{
			if ($.multicalendar._isCalendarShown)
			{
				// Using the multicalendar API doesn't work in IE10..
				// $.multicalendar._hideCalendar($.multicalendar._currentObj);
				$('#' + $.multicalendar.calendarContainer).hide();
			}
		},

		isModalOpen: function()
		{
			var modal = $('#' + $.multicalendar.calendarContainer).hasClass('widget-inline');
			return Frames.isTrue($.multicalendar._isCalendarShown) && modal;
		},

		openInDialog: function(currvalue)
		{
			var $container = $('<div id="widget-dialog" title="Calendar"></div>');

			var closeCallback = function()
			{
				$('.modal-backdrop').remove();
				$container.remove();
			};


			$container.appendTo('body');

			$container.datefield({
				button: false,
				grid: false,
				inline: true,
				onSelect: function()
				{
					Frames.MultiDateField._onWidgetClose(true, closeCallback);
				}
			});

			var containerElem = $container[0];

			$(containerElem).val(currvalue);

			$.multicalendar.currentDateBoxValue = Frames.Application.current().value();
			$.multicalendar._createDatePickerDOMStructure(containerElem);
			$.multicalendar._addCalendarsToDOM(containerElem);
			$.multicalendar._showDateInCalendar(containerElem);
			$.multicalendar._showCalendar(containerElem);

			$.multicalendar._hideCalendar = function()
			{
				$.multicalendar._hideCalendarOrig.apply($.multicalendar);
				Frames.MultiDateField.hideWidget();
				Frames.MultiDateField._onWidgetClose(false, closeCallback);
			};

			var $widget = $('#' + $.multicalendar.calendarContainer);

			var top = ($(window).height() / 2) - ($widget.height() / 2) + 'px';
			var left = ($(window).width() / 2) - ($widget.width() / 2) + 'px';

			var css = {
				top: top
			};

			if (Frames.Locale.formats.IS_RTL)
			{
				css.right = left;
			}
			else
			{
				css.left = left;
			}

			$widget.css(css);
			$widget.addClass('widget-inline');

			$container.modal(
            {
				keyboard: false,
			});
		},

		_onWidgetClose: function(success, callback) {

			var payload;

			if (success)
			{
				var cvalue = $('#widget-dialog').datefield().val();

				var format = Frames.MultiDateField.convertToWidgetFormats(Frames.Locale.formats.DATE_FORMAT).dateFormat;

				var canonicalValue = Frames.Format.formatToCanonical(cvalue, format, 'Date');

				payload = {
					name: 'WIDGET_OK',
					params: [{
						name: 'value',
						value: canonicalValue,
						type: 'String'
					}]
				};

			}
			else
			{
				payload = {
					name: 'WIDGET_CANCEL'
				};
			}

			Frames.Application.execute(payload, null, null, null, null, false);

			if (callback)
			{
				callback();
			}
		}

	}
);

$.multicalendar._hideCalendarOrig = $.multicalendar._hideCalendar;

Frames.Application.on('execute', function(ev, result)
{
	Frames.MultiDateField.hideWidget();
});

$(window).on('resize', function(ev)
{
	if (!Frames.isTrue(Frames.MultiDateField.isModalOpen()) && (ev.target == document))
	{
		Frames.MultiDateField.hideWidget();
	}
});

document.addEventListener('scroll', function(ev)
{
	// HACK this event is called every time user clicks on a item in Firefox.
	// Hide the widget if the target element really hhave a scrollbar
	if (ev.target.scrollHeight > $(ev.target).height() && !Frames.isTrue(Frames.MultiDateField.isModalOpen()))
	{
		Frames.MultiDateField.hideWidget();
	}
}, true);

String.prototype.initCap = function() {
	return this.toLowerCase().replace(/(?:^|\s)[a-z]/g, function(m) {
		return m.toUpperCase();
	});
};


Frames.convertCalendarDate = function(data) {

	var fromCal = data.fromULocale.split('=')[1];
	if (!fromCal)
	{
		fromCal = data.fromULocale.split('.')[2];
	}

	var toCal = data.toULocale.split('=')[1];
	if (!toCal)
	{
		toCal = data.toULocale.split('.')[2];
	}

	date = $.multicalendar._convertDateBetweenCalendarFormats(fromCal, data.fromDateFormat, 'yyyy-mm-dd', data.date);

	var dtini = new DateCalendar(date, CalendarType[fromCal.initCap()]);

	var dtend = dtini['to' + toCal.initCap()]();

	data.date = dtend.getFullYear() + '-' + dtend.getMonth() + '-' + dtend.getDate();

	data.date = $.multicalendar._convertDateBetweenCalendarFormats(toCal, 'yyyy-mm-dd', data.toDateFormat, data.date);

	return data.date;
};

Frames.regtype('datefield', Frames.MultiDateField);

var _constructor = Frames.FormatDate.prototype.__constructor;
Frames.FormatDate.prototype.__constructor = function()
{
	_constructor.apply(arguments);

	var longNamesMonth = $.multicalendar._defaults.calendarLocaleProps[$.multicalendar._defaults.defaultCalendar].monthNames;
	var shortNamesMonth = $.multicalendar._defaults.calendarLocaleProps[$.multicalendar._defaults.defaultCalendar].monthNamesShort;
	var longNamesDay = $.multicalendar._defaults.calendarLocaleProps[$.multicalendar._defaults.defaultCalendar].dayNames;
	var shortNamesDay = $.multicalendar._defaults.calendarLocaleProps[$.multicalendar._defaults.defaultCalendar].dayNamesShort;

	Frames.FormatDate.MONTH_NAMES = longNamesMonth.concat(shortNamesMonth);
	Frames.FormatDate.DAY_NAMES = longNamesDay.concat(shortNamesDay);
};

var DATE_PARTS_DEFAULT = 'D M Y H M S';


Frames.FormatMultiDate = _$.inherit(
	Frames.FormatDate,
{
	__constructor: function()
	{
	},

	_getDefaultFormat: function()
	{
		return Frames.Locale.formats.DATE_FORMAT;
	},

	_getCanonicalFormat: function()
	{
		return Frames.Config.get('DATE_CANONICAL_FORMAT', 'MM/dd/yyyy hh:mm:ss');
	},

	message: function(val, format, type)
	{
		return Frames.Locale.messages.VALIDATION_FORMAT.replace('%s',  '{0}');
	},

	convertFormatLocalized: function(format)
	{
		var frm = this.convertFormat(format, {localized: true});

		var localeParts = Frames.Locale.formats.DATE_PARTS;
		if (Frames.isUndef(localeParts))
		{
			localeParts = DATE_PARTS_DEFAULT;
		}
		if (localeParts != DATE_PARTS_DEFAULT)
		{
			var dparts = DATE_PARTS_DEFAULT.split(' ');
			var parts = localeParts.split(' ');
			$.each(parts, function(i)
			{
				var part = parts[i];

				frm = frm.replace(new RegExp(dparts[i] + (part.length > 1 ? '+' : ''), 'g'), part);
			});
		}
		return frm;
	},

	convertFormat: function(format, flags)
	{
		if (Frames.isUndef(format))
		{
			format =  this._getDefaultFormat();
		}

		var frm = this._convertFormat(format, flags);
		var ret = frm && frm.dateFormat ? frm.dateFormat.toUpperCase() : format;

		if (frm && frm.timeFormat)
		{
			ret += ' ' + frm.timeFormat.toUpperCase();
		}

		return ret;
	},

	_convertFormat: function(format, flags)
	{
		if (Frames.isUndef(format))
		{
			format =  this._getDefaultFormat();
		}

		return Frames.MultiDateField.convertToWidgetFormats(format, flags);
	},

	_separateFormat: function(format)
	{
		if ($.isPlainObject(format) && !Frames.isUndef(format.calendar))
		{
			return { dateValue: format.format.dateFormat, timeValue: format.format.timeFormat };
		}

		return Frames.FormatDate.prototype._separateFormat(format);
	},

	_uniteDate: function(value)
	{
		if (typeof(value) == 'string')
		{
			return value;
		}

		return Frames.FormatDate.prototype._uniteDate({dateValue: value.format.dateFormat, timeValue: value.format.timeFormat});
	},

	_getPartsPositions: function(format)
	{
		// get right order of the format

		var frm = format.toLowerCase();
		var dfrm = (Frames.Locale.formats.DATE_FORMAT || 'dd/mm/yy').toLowerCase();

		var parts = ['m', 'd', 'y'];
		parts = $.map(parts, function(v) { return frm.indexOf(v) !== -1 ? v : undefined; });

		var pos = parts.sort(function(a, b)
		{
			var aa = frm.indexOf(a);
			var bb = frm.indexOf(b);

			if (aa === -1)
			{
				aa = dfrm.indexOf(a);
			}
			if (bb === -1)
			{
				bb = dfrm.indexOf(b);
			}

			return aa - bb;
		});

		return pos;
	},

	_getTryDates: function(val, format)
	{
		var tryDateFormats = [];
		var isObject = false;

		if (typeof(format) == 'string')
		{
			format = this._convertFormat(format);
		}

		var frm = format.dateFormat.toLowerCase();
		var pos = this._getPartsPositions(frm);

		if (Frames.isNumeric(val))
		{
			// calculate the right formats to test from
			tryDateFormats = [
				$.map(pos, function(v) { return Array(3).join(v); }).join(''),
				$.map(pos, function(v) { return Array(v == 'y' ? 5 : 3).join(v); }).join('')
			];
		}
		else
		{
			var sep = this._getSeparator(val);

			if (val.split(sep).length != 3)
			{
				pos = $.map(pos, function(v) { return frm.indexOf(v) !== -1 ? v : undefined; });
			}

			tryDateFormats = [
				$.map(pos, function(v) { return Array(3).join(v); }).join(sep),
				$.map(pos, function(v) { return Array(v == 'y' ? 5 : 3).join(v); }).join(sep),
				$.map(pos, function(v) { return v == 'm' ? 'M' : Array(3).join(v); }).join(sep),
				$.map(pos, function(v) { return v == 'm' ? 'M' : Array(v == 'y' ? 5 : 3).join(v); }).join(sep),
				$.map(pos, function(v) { return v == 'm' ? 'MM' : Array(3).join(v); }).join(sep),
				$.map(pos, function(v) { return v == 'm' ? 'MM' : Array(v == 'y' ? 5 : 3).join(v); }).join(sep),
				$.map(pos, function(v) { return v == 'm' ? 'MMM' : Array(3).join(v); }).join(sep),
				$.map(pos, function(v) { return v == 'm' ? 'MMM' : Array(v == 'y' ? 5 : 3).join(v); }).join(sep)
			];

			var _tryDTF = $.map(tryDateFormats, function(v)
			{
				return {
					dateFormat: v,
					timeFormat: undefined
				};
			});

			if (!Frames.isEmpty(format.timeFormat))
			{
				frm = format.timeFormat.toLowerCase();

				var len = tryDateFormats.length;
				var H = format.timeFormat.indexOf('H') !== -1 ? 'H' : 'h';

				for (var i = 0; i < len; i++)
				{
					var dt = tryDateFormats[i];
					// Time formats should be the firsts being tested so it should be added to the beginning of the array
					_tryDTF.unshift({
						dateFormat: dt,
						timeFormat: H + ':mm'
					});
					_tryDTF.unshift({
						dateFormat: dt,
						timeFormat: H + ':mm a'
					});
					_tryDTF.unshift({
						dateFormat: dt,
						timeFormat: H + ':mm:ss'
					});
					_tryDTF.unshift({
						dateFormat: dt,
						timeFormat: H + ':mm:ss a'
					});
				}
			}

			tryDateFormats = _tryDTF;
		}

		return tryDateFormats;
	},

	_getSeparator: function(val)
	{
		var sep = '';
		if (val.indexOf('/') != -1)
		{
			sep = '/';
		}
		else if (val.indexOf('-') != -1)
		{
			sep = '-';
		}
		else if (val.indexOf('.') != -1)
		{
			sep = '.';
		}
		return sep;
	},

	_valueToDate: function(val, format, validate)
	{
		var date = null;

		var unitedFormat = format ? this._uniteDate(format) : '';
		if (Frames.isEmpty(format) || /(DAY|DY)/gi.test(unitedFormat))
		{
			format = {
				format: this._convertFormat(Frames.Locale.formats.DATE_FORMAT),
				calendar: Frames.Locale.formats.DEFAULT_CALENDAR
			};
		}

		format = _$.extend(true, {}, format); // clone

		var separated = this._separateFormat(format);
		if (Frames.isEmpty(separated.dateValue) && !Frames.isEmpty(separated.timeValue))
		{
			return Frames.FormatDate.prototype._valueToDate.call(Frames.FormatDate.prototype, val, separated.timeValue, validate);
		}

		// always try to parse date without separators
		if (!Frames.isUndef(val) && val.length > 0)
		{
			
			var match = val.search(/[a-z]/i);
			if (val.length == 1 && match === 0)
			{
				//HACK: to Value is being called by item API (@ovalue). This will convert the alpha character by the current date
				val = this._autocompleteVal(val, format);
			}
			
			var originalDateFormat = format.format.dateFormat || format.dateFormat;
			var originalTimeFormat = format.format.timeFormat || format.timeFormat;

			var tryDateFormats = this._getTryDates(val, format.format);

			// try to find correct mask and apply it
			for (var i = 0; i < tryDateFormats.length; i++)

			{
				var ff = {
					calendar: format.calendar || format.format.calendar,
					format: Frames.MultiDateField.convertToWidgetFormats(tryDateFormats[i])
				};
				date = this._parseDate(val, ff, validate);

				if (date)
				{
					break;
				}
			}

			if (!date)
			{
				// restore format
				format.format.dateFormat = originalDateFormat;
				format.format.timeFormat = originalTimeFormat;

				date = this._parseDate(val, format, validate);
			}
		}

		return date;
	},

	_parseDate: function(val, format, validate)
	{
		var date = null;

		if (Frames.isUndef(format))
		{
			return null;
		} else
		if (typeof(format) == 'string')
		{
			format = this._convertFormat(format);
		}


		var currentTime;
		var timeFormat = format.format.timeFormat;
		if (timeFormat)
		{
			var time = this._extractTimePart(val, timeFormat);
			val = val.replace(time, '').trim();

			if (typeof time === 'string' && time !== '')
			{
				var options = {
					show24Hours: /\b[HH|H|kk|k]+\b/.test(timeFormat),
					showSeconds: /\b[ss|s]+\b/.test(timeFormat),
					ampmPrefix: /\sa/.test(timeFormat) ? ' ' : '',
					separator: ':'
				};

				options = _$.extend({}, $.timeEntry.defaultOptions, options);
				currentTime = $.timeEntry._extractTime({ options: options }, time);
			}
			else
			{
				return null;
			}
		}

		var calendar = $.calendars.instance(format.calendar);

		try
		{
			var dd = new Date();
			var month = dd.getMonth() + 1;
			var year = dd.getFullYear();
			var day = dd.getDate();

			// HACK remove timeFormat from value to support RTL!
			var frm = val;
			var dateFormat = val;
			var splitIndex = frm.search(/\b\w+:/);
			if (splitIndex !== -1 && splitIndex !== 0)
			{
				dateFormat = frm.substring(0, splitIndex).trim();
				timeFormat = frm.substring(splitIndex).trim();
			}
			else
			{
				splitIndex = frm.search(/\b\w+[/]/);
				if (splitIndex !== -1 && splitIndex !== 0)
				{
					timeFormat = frm.substring(0, splitIndex).trim();
					dateFormat = frm.substring(splitIndex).trim();
				}
			}

			var pivot =  $.i18n.map['default.century.pivot'];
			pivot = pivot ? parseInt(pivot) : undefined;

			date = calendar.parseDate(format.format.dateFormat, dateFormat, {
				defaults: { day: day, month: month, year: year},
				shortYearCutoff: pivot
			});


		}
		catch (e)
		{}

		if (date)
		{
			date = date.toJSDate();
			if (currentTime)
			{
				if (currentTime[0])
				{
					date.setHours(currentTime[0]);
				}

				if (currentTime[1])
				{
					date.setMinutes(currentTime[1]);
				}

				if (currentTime[2])
				{
					date.setSeconds(currentTime[2]);
				}
			}
		}

		return date;
	},

	_extractTimePart: function(val, timeFormat)
	{
		var timePattern = $.multicalendar.getRegExForTimeFormat(timeFormat);
		var regEx = new RegExp('' + timePattern + '$', 'g');
		var matches = val.match(regEx);

		return matches ? matches[0].trim() : '';
	},

	formatFromCanonical: function(val, format, force)
	{
		var informat = this._getCanonicalFormat();
		if (force !== true && !this.test(val, informat, true))
		{
			return val;
		}
		if (val.indexOf(':') == -1)
		{
			val += ' 12:00:00';
			if (informat.indexOf(' A', informat.length - 2) !== -1)
			{
				val += ' AM';
			}
		}

		var ret = this._format(val,
			{
				format: informat,
				calendar: 'gregorian'
			},
			{
				format: format || this._getDefaultFormat(),
				calendar: Frames.Locale.formats.DEFAULT_CALENDAR
			});

		return ret;
	},

	getTypeInformation: function(mode, format)
	{
		return {
			type: mode === 'SEARCH' ? 'json' : '',
			extra: {
				format: format
				// calendar: 'gregorian'
			}
		};
	},

	formatToCanonical: function(val, format)
	{
		var canFormat = this._getCanonicalFormat();

		if (!this.test(val, format))
		{
			return val;
		}

		val = this._autocompleteVal(val, format || Frames.Locale.formats.DATE_FORMAT);

		if (Frames.isUndef(format))
		{
			format = this._getDefaultFormat();
		}

		var ret = this._format(val,
			{
				format: format, // always use full format because autocomplete
				calendar: Frames.Locale.formats.DEFAULT_CALENDAR,
			},
			{
				format: canFormat,
				calendar: 'gregorian'
			});

		return ret;
	},

	toValueFromCanonical: function(val)
	{
		var informat = this._getCanonicalFormat();
		return this.toValue(val, informat, 'gregorian');
	},

	format: function(val, format, validate)
	{
		if (!Frames.isUndef(format))
		{
			format = this._convertFormat(format);
		}

		format = {
			format: format || Frames.Locale.formats.DATE_FORMAT,
			calendar: Frames.Locale.formats.DEFAULT_CALENDAR
		};
		var informat = format;
		var outformat = format;

		var vv = this._autocompleteVal(val, format);
		if (vv != val)
		{
			val = vv;
			informat = {
				format: Frames.Locale.formats.DATE_FORMAT,
				calendar: Frames.Locale.formats.DEFAULT_CALENDAR
			};
		}

		return this._format(val, informat, outformat, validate || false);
	},

	unformat: function(val)
	{
		return val;
	},

	equal: function(dt1, dt2, format, validate)
	{
		format = {
			format: this._convertFormat(format),
			calendar: Frames.Locale.formats.DEFAULT_CALENDAR
		};

		var d1 = this._valueToDate(dt1, format, validate);
		d1 = d1 && d1.getTime() || dt1;

		var d2 = this._valueToDate(dt2, format, validate);
		d2 = d2 && d2.getTime() || dt2;

		return (d1 === null && d2 === null) ? dt1 === dt2 : d1 === d2;
	},

	equals: function(v1, v2, format)
	{
		if (Frames.isUndef(v1) || Frames.isUndef(v2))
		{
			return v1 === v2;
		}

		var canFormat = this._getCanonicalFormat();
		v1 = this.test(v1, format) ? this.formatToCanonical(v1, format) : this.formatToCanonical(v1, canFormat);
		v2 = this.test(v2, format) ? this.formatToCanonical(v2, format) : this.formatToCanonical(v2, canFormat);

		return this.equal(v1,v2,canFormat);
	},

	_autocompleteVal: function(val, format)
	{
		if (Frames.Application.task.block && Frames.Application.task.block.props('blockMode') == 'SEARCH')
		{
			return val;
		}

		if (!Frames.isUndef(format) && typeof(format) != 'string')
		{
			format = format.format.dateFormat;
		}

		if (!Frames.isEmpty(val) && typeof(val) == 'string')
		{
			var date = new Date();

			var match = val.search(/[a-z]/i);
			if (val.length == 1 && match === 0)
			{
				val = this.format(date, format);
			}
			else
			{
				var frm = this._convertFormat(format);
				var month = date.getMonth() + 1;
				var year = date.getFullYear();
				var day = date.getDate();

				var calendar = $.calendars.instance(Frames.Locale.formats.DEFAULT_CALENDAR);
				try
				{
					var pivot =  $.i18n.map['default.century.pivot'];
					pivot = pivot ? parseInt(pivot) : undefined;
					var dt = calendar.parseDate(frm.dateFormat, val, {
						defaults: { day: day, month: month, year: year},
						shortYearCutoff: pivot
					});
					val = dt.formatDate(frm.dateFormat);
				}
				catch (e)
				{
					return val;
				}
			}
		}
		return val;
	},

	test: function(val, format, canonical)
	{
		if (val instanceof Date)
		{
			return true;
		}

		var unitedFormat = format ? this._uniteDate(format) : '';
		if (Frames.isEmpty(format) || /(DAY|DY|E)/gi.test(unitedFormat))
		{
			format = this._getDefaultFormat();
		}

		var separated = this._separateFormat(format);

		if (Frames.isEmpty(separated.dateValue) && !Frames.isEmpty(separated.timeValue))
		{
			return Frames.FormatDate.prototype.test.call(Frames.FormatDate.prototype, val, separated.timeValue, canonical);
		}

		var v;
		var validate = true;

		if (!Frames.isUndef(val) && val.length > 0)
		{
			var vv;
			if (canonical)
			{
				vv = this.formatFromCanonical(val, format, true);
			}
			else
			{
				// WARN: this will change the date
				vv = this._autocompleteVal(val, format);
			}

			var tryDateFormats = this._getTryDates(vv, format);

			for (var i = 0; i < tryDateFormats.length; i++)
			{
				var informat = {
					format: tryDateFormats[i],
					calendar: Frames.Locale.formats.DEFAULT_CALENDAR
				};

				var outformat = {
					format: this._convertFormat(format),
					calendar: Frames.Locale.formats.DEFAULT_CALENDAR
				};

				v = this._format(vv, informat, outformat, true /*validate*/);

				if (!Frames.isEmpty(v))
				{
					val = vv;
					break;
				}
			}
		}

		if (Frames.isEmpty(v))
		{
			return false;
		}

		return this.equal(v, val, format, validate);
	},

	_format: function(val, informat, outformat, validate, outDateFormat)
	{
		if (Frames.isUndef(informat))
		{
			informat = {
				format: Frames.Locale.formats.DATE_FORMAT,
				calendar: Frames.Locale.formats.DEFAULT_CALENDAR
			};
		}

		if (Frames.isUndef(outformat))
		{
			outformat = {
				format: Frames.Locale.formats.DATE_FORMAT,
				calendar: Frames.Locale.formats.DEFAULT_CALENDAR
			};
		}

		informat = _$.extend({}, informat, { format: this._convertFormat(informat.format) });
		outformat = _$.extend({}, outformat, { format: this._convertFormat(outformat.format) });

		if (Frames.isEmpty(informat.format.dateFormat) && !Frames.isEmpty(informat.format.timeFormat))
		{
			return Frames.FormatDate.prototype._format.call(Frames.FormatDate.prototype, val, { dateValue: undefined, timeValue: informat.format.timeFormat}, { dateValue: undefined, timeValue: outformat.format.timeFormat }, validate);
		}

		var obj = val;
		if (typeof(val) == 'string')
		{
			obj = this._valueToDate(val, informat, validate);
		}

		if (Frames.isUndef(obj))
		{
			return '';
		}

		var calendar = $.calendars.instance(outformat.calendar);
		date = calendar.fromJSDate(obj);

		var yearToString = date._year.toString();
		//validate that is not a negative year
		if (yearToString.indexOf('-') == 0)
		{
			return '';
		}

		if (yearToString.length === 3)
		{
			var yearFormat = (outformat.format.dateFormat.match(/y/g) || []).length
			if (yearFormat === 4)
			{
				date._year = '0' + date._year;
			}
		}

		outDateFormat = outDateFormat || outformat.format.dateFormat;
		var dateString = outDateFormat ? date.formatDate(outDateFormat) : '';

		var timeFormat = outformat.format.timeFormat;
		if (timeFormat)
		{
			var timeOptions = {
				show24Hours: /\b[HH|H|kk|k]+\b/.test(timeFormat),
				showSeconds: /\b[ss|s]+\b/.test(timeFormat),
				ampmPrefix: /\sa/.test(timeFormat) ? ' ' : '',
				separator: ':'
			};

			timeOptions = _$.extend({}, $.timeEntry.defaultOptions, timeOptions);

			var timeString = ($.timeEntry._formatNumber(timeOptions.show24Hours ? obj.getHours() :
				((obj.getHours() + 11) % 12) + 1)) + timeOptions.separator +
				$.timeEntry._formatNumber(obj.getMinutes()) +
				(timeOptions.showSeconds ? timeOptions.separator +
				$.timeEntry._formatNumber(obj.getSeconds()) : '') +
				(timeOptions.show24Hours ?  '' : timeOptions.ampmPrefix +
				timeOptions.ampmNames[(obj.getHours() < 12 ? 0 : 1)]);

			if (!Frames.isEmpty(timeString))
			{
				if (Frames.Locale.formats.IS_RTL && !dateIsRTL && outformat.calendar != 'gregorian')
				{
					var timeString = timeString.split(' ').reverse().join(' ');
					dateString = timeString + (!Frames.isEmpty(dateString) ? ' ' : '') + dateString;
				}
				else
				{
					dateString += (!Frames.isEmpty(dateString) ? ' ' : '') + timeString;
				}
			}
		}
		return dateString;
	},

	toValue: function(val, format, calendar)
	{
		if (Frames.isUndef(format))
		{
			format = this._getDefaultFormat();
		}

		format = {
			format: this._convertFormat(format),
			calendar: calendar || Frames.Locale.formats.DEFAULT_CALENDAR
		};

		return this._valueToDate(val, format, true);
	}
});

var lang = Frames.Locale.lang;
var def_cal = Frames.Locale.formats.DEFAULT_CALENDAR;

if ($.calendarsPicker.regionalOptions[lang] === undefined)
{
	if ($.calendarsPicker.regionalOptions[Frames.Locale.ulang] === undefined)
	{
		lang = '';
	}
	else
	{
		lang = Frames.Locale.ulang;
	}
}

var monthNames = (
		$.calendars.calendars[def_cal].prototype.regionalOptions[lang] ||
		$.calendars.calendars[def_cal].prototype.regionalOptions['']
	).monthNames;

var monthName = monthNames[0];
var dateIsRTL = Frames.Locale.formats.IS_RTL && /[\u0600-\u06FF]/.test(monthName); // TODO: a bit of a hack here. Testing if is arabic

var dfrm = Frames.Locale.formats.DATE_FORMAT || 'dd/mm/yy';

Frames.Locale.formats.DATE_IS_RTL = dateIsRTL;

if (Frames.Locale.formats.IS_RTL && !dateIsRTL)
{
	dfrm = dfrm.split('').reverse().join(''); // reverse format
	Frames.Locale.formats.DATE_FORMAT = dfrm;
}

var formats = Frames.MultiDateField.convertToWidgetFormats(dfrm, lang);
var dateformat = formats.dateFormat;
var timeformat = formats.timeFormat;

var calType = Frames.Locale.formats.DEFAULT_CALENDAR;

// ellucian gets all of these from server side brought properties files
$.i18n.map['js.datepicker.dateFormat'] = dateformat;
$.i18n.map['default.calendar'] = Frames.Locale.formats.DEFAULT_CALENDAR;

var calendars = Frames.Locale.formats.CALENDARS;
for (var i = 0; i < calendars.length; i++)
{
	$.i18n.map['default.calendar' + i] = calendars[i];
}

$.i18n.map['default.date.time.error'] = 'Invalid date time. Format: {0}'; // TODO: fetch this from somewhere else!

$.i18n.map['default.language.direction'] = Frames.Locale.formats.IS_RTL ? 'rtl' : 'ltr';

$.i18n.map['default.dateEntry.format'] = dateformat;

$.i18n.map['default.century.below.pivot'] = '2000'; // TODO: fetch this from somewhere else!
$.i18n.map['default.century.pivot'] = '50'; // TODO: fetch this from somewhere else!
$.i18n.map['default.century.above.pivot'] = '1900'; // TODO: fetch this from somewhere else!

var calendar_locale_props = {};
var picker_defaults = {};
var _cal;

for (var j = 0; j < calendars.length; j++)
{
	_cal = calendars[j];

	// for reference, ellucian gets all of these from server side brought properties files
	// monthNames: $.i18n.prop("default.islamic.monthNames"),
	// monthNamesShort: $.i18n.prop("default.islamic.monthNamesShort"),
	// dayNames: $.i18n.prop("default.islamic.dayNames"),
	// dayNamesShort: $.i18n.prop("default.islamic.dayNamesShort"),
	// dayNamesMin: $.i18n.prop("default.islamic.dayNamesMin")

	if ($.calendars.calendars[_cal])
	{
		var _calRegional = $.calendars.calendars[_cal].prototype.regionalOptions[lang] || $.calendars.calendars[_cal].prototype.regionalOptions[''];

		calendar_locale_props[_cal] = {
			monthNames: _calRegional.monthNames,
			monthNamesShort: _calRegional.monthNamesShort,
			dayNames: _calRegional.dayNames,
			dayNamesShort: _calRegional.dayNamesShort,
			dayNamesMin: _calRegional.dayNamesMin
		};
	}
}

// make a new renderer more similar to jquery ui's datepicker
var renderer = _$.extend({}, $.calendarsPicker.themeRollerRenderer, {
	commandClass: 'ui-datepicker-cmd'
});

_cal = Frames.Locale.formats.DEFAULT_CALENDAR;
var firstDay = (
		$.calendars.calendars[_cal].prototype.regionalOptions[lang] ||
		$.calendars.calendars[_cal].prototype.regionalOptions['']
	).firstDay;

var defaults = _$.extend({}, $.calendarsPicker.regionalOptions[lang], {
	renderer: renderer,
	changeMonth: true,
	showAnim: '',
	showOptions: null,
	showSpeed: 'normal',
	useMouseWheel: false,
	showOtherMonths: true,
	selectOtherMonths: true,
	prevText: '<span>&#160;</span>',
	nextText: '<span>&#160;</span>',
	isRTL: Frames.Locale.formats.IS_RTL
});

$.calendarsPicker.setDefaults(defaults);

$.multicalendar.setDefaults({
	defaultCalendar: calType,
	defaultDateFormat: dateformat,
	displayDateFormat: dateformat,
	calendars: Frames.Locale.formats.CALENDARS,
	isRTL: Frames.Locale.formats.IS_RTL,
	calendarLocaleProps: calendar_locale_props,
	buttonClass: 'calendar-img',
	showOn: 'button',
	firstDayOfTheWeek: firstDay,
	timeFormat: timeformat,
	timeLocaleProps: $.timeEntry.regionalOptions[lang] || $.timeEntry.regionalOptions['']
});

//# sourceURL=app/flat/widgets/datepicker/js/frames.calendar.js
